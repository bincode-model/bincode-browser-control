export function verifyReadReceipt(data, profileId, extensionId) {
  if (!data?.proof || data.proof.profileId !== profileId ||
      data.proof.extensionId !== extensionId || data.proof.debuggerAttached !== true ||
      !data.proof.attachedTabs?.length || !/^https?:\/\//.test(data.result?.url || '') ||
      typeof data.result.text !== 'string') {
    throw Error('未取得与本环境、插件及实际页面一致的调试读取回执。');
  }
  return {profileId, extensionId, debuggerAttached:true, url:data.result.url,
    title:data.result.title || '', checkedAt:data.proof.timestamp};
}

export function assessJobResult(job) {
  const result = String(job.result || '');
  if (/停在登录页|跳转[至到].*登录页|请先.*登录|等待.*登录|在\s*env-\d+\s*登录/.test(result)) {
    return {status:'waiting_login',reason:'尚未登录或完成本人验证，任务未完成。'};
  }
  if (/补充.*(日期|类型|范围)|明确.*(取数|范围)|缺少.*(范围|信息|日期)|等待.*确认/.test(result)) {
    return {status:'needs_input',reason:'缺少执行任务所需的信息。'};
  }
  // CLI exit code and browser actions prove execution, not acceptance.
  return {status:'needs_review',reason:'执行结果已保存，待核对任务目标和交付结果。'};
}
