import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {WebSocketServer} from 'ws';
import {Fleet} from './fleet.mjs';
import {ROOT,DATA} from './store.mjs';

export const fleet=new Fleet();
const token=fs.readFileSync(path.join(DATA,'admin-token'),'utf8').trim();
const consoleOrigin=`http://127.0.0.1:${fleet.config.port}`;
const sseClients=new Set();
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
const send=(res,status,value)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(value));};
function authed(req){return req.headers.authorization==='Bearer '+token||(req.headers.cookie||'').split(';').some(x=>x.trim()==='fleet_session='+token);}
async function body(req){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>1000000)throw Error('请求内容过大。');}return raw?JSON.parse(raw):{};}
function escape(x){return String(x).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));}
function staticFile(res,file){if(!fs.existsSync(file)||!fs.statSync(file).isFile())return send(res,404,{error:'文件不存在。'});res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});fs.createReadStream(file).pipe(res);}
const server=http.createServer(async(req,res)=>{
  try{
    if(![`127.0.0.1:${fleet.config.port}`,`localhost:${fleet.config.port}`].includes(req.headers.host))return send(res,403,{error:'Host 不匹配。'});
    const u=new URL(req.url,consoleOrigin),route=u.pathname;
    if(req.method!=='GET'&&req.headers.origin&&![consoleOrigin,consoleOrigin.replace('127.0.0.1','localhost')].includes(req.headers.origin))return send(res,403,{error:'只允许本机控制台提交指令。'});
    if(route==='/health')return send(res,200,{ok:true,pid:process.pid,profiles:140,version:'1.2.0',root:ROOT,dataDir:DATA});
    if(route.startsWith('/welcome/')){
      const p=fleet.profileView(route.split('/').at(-1));res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
      return res.end(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>${escape(p.name)} · 独立 AI 浏览器</title><style>body{font:16px/1.7 system-ui;max-width:780px;margin:120px auto;padding:24px;color:#1e3035;background:#f4f7f8}h1{font-size:36px;letter-spacing:-.02em}code{background:#e3ebed;padding:4px 8px;border-radius:4px}a{color:#175e6b}button,input{font:inherit;padding:10px;border:1px solid #c7d2d6;border-radius:6px}button{background:#175e6b;color:white;cursor:pointer}</style><p>bincode多浏览器控制 / 浏览器${p.number} / 第 ${p.group} 组</p><h1>${escape(p.name)}</h1><p>环境编号 <code>${p.id}</code>。这个窗口有独立的 Cookie、登录和 AI 控制插件。</p><p>AI 接管后，页面顶部将显示控制者名称；蓝色浏览器也会显示此插件的调试提示。</p><p><a href="/" target="_blank">打开控制台</a>，提交任务或配置本环境。</p><hr><h2>插件操作验证页</h2><label for="test-input">验证输入</label> <input id="test-input" placeholder="由 AI 插件填写"><button id="test-button" onclick="document.getElementById('test-result').textContent=document.getElementById('test-input').value">确认</button><p id="test-result">等待操作</p><div id="trusted-result"></div><script>document.querySelector('#test-button').addEventListener('click',e=>document.querySelector('#trusted-result').textContent='isTrusted='+e.isTrusted);</script></html>`);
    }
    if(route.startsWith('/api/')){
      if(!authed(req))return send(res,401,{error:'本机控制台认证失败，请重新打开控制台。'});
      if(route==='/api/events'&&req.method==='GET'){
        res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-store','connection':'keep-alive'});res.write('event: state\ndata: '+JSON.stringify(fleet.publicState())+'\n\n');sseClients.add(res);req.on('close',()=>sseClients.delete(res));return;
      }
      if(route==='/api/state'&&req.method==='GET')return send(res,200,fleet.publicState());
      if(route.startsWith('/api/artifacts/')&&req.method==='GET'){const name=route.split('/').at(-1);if(!/^env-\d{3}-\d+-[a-f\d]+\.png$/.test(name))throw Error('截图文件名无效。');return staticFile(res,path.join(DATA,'artifacts',name));}
      if(route.startsWith('/api/jobs/')&&req.method==='GET'){const j=fleet.jobs.find(j=>j.id===route.split('/').at(-1));if(!j)return send(res,404,{error:'任务不存在。'});return send(res,200,j);}
      if(req.method!=='POST')return send(res,405,{error:'方法不支持。'});const value=await body(req);
      const ops={
        '/api/start':()=>value.connect===false?fleet.start(value.profileId,{background:value.background,initialUrl:value.initialUrl}):fleet.launch(value.profileId,{initialUrl:value.initialUrl}),
        '/api/stop':()=>fleet.stop(value.profileId,{force:value.force===true}),
        '/api/command':()=>fleet.command(value.profileId,value.action,value.args,value),
        '/api/release':()=>fleet.release(value.profileId,value.owner,value.force===true),
        '/api/settings':()=>fleet.settings(value),
        '/api/profile':()=>fleet.updateProfile(value.profileId,value),
        '/api/browser-network':()=>fleet.setBrowserNetworkMode(value.mode),
        '/api/provider':()=>fleet.configureProvider(value.provider,value.config),
        '/api/jobs':()=>fleet.enqueue(value),
        '/api/cancel':()=>fleet.cancelJob(value.jobId),
        '/api/retry':()=>fleet.retryJob(value.jobId),
        '/api/pause':()=>{fleet.paused=!!value.paused;fleet.changed();return {paused:fleet.paused};},
        '/api/emergency-stop':()=>fleet.emergencyStop(),
        '/api/close-idle':()=>Promise.allSettled([...fleet.runtime].filter(([,r])=>r.pid&&(!r.lease||r.lease.kind==='standby')).map(([id])=>fleet.stop(id)))
      };if(!ops[route])return send(res,404,{error:'接口不存在。'});return send(res,200,await ops[route]());
    }
    if(route==='/'){
      res.setHeader('set-cookie',`fleet_session=${token}; HttpOnly; SameSite=Strict; Path=/`);
      return staticFile(res,path.join(ROOT,'public/index.html'));
    }
    if(!['/app.js','/paging.js','/profile-presentation.js','/style.css','/logo.png'].includes(route))return send(res,404,{error:'页面不存在。'});return staticFile(res,path.join(ROOT,'public',route.slice(1)));
  }catch(e){send(res,400,{error:e.message});}
});
const wss=new WebSocketServer({noServer:true,maxPayload:16*1024*1024});
server.on('upgrade',(req,socket,head)=>{
  if(req.url!=='/bridge'||req.headers.host!==`127.0.0.1:${fleet.config.port}`||!req.headers.origin?.startsWith('chrome-extension://')){socket.destroy();return;}
  wss.handleUpgrade(req,socket,head,ws=>{
    const timer=setTimeout(()=>ws.close(1008,'authentication timeout'),5000);ws.on('message',raw=>{
      let m;try{m=JSON.parse(raw);}catch{ws.close(1008,'invalid message');return;}
      try{if(!ws.profileId){if(m.type!=='hello')throw Error('hello required');fleet.connect(ws,m);clearTimeout(timer);}else fleet.receive(ws,m);}catch{ws.close(1008,'authentication failed');}
    });ws.on('error',()=>{});
  });
});
let scheduled;
fleet.on('change',()=>{if(scheduled)return;scheduled=setTimeout(()=>{scheduled=null;const data=JSON.stringify(fleet.publicState());for(const res of sseClients)res.write('event: state\ndata: '+data+'\n\n');},200);});
fleet.on('jobEvent',event=>{for(const res of sseClients)res.write('event: job\ndata: '+JSON.stringify(event)+'\n\n');});
setInterval(()=>{fleet.changed();for(const res of sseClients)res.write(': heartbeat\n\n');},5000).unref();
server.listen(fleet.config.port,'127.0.0.1',()=>{
  fs.writeFileSync(path.join(DATA,'server.pid'),String(process.pid),{mode:0o600});console.log(`AI Browser Fleet: ${consoleOrigin} · 140 independent environments`);
});
server.on('error',e=>{console.error(e.message);process.exit(1);});
async function shutdown(){clearInterval(fleet.timer);await fleet.emergencyStop();for(const res of sseClients)res.end();wss.close();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),5000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
