import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
export const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const DATA=path.resolve(process.env.FLEET_DATA_DIR||path.join(ROOT,'data'));
export const now=()=>new Date().toISOString();
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export function writeJSON(file,value){fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(value,null,2)+'\n',{mode:0o600});fs.renameSync(tmp,file);}
export function loadJSON(file,fallback){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code==='ENOENT')return fallback;throw e;}}
export function numberedProfiles(profiles){return [...profiles].sort((a,b)=>{
  const number=p=>/^env-\d{3}$/.test(p.id||'')?Number(p.id.slice(4)):Number(p.number)||Number.MAX_SAFE_INTEGER;
  return number(a)-number(b)||String(a.id).localeCompare(String(b.id));
});}
export function findChrome(){
  let downloaded='';try{downloaded=createRequire(import.meta.url)('playwright-core').chromium.executablePath();}catch{}
  const bundled=process.platform==='darwin'?path.join(ROOT,'runtime/browser/Chromium.app/Contents/MacOS/Chromium'):path.join(ROOT,'runtime/browser/chrome');
  const cache=path.join(os.homedir(),'Library/Caches/ms-playwright');
  const legacy=fs.existsSync(cache)?fs.readdirSync(cache).filter(n=>/^chromium-/.test(n)).sort().reverse().map(n=>path.join(cache,n,'chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing')):[];
  return [process.env.FLEET_CHROME,bundled,downloaded,...legacy,'/Applications/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing','/usr/bin/chromium','/usr/bin/chromium-browser'].find(p=>p&&fs.existsSync(p))||'';
}
export function initStore(){
  fs.mkdirSync(DATA,{recursive:true,mode:0o700});fs.chmodSync(DATA,0o700);
  const file=path.join(DATA,'fleet.json');
  const config=loadJSON(file,null)||{schemaVersion:1,createdAt:now(),port:Number(process.env.FLEET_PORT||17410),chrome:findChrome(),groupSize:50,maxBrowsers:2,maxAgents:2,autoClose:true,taskTimeoutMinutes:15,profiles:Array.from({length:140},(_,i)=>({id:`env-${String(i+1).padStart(3,'0')}`,number:i+1,name:`浏览器 ${String(i+1).padStart(3,'0')}`,group:Math.floor(i/50)+1,provider:'codex',entryUrl:'',extraExtensions:[],token:crypto.randomBytes(32).toString('hex')}))};
  if(process.env.FLEET_CHROME||!config.chrome||!fs.existsSync(config.chrome))config.chrome=findChrome();
  if(config.profiles.length!==140||new Set(config.profiles.map(p=>p.id)).size!==140)throw Error('配置必须包含 140 个独立环境。');
  config.profiles=numberedProfiles(config.profiles);
  for(const p of config.profiles){
    if(!/^env-\d{3}$/.test(p.id))throw Error('环境编号无效。');
    fs.mkdirSync(path.join(DATA,'profiles',p.id),{recursive:true,mode:0o700});
    fs.mkdirSync(path.join(DATA,'workspaces',p.id),{recursive:true,mode:0o700});
    const ext=path.join(DATA,'extensions',p.id);fs.mkdirSync(ext,{recursive:true,mode:0o700});
    for(const f of fs.readdirSync(path.join(ROOT,'extension')))fs.copyFileSync(path.join(ROOT,'extension',f),path.join(ext,f));
    const manifest=loadJSON(path.join(ext,'manifest.json'));
    manifest.name=`AI 浏览器 ${p.id.slice(4)}`;
    if(manifest.action)manifest.action.default_title=manifest.name;
    writeJSON(path.join(ext,'manifest.json'),manifest);
    fs.writeFileSync(path.join(ext,'config.js'),'const FLEET_CONFIG = '+JSON.stringify({profileId:p.id,token:p.token,bridgeUrl:`ws://127.0.0.1:${config.port}/bridge`,consoleUrl:`http://127.0.0.1:${config.port}/`})+';\n',{mode:0o600});
  }
  writeJSON(file,config);
  const auth=path.join(DATA,'admin-token');if(!fs.existsSync(auth))fs.writeFileSync(auth,crypto.randomBytes(32).toString('hex'),{mode:0o600});
  return config;
}
