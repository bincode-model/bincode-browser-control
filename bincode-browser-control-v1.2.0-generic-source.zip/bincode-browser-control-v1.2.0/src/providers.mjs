import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn,execFileSync} from 'node:child_process';
import {ROOT,DATA} from './store.mjs';

const executables={codex:[path.join(ROOT,'scripts/portable/codex.sh'),path.join(os.homedir(),'.local/bin/codex'),path.join(os.homedir(),'.npm-global/bin/codex'),'/opt/homebrew/bin/codex','/usr/local/bin/codex'], 'claude-cli':[path.join(os.homedir(),'.local/bin/claude'),'/opt/homebrew/bin/claude','/usr/local/bin/claude']};
function executable(id){
  const command=id==='codex'?'codex':'claude';
  const explicit=process.env[id==='codex'?'FLEET_CODEX':'FLEET_CLAUDE'];
  const onPath=(process.env.PATH||'').split(path.delimiter).map(p=>path.join(p,command));
  return [explicit,...(executables[id]||[]),...onPath].find(p=>p&&fs.existsSync(p));
}
export function providerStatus(credentials){return [
  {id:'codex',name:'Codex · ChatGPT 登录',kind:'cli',ready:!!executable('codex'),note:'使用本机 Codex 登录'},
  {id:'claude-cli',name:'Claude Code · 本机登录',kind:'cli',ready:!!executable('claude-cli'),note:'使用本机 Claude Code 登录'},
  ...[{id:'openai',name:'ChatGPT / OpenAI',baseUrl:'https://api.openai.com/v1'},{id:'anthropic',name:'Claude / Anthropic',baseUrl:'https://api.anthropic.com'},{id:'kimi',name:'Kimi / Moonshot',baseUrl:'https://api.moonshot.cn/v1'},{id:'perplexity',name:'Perplexity',baseUrl:'https://api.perplexity.ai'},{id:'compatible',name:'其他兼容模型',baseUrl:''}].map(p=>({...p,kind:'api',ready:!!(credentials[p.id]?.apiKey&&credentials[p.id]?.model&&(credentials[p.id]?.baseUrl||p.baseUrl)),model:credentials[p.id]?.model||'',baseUrl:credentials[p.id]?.baseUrl||p.baseUrl,note:p.id==='perplexity'?'需要支持工具调用的模型或兼容端点':'填写 API Key 和支持工具调用的模型'}))
];}
const actionDefinitions=[
  ['navigate','打开网站。只能 HTTP/HTTPS，可选新标签。',{url:{type:'string'},newTab:{type:'boolean'}},['url']],
  ['snapshot','读取当前页面、文本和可交互元素，返回 @e1 等引用。',{},[]],
  ['tabs','列出此独立环境内的标签页。',{},[]],
  ['select_tab','选择标签页。',{tabId:{type:'integer'}},['tabId']],
  ['click','点击页面元素，selector 使用 snapshot 中的 @e 引用或 CSS。',{selector:{type:'string'}},['selector']],
  ['fill','清空并填写输入框。',{selector:{type:'string'},value:{type:'string'}},['selector','value']],
  ['press_key','发送 Enter、Tab、Escape 等按键。',{key:{type:'string'}},['key']],
  ['scroll','滚动页面。',{x:{type:'number'},y:{type:'number'}},['y']],
  ['evaluate','在当前页面执行 JavaScript，返回可序列化结果。',{code:{type:'string'}},['code']],
  ['screenshot','保存当前网页截图。',{},[]]
];
export const apiTools=actionDefinitions.map(([name,description,properties,required])=>({type:'function',function:{name,description,parameters:{type:'object',properties,required,additionalProperties:false}}}));
function taskPrompt(job,fleet){
  const p=fleet.profile(job.profileId);
  return `你是 ${job.profileId} 的浏览器任务执行者。你只能通过 fleet MCP 的 browser_* 工具控制这一环境的 AI 插件。不要使用 shell、Playwright、远程调试端口、其他浏览器或其他 MCP。先 browser_navigate 打开任务需要的页面，再 browser_snapshot 读取当前页面，依据真实页面执行，不要编造已完成的操作。环境编号：${job.profileId}。${p.entryUrl?'默认入口：'+p.entryUrl+'。':''}\n用户任务：\n${job.prompt}\n仅执行用户授权的页面和操作。遇到登录、验证码或验证提示时暂停，等用户本人处理。以实际页面和插件回执作为证据；遇到权限或任务范围不明确时说明缺失信息。结束时说明实际结果、证据和未完成事项。`;
}
function cliArgs(job,fleet,output){
  const mcp={fleet:{command:process.execPath,args:[path.join(ROOT,'src/mcp.mjs'),'--profile',job.profileId],env:{FLEET_DATA_DIR:DATA,FLEET_OWNER:job.id,FLEET_CONTROLLER:job.provider==='codex'?'Codex':'Claude',FLEET_BACKGROUND:String(job.background===true)},startup_timeout_sec:30,tool_timeout_sec:120}};
  if(job.provider==='claude-cli')return ['-p',taskPrompt(job,fleet),'--output-format','stream-json','--verbose','--mcp-config',JSON.stringify({mcpServers:mcp}),'--strict-mcp-config','--allowedTools','mcp__fleet__*'];
  const args=['exec','--ignore-user-config','--skip-git-repo-check','--json','--color','never','--sandbox','read-only','-c','approval_policy="never"','-c',`mcp_servers.fleet.command=${JSON.stringify(process.execPath)}`,'-c',`mcp_servers.fleet.args=${JSON.stringify(mcp.fleet.args)}`,'-c',`mcp_servers.fleet.env=${tomlMap(mcp.fleet.env)}`,'-c','mcp_servers.fleet.default_tools_approval_mode="approve"','-c','mcp_servers.fleet.startup_timeout_sec=30','-c','mcp_servers.fleet.tool_timeout_sec=120','-o',output];
  // Inherit the user's selected model while excluding unrelated global MCPs.
  const cfg=fs.existsSync(path.join(os.homedir(),'.codex/config.toml'))?fs.readFileSync(path.join(os.homedir(),'.codex/config.toml'),'utf8'):'';
  const model=cfg.match(/^model\s*=\s*"([^"]+)"/m)?.[1];if(model)args.push('-m',model);
  const effort=cfg.match(/^model_reasoning_effort\s*=\s*"([^"]+)"/m)?.[1];if(effort)args.push('-c',`model_reasoning_effort=${JSON.stringify(effort)}`);
  args.push(taskPrompt(job,fleet));return args;
}
function tomlMap(obj){return '{ '+Object.entries(obj).map(([k,v])=>`${k} = ${JSON.stringify(v)}`).join(', ')+' }';}
async function runCli({job,fleet,handle,onEvent}){
  const output=path.join(DATA,'jobs',job.id+'-result.txt');fs.mkdirSync(path.dirname(output),{recursive:true,mode:0o700});
  const env={...process.env};for(const k of ['CODEX_THREAD_ID','CODEX_SESSION_ID','CODEX_CI'])delete env[k];
  const workspace=path.join(DATA,'workspaces',job.profileId);
  return new Promise((resolve,reject)=>{
    const child=spawn(executable(job.provider),cliArgs(job,fleet,output),{cwd:workspace,env,stdio:['ignore','pipe','pipe']});handle.process=child;
    let stdout='',stderr='',final='',lineBuffer='';
    child.stdout.on('data',chunk=>{
      const str=chunk.toString();stdout=(stdout+str).slice(-30000);lineBuffer+=str;let n;
      while((n=lineBuffer.indexOf('\n'))>=0){const line=lineBuffer.slice(0,n);lineBuffer=lineBuffer.slice(n+1);let event;try{event=JSON.parse(line);}catch{continue;}
        if(event.type==='item.completed'&&event.item?.type==='agent_message')final=event.item.text;
        if(event.type==='result')final=event.result||final;
        const type=event.item?.type||event.type;const message=event.item?.text||event.item?.tool||event.message||event.error?.message||type;
        if(!['thread.started','turn.started'].includes(type))onEvent(type,String(message).slice(0,6000));
      }
    });
    child.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-12000);});
    child.on('error',reject);
    child.on('exit',code=>{
      handle.process=null;if(code!==0)return reject(Error(`AI 执行程序退出 (${code})：${stderr.slice(-1800)||stdout.slice(-1800)}`));
      if(!job.actions?.length)return reject(Error('AI 没有通过此环境的插件执行任何浏览器操作，任务未验收。'));
      if(fs.existsSync(output))final=fs.readFileSync(output,'utf8');
      resolve(final||'任务已执行，详见插件操作记录。');
    });
  });
}
async function modelRequest(url,body,headers,signal){
  const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body),signal});
  const value=await r.json();if(!r.ok)throw Error(`模型 API ${r.status}：${value.error?.message||value.message||'请求失败'}`);return value;
}
async function runApi({job,fleet,handle,onEvent,credentials}){
  const spec=providerStatus(fleet.credentials).find(x=>x.id===job.provider);const base=spec.baseUrl.replace(/\/$/,'');
  const instruction=taskPrompt(job,fleet),messages=[{role:'user',content:instruction}];
  for(let step=0;step<30;step++){
    handle.abort.signal.throwIfAborted();onEvent('thinking',`模型正在决定第 ${step+1} 步操作…`);
    if(job.provider==='anthropic'){
      const reply=await modelRequest(base+'/v1/messages',{model:credentials.model,max_tokens:4096,messages,tools:apiTools.map(t=>({name:t.function.name,description:t.function.description,input_schema:t.function.parameters}))},{'x-api-key':credentials.apiKey,'anthropic-version':'2023-06-01'},handle.abort.signal);
      messages.push({role:'assistant',content:reply.content});const calls=reply.content.filter(x=>x.type==='tool_use');
      if(!calls.length){if(!job.actions?.length)throw Error('模型未执行浏览器工具。');return reply.content.filter(x=>x.type==='text').map(x=>x.text).join('\n');}
      const results=[];for(const call of calls){const result=await useTool(call.name,call.input,{job,fleet,handle,onEvent});results.push({type:'tool_result',tool_use_id:call.id,content:JSON.stringify(result)});}messages.push({role:'user',content:results});
    }else{
      const reply=await modelRequest(base+'/chat/completions',{model:credentials.model,messages,tools:apiTools,tool_choice:'auto'},{Authorization:'Bearer '+credentials.apiKey},handle.abort.signal);
      const msg=reply.choices?.[0]?.message;if(!msg)throw Error('模型响应没有 message。');messages.push(msg);
      if(!msg.tool_calls?.length){if(!job.actions?.length)throw Error('模型未执行浏览器工具；请使用支持工具调用的模型。');return msg.content||'任务结束。';}
      for(const call of msg.tool_calls){let input;try{input=JSON.parse(call.function.arguments);}catch{input={};}const result=await useTool(call.function.name,input,{job,fleet,handle,onEvent});messages.push({role:'tool',tool_call_id:call.id,content:JSON.stringify(result)});}
    }
  }
  throw Error('任务达到 30 步操作上限，请拆分任务后重试。');
}
async function useTool(name,args,{job,fleet,handle,onEvent}){
  handle.abort.signal.throwIfAborted();if(!actionDefinitions.some(x=>x[0]===name))return {error:'未知工具'};
  onEvent('tool',`插件执行 ${name}`);
  try{return await fleet.command(job.profileId,name,args,{owner:job.id,controller:providerStatus(fleet.credentials).find(x=>x.id===job.provider).name,background:job.background});}catch(e){return {error:e.message};}
}
export async function runAgent(options){return ['codex','claude-cli'].includes(options.job.provider)?runCli(options):runApi(options);}
