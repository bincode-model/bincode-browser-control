import fs from 'node:fs';
import path from 'node:path';
import {DATA,loadJSON} from './store.mjs';
export async function api(route,body){
  const cfg=loadJSON(path.join(DATA,'fleet.json'),{port:17410});const token=fs.readFileSync(path.join(DATA,'admin-token'),'utf8').trim();
  const r=await fetch(`http://127.0.0.1:${cfg.port}${route}`,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},...(body!==undefined?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(120000)});
  const value=await r.json();if(!r.ok)throw Error(value.error||`HTTP ${r.status}`);return value;
}
