#!/bin/sh
set -eu
fleet_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$fleet_root/runtime/node/bin/node" "$fleet_root/scripts/portable/connect-codex.mjs" "$@"
