#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -x runtime/node/bin/node ]; then export PATH="$PWD/runtime/node/bin:$PATH"; fi
node --input-type=module <<'JS'
import fs from 'node:fs';
import path from 'node:path';
import {DATA} from './src/store.mjs';
import {api} from './src/client.mjs';
const health=await fetch('http://127.0.0.1:'+JSON.parse(fs.readFileSync(path.join(DATA,'fleet.json'))).port+'/health').then(r=>r.json());
if(health.pid!==Number(fs.readFileSync(path.join(DATA,'server.pid'),'utf8'))||health.profiles!==140)throw Error('进程身份不匹配，未停止');
await api('/api/emergency-stop',{});process.kill(health.pid,'SIGTERM');console.log('已停止后台，浏览器环境数据保留。');
JS
