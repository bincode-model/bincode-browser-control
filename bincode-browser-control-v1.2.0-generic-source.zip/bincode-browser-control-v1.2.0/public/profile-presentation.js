export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));

export function profileNumber(profile) {
  return Number(profile.number || profile.id?.slice(4));
}

export function browserLabel(profile) {
  return `浏览器 ${String(profileNumber(profile)).padStart(3, '0')}`;
}

export function profileName(profile) {
  return profile.name?.trim() || browserLabel(profile);
}

export function sortProfiles(profiles) {
  return [...profiles].sort((a, b) => profileNumber(a) - profileNumber(b));
}

export function selectedProfileIds(profiles, ids) {
  const selected = new Set(ids);
  return sortProfiles(profiles).filter(profile => selected.has(profile.id)).map(profile => profile.id);
}

export function profileSearchText(profile) {
  return [profile.id, browserLabel(profile), profileName(profile), profile.entryUrl, profile.remark].join(' ').toLowerCase();
}

export function profileEntryHost(profile) {
  if (!profile.entryUrl) return '本机起始页';
  return URL.canParse(profile.entryUrl) ? new URL(profile.entryUrl).hostname : '入口网址无效';
}

export async function startProfilesInOrder(profiles, ids, start) {
  const ordered = selectedProfileIds(profiles, ids);
  const opened = [];
  for (const [index, profileId] of ordered.entries()) {
    try {
      await start(profileId);
      opened.push(profileId);
    } catch (error) {
      return {opened, failed: {profileId, error}, remaining: ordered.slice(index + 1)};
    }
  }
  return {opened, remaining: []};
}
