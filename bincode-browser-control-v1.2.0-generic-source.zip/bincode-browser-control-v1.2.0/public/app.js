import {escapeHTML, browserLabel, profileName, profileNumber, sortProfiles, selectedProfileIds, profileSearchText, profileEntryHost, startProfilesInOrder} from './profile-presentation.js';
let state,view='environments',showAllJobs=false,editing=null,editingProvider=null,jobDetailId=null,settingsLoaded=false,sortDir=1,lastMatrix='',lastRows='';
const selected=new Set();
const $=s=>document.querySelector(s);
const esc=escapeHTML;
const TZ='Asia/Shanghai';
const statuses={stopped:'已关闭',starting:'正在启动',idle:'插件在线',reserved:'等待 AI 指令',controlling:'AI 控制中',disconnected:'插件断线',reconnecting:'重新连接',error:'启动失败'};
const jobStatuses={queued:'排队中',starting:'启动中',running:'运行中',succeeded:'已完成',failed:'失败',cancelled:'已取消',interrupted:'已中断',waiting_login:'待本人登录',needs_input:'待补充范围',needs_review:'待核验'};
const pad3=n=>String(n).padStart(3,'0');
// Browsers opened by an MCP process are not children of this console, so a
// live plugin connection or measured memory also counts as running.
const isRunning=p=>!!(p.pid||p.connected||p.memoryMB>0);
function fmtFull(iso){return new Date(iso).toLocaleString('zh-CN',{timeZone:TZ,hour12:false});}
function fmtTime(iso){return new Date(iso).toLocaleTimeString('zh-CN',{timeZone:TZ,hour12:false});}
function message(text,error=false){const box=$(error?'#error':'#notice');box.textContent=text;box.classList.remove('hidden');if(!error)setTimeout(()=>box.classList.add('hidden'),8000);}
async function api(route,body){const r=await fetch('/api/'+route,{method:body===undefined?'GET':'POST',headers:{'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const data=await r.json();if(!r.ok)throw Error(data.error);return data;}
async function action(button,fn){$('#error').classList.add('hidden');if(button)button.disabled=true;try{return await fn();}catch(e){message(e.message,true);}finally{if(button)button.disabled=false;}}
const TITLES={environments:'浏览器环境',jobs:'任务队列',providers:'AI 控制器',settings:'运行设置'};
const SUBTITLES={jobs:'独立环境各自执行任务，记录插件实际操作和结果。',providers:'为每个浏览器环境选择 AI，支持本机登录或模型 API。',settings:'按电脑实际负载调整并发，环境数据永久保存。'};
function envSubtitle(){
  if(!state)return '正在读取…';
  const running=state.profiles.filter(isRunning).length;
  const mode=state.settings.browserNetworkMode==='system'?'跟随系统':'直连';
  return `${state.profiles.length} 个浏览器 · ${running} 个运行中 · 下次启动：${mode}`;
}
function switchView(next){view=next;document.querySelectorAll('.view').forEach(el=>el.classList.toggle('hidden',el.id!=='view-'+next));document.querySelectorAll('.nav').forEach(el=>el.classList.toggle('active',el.dataset.view===next));$('#page-title').textContent=TITLES[next];$('#page-subtitle').textContent=next==='environments'?envSubtitle():SUBTITLES[next];if(next==='jobs')renderJobs();}
function providerLabel(id){return state.providers.find(p=>p.id===id)?.name||id;}
function shownProfiles(){
  const query=$('#search').value.trim().toLowerCase();
  const number=(query.match(/^浏览器\s*0*(\d+)$/)||query.match(/^0*(\d{1,3})$/))?.[1];
  const status=$('#status-filter').value;
  const filters={
    running:isRunning,
    connected:p=>p.connected,
    controlling:p=>!!p.controller,
    disconnected:p=>isRunning(p)&&!p.connected,
    stopped:p=>!isRunning(p),
    retained:p=>(state.settings.retainedProfileIds||[]).includes(p.id)
  };
  const matches=sortProfiles(state.profiles).filter(p=>
    (!filters[status]||filters[status](p)) &&
    (number ? profileNumber(p)===Number(number) : !query||profileSearchText(p).includes(query))
  );
  return sortDir<0?matches.reverse():matches;
}
function resetPage(){const ids=new Set(shownProfiles().map(p=>p.id));for(const id of [...selected])if(!ids.has(id))selected.delete(id);renderProfiles();}
function setStatusFilter(value){$('#status-filter').value=value;resetPage();}
function renderKpis(){
  const status=$('#status-filter').value;
  const tiles=[
    ['','浏览器环境',state.profiles.length,''],
    ['running','运行中',state.profiles.filter(isRunning).length,`/ ${state.settings.maxBrowsers} 上限`],
    ['connected','插件在线',state.profiles.filter(p=>p.connected).length,''],
    ['controlling','AI 控制中',state.profiles.filter(p=>p.controller).length,'']
  ];
  $('#kpis').innerHTML=tiles.map(([key,label,value,unit])=>`<button class="kpi ${status===key?'active':''}" data-filter="${key}" aria-pressed="${status===key}"><span class="label">${label}</span><span class="value">${value}${unit?`<small>${unit}</small>`:''}</span></button>`).join('');
}
function memoryText(){
  const mb=state.resources.fleetMemoryMB||0;
  return mb>1024?(mb/1024).toFixed(1)+' GB':mb+' MB';
}
function renderMatrix(shown){
  const visible=new Set(shown.map(p=>p.id));
  const groups=new Map();
  for(const profile of sortProfiles(state.profiles)){
    if(!groups.has(profile.group))groups.set(profile.group,[]);
    groups.get(profile.group).push(profile);
  }
  const html=[...groups].map(([group,profiles])=>`<div class="ov-row"><div class="ov-label"><b>第 ${Number(group)} 组</b><span>${profiles.length} 个</span></div><div class="cells">${profiles.map(p=>{
    const label=`${browserLabel(p)}，${profileName(p)}，${statuses[p.status]||p.status}`;
    return `<button class="cell s-none${isRunning(p)?' is-run':''}${p.controller?' is-ai':''}${visible.has(p.id)?'':' dim'}${selected.has(p.id)?' picked':''}" data-matrix="${p.id}" aria-label="${esc(label)}">${profileNumber(p)}</button>`;
  }).join('')}</div></div>`).join('');
  if(html!==lastMatrix){$('#matrix').innerHTML=html;lastMatrix=html;}
}
function rowHTML(p){
  const name=profileName(p);
  const job=state.jobs.findLast(j=>j.profileId===p.id);
  const control=p.userStopped?'用户已停止控制':p.controller?(p.controlMode==='standby'?'AI 调试已连接 · 待命':p.controller+' 执行中'):statuses[p.status]||p.status;
  const runClass=p.controller?'busy':p.connected?'online':isRunning(p)?'warn':'off';
  return `<tr id="row-${p.id}" class="${selected.has(p.id)?'selected-row':''}">
<td class="checkbox-col"><input type="checkbox" data-select="${p.id}" aria-label="选择 ${esc(name)}" ${selected.has(p.id)?'checked':''}></td>
<td class="num">${pad3(profileNumber(p))}</td>
<td><span class="env-name">${esc(name)}</span><span class="env-id entry-url" title="${esc(p.entryUrl||'')}">${esc(profileEntryHost(p))}</span>${p.remark?`<span class="env-id">${esc(p.remark)}</span>`:''}</td>
<td class="run-cell"><span class="run ${runClass}"><i class="d"></i>${esc(control)}</span><span class="env-id">${p.memoryMB?p.memoryMB+' MB':''}${p.controlProof?(p.memoryMB?' · ':'')+'读取回执 '+fmtTime(p.controlProof.checkedAt):''}</span>${p.error?`<span class="env-id warning">${esc(p.error)}</span>`:''}</td>
<td class="job">${job?`<span class="status ${job.status==='failed'?'failed':['running','starting'].includes(job.status)?'busy':job.status==='succeeded'?'online':''}">${jobStatuses[job.status]||esc(job.status)}</span><span class="task-brief" title="${esc(job.prompt)}">${esc(job.prompt)}</span><span class="env-id">第 ${job.batchIndex||job.group}/${job.batchCount||'—'} 批 · ${esc(providerLabel(job.provider).split(' · ')[0])}</span>`:'<span class="env-id">暂无任务</span>'}</td>
<td><div class="row-actions"><button data-launch="${p.id}" ${p.status==='starting'?'disabled':''}>${p.pid?'关闭':p.connected?'重新核验':'启动'}</button>${p.pid?`<button data-connect="${p.id}">重新核验</button>`:''}<button data-edit="${p.id}" class="text-button">设置</button></div></td></tr>`;
}
function renderProfiles(){
  if(!state)return;
  const shown=shownProfiles();
  renderKpis();renderMatrix(shown);
  const rows=shown.length?shown.map(rowHTML).join(''):'<tr><td colspan="6" class="empty">没有匹配的浏览器。</td></tr>';
  if(rows!==lastRows){$('#profile-rows').innerHTML=rows;lastRows=rows;}
  $('#filtered-count').textContent=`显示 ${shown.length} / ${state.profiles.length}`;
  $('#selected-count').textContent=`已选 ${selected.size} 个`;
  $('#selbar').classList.toggle('show',selected.size>0);
  $('#select-group').checked=shown.length>0&&shown.every(p=>selected.has(p.id));
  $('#select-group').indeterminate=shown.some(p=>selected.has(p.id))&&!$('#select-group').checked;
  $('#task-info').textContent=`已选 ${selected.size} 个，按编号每批最多 10 个；同时最多 ${state.settings.maxAgents} 个 AI 任务、${state.settings.maxBrowsers} 个浏览器。待登录、失败和待核验不计为完成。`;
}
function renderJobs(){
  if(!state)return;const jobs=state.jobs.filter(j=>showAllJobs||['queued','starting','running','waiting_login','needs_input','needs_review','failed','interrupted'].includes(j.status)).slice().reverse();
  $('#job-list').innerHTML=jobs.length?jobs.map(j=>`<div class="job-row"><div><strong>${j.profileId}</strong><br><span class="env-id">第 ${j.group} 组 · ${esc(j.provider)}</span></div><span class="status ${j.status==='failed'?'failed':['running','starting'].includes(j.status)?'busy':j.status==='succeeded'?'online':''}">${jobStatuses[j.status]}</span><p>${esc(j.prompt)}</p><span class="job-time env-id">${fmtFull(j.createdAt)}</span><div class="job-actions"><button data-detail="${j.id}">详情</button>${['queued','starting','running'].includes(j.status)?`<button data-cancel="${j.id}">取消</button>`:['failed','interrupted','cancelled','waiting_login','needs_input','needs_review'].includes(j.status)?`<button data-retry="${j.id}">重试</button>`:''}</div></div>`).join(''):'<div class="empty">暂无'+(showAllJobs?'任务':'进行中或待处理任务')+'。在浏览器环境中选择环境并提交任务。</div>';
  const latest=state.jobs.at(-1),batch=latest?state.jobs.filter(j=>j.batchId===latest.batchId):[];
  const count=status=>batch.filter(j=>status.includes(j.status)).length;
  $('#batch-summary').innerHTML=batch.length?`<span>最近一轮 <strong>${batch.length}</strong> 家</span><span>已完成 <strong>${count(['succeeded'])}</strong></span><span>执行 / 排队 <strong>${count(['queued','starting','running'])}</strong></span><span>待登录 / 补充 / 核验 <strong>${count(['waiting_login','needs_input','needs_review'])}</strong></span><span>失败 / 中断 <strong>${count(['failed','interrupted','cancelled'])}</strong></span>`:'尚无批次任务';
  $('#pause-queue').textContent=state.paused?'继续队列':'暂停队列';
}
function updateState(next){
  state=next;$('#connection').textContent='本机控制台已连接';
  $('#nav-queued').textContent=state.jobs.filter(j=>['queued','running','starting'].includes(j.status)).length;
  const retained=state.settings.retainedProfileIds||[];
  const retainedOption=$('#status-filter option[value="retained"]');if(retainedOption)retainedOption.textContent=`本次保留（${retained.length} 个）`;
  $('#environment-count').textContent=state.profiles.length;
  $('#brand-count').textContent=`${state.profiles.length} 个独立浏览器环境`;
  $('#side-resources').textContent=`${state.profiles.filter(isRunning).length} 个浏览器运行 · 内存 ${memoryText()}`;
  if(view==='environments')$('#page-subtitle').textContent=envSubtitle();
  document.title=`bincode多浏览器控制 · ${state.profiles.length} 个浏览器环境`;
  renderProfiles();renderJobs();
  const options=state.providers.map(p=>`<option value="${p.id}">${esc(p.name)}${p.ready?'':'（未配置）'}</option>`).join('');
  for(const id of ['#task-provider','#edit-provider']){const el=$(id);if(el.dataset.options!==options){const old=el.value;el.innerHTML=(id==='#task-provider'?'<option value="">使用各环境自己的设置</option>':'')+options;el.value=old;el.dataset.options=options;}}
  $('#provider-list').innerHTML=state.providers.map(p=>`<div class="provider-row"><div class="provider-copy"><h3>${esc(p.name)}</h3><p>${esc(p.note)}${p.model?' · '+esc(p.model):''}</p></div><span class="status ${p.ready?'online':''}">${p.ready?'可使用':'待配置'}</span>${p.kind==='api'?`<button data-provider="${p.id}">配置</button>`:''}</div>`).join('');
  if(!settingsLoaded){$('#max-browsers').value=state.settings.maxBrowsers;$('#max-agents').value=state.settings.maxAgents;$('#auto-close').checked=state.settings.autoClose;$('#task-timeout').value=state.settings.taskTimeoutMinutes;settingsLoaded=true;}
  $('#machine-info').textContent=`${state.resources.totalMemoryGB.toFixed(0)} GB 内存 · ${state.resources.cpuCount} 核 CPU · 浏览器进程占用 ${state.resources.fleetMemoryMB} MB · 已打开 ${state.resources.activeBrowsers} 个环境`;
  $('#chrome-path').textContent=state.settings.chrome||'尚未找到兼容的 Chrome 或 Chromium。';
  $('#network-mode').textContent=state.settings.browserNetworkMode==='system'?'跟随系统':'直连';
  $('#network-system').disabled=state.settings.browserNetworkMode==='system';
}

// ---- drawers & tooltip ----
function openDrawer(id){$('#scrim').classList.add('show');$(id).classList.add('show');}
function closeDrawers(){$('#scrim').classList.remove('show');$('#task-drawer').classList.remove('show');$('#profile-editor').classList.remove('show');editing=null;}
function hideTip(){$('#tip').classList.remove('show');}
function showTip(cell){
  const p=state.profiles.find(x=>x.id===cell.dataset.matrix);if(!p)return;
  const tip=$('#tip');
  tip.innerHTML=`<b>${esc(profileName(p))}</b><div class="r">运行<i>${esc(statuses[p.status]||p.status)}</i></div><div class="r">入口<i>${esc(profileEntryHost(p))}</i></div><div class="r muted">点击定位到列表</div>`;
  const r=cell.getBoundingClientRect();tip.classList.add('show');
  tip.style.left=Math.max(8,Math.min(window.innerWidth-tip.offsetWidth-8,r.left))+'px';
  tip.style.top=(r.bottom+8+tip.offsetHeight>window.innerHeight?r.top-tip.offsetHeight-8:r.bottom+8)+'px';
}
function locate(id){
  if(!shownProfiles().some(p=>p.id===id)){$('#search').value='';$('#status-filter').value='';renderProfiles();}
  const row=$('#row-'+id);if(!row)return;row.scrollIntoView({block:'center',behavior:'smooth'});row.classList.remove('flash');void row.offsetWidth;row.classList.add('flash');
}

// ---- events ----
document.querySelectorAll('.nav').forEach(el=>el.onclick=()=>switchView(el.dataset.view));
document.querySelectorAll('.close-drawer').forEach(el=>el.onclick=closeDrawers);
document.querySelector('th.sortable').onclick=e=>{sortDir=-sortDir;e.currentTarget.dataset.dir=sortDir>0?'asc':'desc';renderProfiles();};
$('#scrim').onclick=closeDrawers;
$('#search').oninput=resetPage;
$('#status-filter').onchange=resetPage;
$('#kpis').onclick=e=>{const b=e.target.closest('[data-filter]');if(b)setStatusFilter($('#status-filter').value===b.dataset.filter?'':b.dataset.filter);};
$('#matrix').onclick=e=>{const b=e.target.closest('[data-matrix]');if(!b)return;const id=b.dataset.matrix;if(e.metaKey||e.shiftKey||e.ctrlKey){selected.has(id)?selected.delete(id):selected.add(id);renderProfiles();return;}hideTip();locate(id);};
$('#matrix').onmouseover=e=>{const b=e.target.closest('[data-matrix]');b?showTip(b):hideTip();};
$('#matrix').onmouseleave=hideTip;
$('#select-group').onchange=e=>{shownProfiles().forEach(p=>e.target.checked?selected.add(p.id):selected.delete(p.id));renderProfiles();};
$('#clear-selection').onclick=()=>{selected.clear();renderProfiles();};
$('#profile-rows').onchange=e=>{const id=e.target.dataset.select;if(id){e.target.checked?selected.add(id):selected.delete(id);renderProfiles();}};
$('#profile-rows').onclick=e=>{
  const launch=e.target.closest('[data-launch]');
  if(launch){
    const p=state.profiles.find(p=>p.id===launch.dataset.launch);
    action(launch,async()=>{await api(p.pid?'stop':'start',{profileId:p.id});message(p.pid?'环境已关闭。':`${browserLabel(p)} 已启动，插件已连接。`);});
  }
  const reconnect=e.target.closest('[data-connect]');
  if(reconnect)action(reconnect,async()=>{await api('start',{profileId:reconnect.dataset.connect});message('已重新核验插件与调试连接。');});
  const edit=e.target.closest('[data-edit]');
  if(edit){
    editing=edit.dataset.edit;
    const p=state.profiles.find(p=>p.id===editing);
    $('#edit-id').textContent=browserLabel(p);
    $('#edit-name').value=profileName(p);
    $('#edit-remark').value=p.remark||'';
    $('#edit-provider').value=p.provider;
    $('#edit-url').value=p.entryUrl;
    $('#edit-extensions').value=p.extraExtensions.join('\n');
    $('#edit-path').textContent='独立数据：'+p.userDataDir;
    openDrawer('#profile-editor');
    $('#edit-name').focus();
  }
};
$('#save-profile').onclick=e=>action(e.target,async()=>{
  await api('profile',{profileId:editing,name:$('#edit-name').value,remark:$('#edit-remark').value,provider:$('#edit-provider').value,entryUrl:$('#edit-url').value,extraExtensions:$('#edit-extensions').value.split('\n').map(x=>x.trim()).filter(Boolean)});
  closeDrawers();
  message('环境设置已保存。');
});
$('#open-task').onclick=()=>{
  const ids=selectedProfileIds(state.profiles,selected);
  $('#picked').innerHTML=ids.map(id=>`<span class="tag">${esc(profileName(state.profiles.find(p=>p.id===id)))}</span>`).join('');
  openDrawer('#task-drawer');
  $('#task-prompt').focus();
};
async function submitJobs(ids){
  if(!ids.length)throw Error('请先选择浏览器。');
  const prompt=$('#task-prompt').value.trim();if(!prompt)throw Error('请输入要执行的任务。');
  const jobs=await api('jobs',{profileIds:selectedProfileIds(state.profiles,ids),prompt,provider:$('#task-provider').value||undefined,background:$('#background').checked});
  closeDrawers();message(`${jobs.length} 个任务已入队，按每批最多 10 个依次执行。`);switchView('jobs');
}
$('#submit-task').onclick=e=>action(e.target,()=>submitJobs([...selected]));
$('#start-selected').onclick=e=>action(e.target,async()=>{
  if(!selected.size)throw Error('请先选择浏览器。');
  const ids=selectedProfileIds(state.profiles,selected),newIds=ids.filter(id=>!isRunning(state.profiles.find(p=>p.id===id)));
  const slots=Math.max(0,state.settings.maxBrowsers-Math.max(state.resources.activeBrowsers,state.profiles.filter(isRunning).length));
  if(newIds.length>slots)throw Error(`当前还可打开 ${slots} 个，请先关闭空闲浏览器。`);
  const result=await startProfilesInOrder(state.profiles,ids,profileId=>api('start',{profileId,background:false}));
  if(result.failed)throw Error(`${result.failed.profileId}：${result.failed.error.message}。后续 ${result.remaining.length} 个环境未打开。`);
  message(`已按编号启动 ${result.opened.length} 个环境。`);
});
$('#close-idle').onclick=e=>action(e.target,async()=>{const results=await api('close-idle',{});const failures=results.filter(x=>x.status==='rejected').length;message(failures?`关闭空闲环境时有 ${failures} 个错误，请查看环境状态。`:'空闲环境已关闭，Cookie 和登录已保存。',!!failures);});
async function setNetworkMode(mode){
  const result=await api('browser-network',{mode});
  const label=result.mode==='direct'?'直连':'跟随系统';
  $('#network-mode').textContent=label;
  message(`${result.total} 个环境下次启动时${label}。${result.running?`当前 ${result.running} 个运行中或正在启动的环境继续用原方式。`:''}`);
}
$('#network-direct').onclick=e=>action(e.currentTarget,()=>setNetworkMode('direct'));
$('#network-system').onclick=e=>action(e.currentTarget,()=>setNetworkMode('system'));
$('#emergency').onclick=e=>action(e.target,async()=>{await api('emergency-stop',{});message('任务已取消，队列已暂停，AI 控制已释放。');});
$('#pause-queue').onclick=e=>action(e.target,()=>api('pause',{paused:!state.paused}));
$('#filter-active').onclick=()=>{showAllJobs=false;$('#filter-active').classList.add('active');$('#filter-all').classList.remove('active');renderJobs();};
$('#filter-all').onclick=()=>{showAllJobs=true;$('#filter-all').classList.add('active');$('#filter-active').classList.remove('active');renderJobs();};
async function detail(id){jobDetailId=id;const j=await api('jobs/'+id);$('#job-detail').classList.remove('hidden');$('#job-prompt').textContent=j.profileId+' · '+j.prompt;$('#job-events').textContent=(j.events||[]).map(x=>fmtTime(x.time)+' '+x.message).join('\n')||'任务尚未开始。';$('#job-result').textContent=j.result||j.error||'等待执行结果。';const names=[...new Set((j.result||'').match(/env-\d{3}-\d+-[a-f\d]+\.png/g)||[])];$('#job-artifacts').innerHTML=names.map(name=>`<figure><img src="/api/artifacts/${name}" alt="${esc(j.profileId)} 的插件操作截图" loading="lazy"><figcaption>${esc(name)}</figcaption></figure>`).join('');}
$('#job-list').onclick=e=>{const d=e.target.closest('[data-detail]'),c=e.target.closest('[data-cancel]'),r=e.target.closest('[data-retry]');if(d)action(d,()=>detail(d.dataset.detail));if(c)action(c,()=>api('cancel',{jobId:c.dataset.cancel}));if(r)action(r,()=>api('retry',{jobId:r.dataset.retry}));};
$('#provider-list').onclick=e=>{const b=e.target.closest('[data-provider]');if(!b)return;editingProvider=b.dataset.provider;const p=state.providers.find(p=>p.id===editingProvider);$('#provider-form').classList.remove('hidden');$('#provider-form-title').textContent=p.name;$('#api-base').value=p.baseUrl;$('#api-model').value=p.model;$('#api-key').value='';$('#api-model').focus();};
$('#save-provider').onclick=e=>action(e.target,async()=>{const config={baseUrl:$('#api-base').value.trim(),model:$('#api-model').value.trim()};if($('#api-key').value.trim())config.apiKey=$('#api-key').value.trim();await api('provider',{provider:editingProvider,config});$('#api-key').value='';message('AI 控制器配置已保存。');});
$('#settings-form').onsubmit=e=>{e.preventDefault();action($('#settings-form button'),async()=>{await api('settings',{maxBrowsers:+$('#max-browsers').value,maxAgents:+$('#max-agents').value,autoClose:$('#auto-close').checked,taskTimeoutMinutes:+$('#task-timeout').value});message('运行设置已保存。');});};
const events=new EventSource('/api/events');events.addEventListener('state',event=>{try{updateState(JSON.parse(event.data));}catch(e){message('界面更新失败：'+e.message,true);}});events.addEventListener('job',event=>{const data=JSON.parse(event.data);if(data.jobId===jobDetailId)detail(jobDetailId).catch(()=>{});});events.onerror=()=>{$('#connection').textContent='连接中断，正在重连…';};
api('state').then(updateState).catch(e=>message(e.message,true));
