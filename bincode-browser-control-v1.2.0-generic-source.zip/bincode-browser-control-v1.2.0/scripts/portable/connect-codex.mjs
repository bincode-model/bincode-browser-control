import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {ROOT,DATA} from '../../src/store.mjs';
import {connection,serverName,writeMcpConfigs} from './mcp-config.mjs';
if(!fs.existsSync(path.join(DATA,'fleet.json')))throw Error('请先安装并启动控制台。');
writeMcpConfigs();
const c=connection(),cli=path.join(ROOT,'scripts/portable/codex.sh');
const read=spawnSync(cli,['mcp','list','--json'],{encoding:'utf8',timeout:30000});
if(read.status!==0)throw Error('无法读取 Codex MCP 配置：'+read.stderr);
const existing=JSON.parse(read.stdout).find(x=>x.name===serverName);
if(existing){
  const t=existing.transport||existing;
  const same=t.command===c.command&&JSON.stringify(t.args)===JSON.stringify(c.args)&&t.env?.FLEET_DATA_DIR===DATA;
  if(!same)throw Error('已有同名 MCP 指向其他目录，未覆盖。请在 Codex 设置中核对 '+serverName+'，再导入本目录 data/mcp-config-codex.toml。');
  console.log('本控制台的 MCP 已接入；请在 Codex 中重启连接。');
}else{
  const args=['mcp','add',serverName];
  for(const [k,v]of Object.entries(c.env))args.push('--env',k+'='+v);
  args.push('--',c.command,...c.args);
  const added=spawnSync(cli,args,{stdio:'inherit',timeout:30000});
  if(added.status!==0)throw Error('MCP 添加未完成。');
  console.log('已添加本机 MCP：'+serverName+'。请先启动控制台，再在 Codex 的 MCP 设置中重启连接。');
}
