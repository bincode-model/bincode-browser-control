import fs from 'node:fs';
import path from 'node:path';
import {ROOT,DATA} from '../../src/store.mjs';
export const serverName='shop_browser_fleet';
export function connection(profileId){
  if(profileId&&!/^env-\d{3}$/.test(profileId))throw Error('无效环境编号');
  return {command:process.execPath,args:[path.join(ROOT,'src/mcp.mjs'),...(profileId?['--profile',profileId]:[])],env:{FLEET_DATA_DIR:DATA,FLEET_CONTROLLER:'AI Agent'},startup_timeout_sec:30,tool_timeout_sec:120};
}
function toml(name,c){
  return `[mcp_servers.${name}]\ncommand = ${JSON.stringify(c.command)}\nargs = ${JSON.stringify(c.args)}\nstartup_timeout_sec = 30\ntool_timeout_sec = 120\n[mcp_servers.${name}.env]\n`+Object.entries(c.env).map(([k,v])=>k+' = '+JSON.stringify(v)+'\n').join('');
}
export function writeMcpConfigs(){
  fs.mkdirSync(DATA,{recursive:true,mode:0o700});
  const c=connection(),one=connection('env-001');
  const files={'mcp-config.json':JSON.stringify({mcpServers:{[serverName]:c}},null,2)+'\n','mcp-config-codex.toml':toml(serverName,c),'mcp-env-001.json':JSON.stringify({mcpServers:{shop_browser_001:one}},null,2)+'\n','mcp-env-001.toml':toml('shop_browser_001',one)};
  for(const [name,value] of Object.entries(files))fs.writeFileSync(path.join(DATA,name),value,{mode:0o600});
  return Object.keys(files).map(name=>path.join(DATA,name));
}
