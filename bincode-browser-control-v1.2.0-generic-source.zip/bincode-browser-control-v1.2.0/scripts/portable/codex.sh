#!/bin/sh
set -eu
fleet_root=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
export PATH="$fleet_root/runtime/node/bin:$PATH"
exec "$fleet_root/runtime/node/bin/node" "$fleet_root/runtime/codex/bin/codex.js" "$@"
