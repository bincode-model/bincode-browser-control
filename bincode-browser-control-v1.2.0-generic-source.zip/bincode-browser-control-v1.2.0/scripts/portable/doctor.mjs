import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findChrome,ROOT,DATA,initStore} from '../../src/store.mjs';
import {providerStatus} from '../../src/providers.mjs';
import {writeMcpConfigs} from './mcp-config.mjs';
if(Number(process.versions.node.split('.')[0])<22)throw Error('需要 Node.js 22 或更高版本');
const config=initStore();
const numberedRoot=path.join(ROOT,'runtime','numbered-browsers');
let browser;
if(process.platform==='darwin'&&fs.existsSync(numberedRoot)){
  for(const p of config.profiles)fs.accessSync(path.join(numberedRoot,`浏览器 ${p.id.slice(4)}.app`,'Contents','MacOS','Chromium'),fs.constants.X_OK);
  browser=`${numberedRoot}（140 个独立蓝色 Chromium 浏览器）`;
}else{
  browser=findChrome();if(!browser)throw Error('未找到兼容浏览器。请安装 Chromium，再用 FLEET_CHROME 指定可执行文件。');
  fs.accessSync(browser,fs.constants.X_OK);
}
const mcpConfigs=writeMcpConfigs();
console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,memoryGB:Math.round(os.totalmem()/1024**3),browser,data:DATA,profiles:config.profiles.length,maxBrowsers:config.maxBrowsers,maxAgents:config.maxAgents,mcpConfigs,aiSources:providerStatus({}).filter(p=>p.kind==='cli').map(p=>({name:p.name,installed:p.ready})),next:'启动控制台后在 AI 来源配置自己的 API 或登录自己的 CLI；文件存在不代表已登录。'},null,2));
