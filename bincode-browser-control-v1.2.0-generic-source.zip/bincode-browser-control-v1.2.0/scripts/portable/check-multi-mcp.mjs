import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import assert from 'node:assert/strict';
import {spawn,spawnSync,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const args=process.argv.slice(2),agent=args.includes('--agent');
const value=flag=>{const n=args.indexOf(flag);return n<0?null:args[n+1];};
const count=Number(value('--count')||10);
assert(Number.isInteger(count)&&count>=2&&count<=10,'--count 必须为 2–10');
const runId=new Date().toISOString().replaceAll(':','-')+'-'+crypto.randomBytes(3).toString('hex');
const out=path.resolve(value('--output')||path.join(root,'data','diagnostics',runId));
fs.mkdirSync(out,{recursive:true,mode:0o700});
const cache=path.join(os.homedir(),'Library','Caches','BinCode 浏览器控制台诊断');
fs.mkdirSync(cache,{recursive:true,mode:0o700});
const data=fs.mkdtempSync(path.join(cache,'run-'));
const port=await new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});
process.env.FLEET_DATA_DIR=data;process.env.FLEET_PORT=String(port);
const {initStore,writeJSON}=await import('../../src/store.mjs');
const config=initStore();config.maxBrowsers=10;config.maxAgents=10;config.autoClose=false;config.taskTimeoutMinutes=5;
for(const p of config.profiles)p.entryUrl='http://127.0.0.1:'+port+'/welcome/'+p.id;
writeJSON(path.join(data,'fleet.json'),config);
const token=fs.readFileSync(path.join(data,'admin-token'),'utf8').trim();
const base='http://127.0.0.1:'+port;
const ids=Array.from({length:count},(_,i)=>'env-'+String(i+1).padStart(3,'0'));
const report={version:'1.2.0',startedAt:new Date().toISOString(),runId,platform:process.platform,arch:process.arch,system:execFileSync('/usr/bin/sw_vers',['-productVersion'],{encoding:'utf8'}).trim(),memoryGB:Math.round(os.totalmem()/1024**3),root,isolatedData:data,consolePort:port,requestedVisibleBrowsers:count,usedPersonalProfiles:false,usedExternalWebsites:false,checks:[],agentRequested:agent};
const clients=new Map();let server,interrupted=false;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function record(name,details={}){report.checks.push({name,passed:true,at:new Date().toISOString(),...details});console.log('通过：'+name);}
async function api(route,body){const r=await fetch(base+route,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,'content-type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(100000)});const v=await r.json();if(!r.ok)throw Error(v.error||r.status);return v;}
async function connect(id,background=false){
  const c=new Client({name:'fleet-migration-diagnostic',version:'1.2.0'});
  const env={...process.env,FLEET_DATA_DIR:data,FLEET_OWNER:'diagnostic-'+runId+'-'+id,FLEET_CONTROLLER:'MCP 迁移验收',FLEET_BACKGROUND:String(background)};
  const t=new StdioClientTransport({command:process.execPath,args:[path.join(root,'src/mcp.mjs'),'--profile',id],env,stderr:'pipe'});
  clients.set(id,c);await c.connect(t);
  t.stderr?.on('data',b=>fs.appendFileSync(path.join(out,'mcp-stderr.log'),b,{mode:0o600}));
  const listed=await c.listTools();assert.equal(listed.tools.length,12);assert(!listed.tools.some(x=>x.name==='fleet_run_tasks'));
  return c;
}
async function call(id,name,input={}){
  const r=await clients.get(id).callTool({name,arguments:input},undefined,{timeout:100000});
  const text=r.content.filter(x=>x.type==='text').map(x=>x.text).join('\n');
  if(r.isError)throw Error(id+' '+name+': '+text);
  const v=JSON.parse(text);
  if(name.startsWith('browser_')&&!['browser_tabs','browser_release'].includes(name)){
    assert.equal(v.proof?.profileId,id);assert.equal(v.proof?.debuggerAttached,true);assert(v.proof.extensionId);assert(v.proof.attachedTabs.length>0);
  }
  return v;
}
async function release(id){if(!clients.has(id))return;try{await call(id,'browser_release');}finally{await clients.get(id).close();clients.delete(id);}}
const url=id=>base+'/welcome/'+id;
async function readStorage(id){return (await call(id,'browser_evaluate',{code:'({value:localStorage.getItem("fleet-isolation"),cookie:document.cookie,url:location.href})'})).result;}
function checkStorage(id,r){assert.equal(r.value,runId+'-'+id);assert(r.cookie.split(';').some(x=>x.trim()==='fleet_isolation='+id));assert.equal(r.url,url(id));}
async function writeStorage(id){const expected=runId+'-'+id;await call(id,'browser_evaluate',{code:`(()=>{localStorage.setItem('fleet-isolation',${JSON.stringify(expected)});document.cookie='fleet_isolation=${id}; Path=/; Max-Age=3600; SameSite=Strict';return true})()`});}
async function actualInput(id,label){
  const text='MCP-'+runId+'-'+id;
  await call(id,'browser_fill',{selector:'#test-input',value:text});
  const clicked=await call(id,'browser_click',{selector:'#test-button'});
  assert.equal(clicked.result.activation,'trusted-input');assert.equal(clicked.result.event.trusted,true);
  const state=(await call(id,'browser_evaluate',{code:'({value:document.querySelector("#test-result").textContent,trusted:document.querySelector("#trusted-result").textContent})'})).result;
  assert.equal(state.value,text);assert.equal(state.trusted,'isTrusted=true');
  const shot=await call(id,'browser_screenshot');
  const dest=path.join(out,label+'-'+id+'.png');fs.copyFileSync(shot.result.file,dest);
  return {profileId:id,value:text,clickTrusted:true,proof:clicked.proof,screenshot:path.basename(dest)};
}
async function stop(id){await release(id).catch(()=>{});await api('/api/stop',{profileId:id,force:true});}
async function phaseVisible(){
  console.log(`正在同时启动 ${count} 个可见编号浏览器，仅打开本机验证页…`);
  const starts=await Promise.allSettled(ids.map(profileId=>api('/api/start',{profileId})));
  starts.forEach((s,i)=>{if(s.status==='rejected')throw Error(ids[i]+': '+s.reason.message);});
  for(const id of ids){const ready=await api('/api/state');const p=ready.profiles.find(p=>p.id===id);assert.equal(p.controlMode,'standby');assert.equal(p.controlProof?.debuggerAttached,true);assert.equal(p.controlProof?.url,url(id));assert.equal(p.controller,'控制台（待命）');}
  record('默认启动直达配置入口并自动建立真实调试待命连接');
  for(const id of ids)await connect(id);
  const rows=await Promise.all(ids.map(async id=>{
    const status=await call(id,'fleet_status');assert.equal(status.profiles.length,1);assert.equal(status.profiles[0].id,id);
    const nav=await call(id,'browser_navigate',{url:url(id)});
    const snapshot=await call(id,'browser_snapshot');assert.equal(snapshot.result.url,url(id));assert(snapshot.result.text.includes(id));
    await writeStorage(id);return {id,proof:snapshot.proof};
  }));
  // Inspect all stores after every browser has written; a shared store cannot pass.
  for(const id of ids)checkStorage(id,await readStorage(id));
  const state=await api('/api/state'),active=state.profiles.filter(p=>p.pid);
  assert.equal(active.length,count);assert.equal(new Set(active.map(p=>p.pid)).size,count);assert.equal(new Set(active.map(p=>p.extensionId)).size,count);
  const ps=execFileSync('/bin/ps',['-axo','pid=,command='],{encoding:'utf8'});
  for(const p of active){const line=ps.split('\n').find(l=>l.trim().startsWith(p.pid+' '));assert(line?.includes('--user-data-dir='+path.join(data,'profiles',p.id)));assert(!line.includes('--headless'));}
  record('同时运行的可见独立浏览器、真实 MCP 连接与 Cookie 隔离',{concurrent:active.length,profiles:active.map(p=>({id:p.id,pid:p.pid,extensionId:p.extensionId,userDataDir:p.userDataDir})),readReceipts:rows});
  const denied=await clients.get(ids[0]).callTool({name:'browser_snapshot',arguments:{profileId:ids[1]}});assert.equal(denied.isError,true);assert(denied.content.some(c=>c.type==='text'&&c.text.includes('不允许控制其他环境')));
  record('单环境 MCP 拒绝访问另一编号');
  const actions=[];
  for(const id of ids)actions.push(await actualInput(id,'visible'));
  record('可见浏览器通过 MCP 真实填写、可信点击和截图',{count:actions.length,actions});
  for(const id of ids)await stop(id);
}
async function phasePersistence(){
  const samples=ids.slice(0,2),details=[];
  for(const id of samples){
    await api('/api/start',{profileId:id,connect:false,background:true,initialUrl:url(id)});await connect(id,true);
    await call(id,'browser_navigate',{url:url(id)});checkStorage(id,await readStorage(id));
    details.push(await actualInput(id,'reopened'));await stop(id);
  }
  record('关闭重开后 Cookie 和 localStorage 保留，后台模式 MCP 操作通过',{profiles:samples,actions:details});
}
async function phaseAgent(){
  const cli=path.join(root,'scripts/portable/codex.sh');
  const version=spawnSync(cli,['--version'],{encoding:'utf8',timeout:30000});assert.equal(version.status,0,version.stderr);
  const login=spawnSync(cli,['login','status'],{encoding:'utf8',timeout:30000});assert.equal(login.status,0,'请先运行“登录AI.command”登录你自己的 Codex 账号，再检查 AI 实际操作。');
  const id='env-011',nonce='agent-'+crypto.randomBytes(12).toString('hex');
  await api('/api/start',{profileId:id,connect:false,background:true,initialUrl:url(id)});await connect(id,true);
  await call(id,'browser_navigate',{url:url(id)});
  await call(id,'browser_evaluate',{code:`localStorage.setItem('fleet-agent-challenge',${JSON.stringify(nonce)});true`});
  await release(id);
  const prompt=`这是用户授权的本机安装诊断。只访问 ${url(id)}。用 browser_navigate 打开该页，再 browser_snapshot。通过 browser_evaluate 读取 localStorage.getItem('fleet-agent-challenge')，将读取到的原样字符串用 browser_fill 填到 #test-input，用 browser_click 点击 #test-button，最后用 browser_evaluate 读取 #test-result 和 #trusted-result，报告实际值。禁止用 evaluate 直接填写或模拟点击；只用这个环境的 MCP，不用 shell。`;
  const [created]=await api('/api/jobs',{profileIds:[id],provider:'codex',background:true,prompt});
  console.log('已启动真实 Codex AI agent，通过绑定 MCP 操作本机验证页…');
  const deadline=Date.now()+240000;let job;
  while(Date.now()<deadline){job=await api('/api/jobs/'+created.id);if(!['queued','starting','running'].includes(job.status)&&job.endedAt)break;await pause(1000);if(interrupted)throw Error('诊断已中断');}
  fs.writeFileSync(path.join(out,'agent-job.json'),JSON.stringify(job,null,2),{mode:0o600});
  assert(job.endedAt,'Codex agent 超过诊断时限');assert(!['failed','cancelled','waiting_login'].includes(job.status),job.error||job.status);
  const kinds=new Set(job.actions?.map(x=>x.action));for(const k of ['navigate','snapshot','evaluate','fill','click'])assert(kinds.has(k),'AI 未实际执行 '+k);
  await connect(id,true);
  const final=(await call(id,'browser_evaluate',{code:'({value:document.querySelector("#test-result").textContent,trusted:document.querySelector("#trusted-result").textContent})'})).result;
  assert.equal(final.value,nonce);assert.equal(final.trusted,'isTrusted=true');
  const shot=await call(id,'browser_screenshot');fs.copyFileSync(shot.result.file,path.join(out,'codex-agent.png'));
  record('真实 Codex agent 经 MCP 读取随机值、填写、点击并独立复核',{cli:version.stdout.trim(),profileId:id,jobId:job.id,consoleJobStatus:job.status,independentResult:final,actions:job.actions,screenshot:'codex-agent.png'});
  await stop(id);
}
async function cleanup(){
  for(const id of [...clients.keys()])await release(id).catch(()=>{});
  if(server?.pid){
    await api('/api/emergency-stop',{}).catch(()=>{});
    const state=await api('/api/state').catch(()=>null);
    if(state)for(const p of state.profiles.filter(p=>p.pid))await api('/api/stop',{profileId:p.id,force:true}).catch(()=>{});
    server.kill('SIGTERM');
    for(let n=0;n<70&&server.exitCode===null;n++)await pause(100);
    if(server.exitCode===null)server.kill('SIGKILL');
  }
  const rows=execFileSync('/bin/ps',['-axo','pid=,command='],{encoding:'utf8'}).split('\n').filter(l=>l.includes('--user-data-dir='+data+'/profiles/'));
  report.remainingDiagnosticBrowserProcesses=rows.length;
  if(rows.length){report.passed=false;report.cleanupError='仍有诊断浏览器未退出，保留目录供检查';}
  if(!rows.length&&report.passed&&!args.includes('--keep-data')){fs.rmSync(data,{recursive:true,force:true});report.diagnosticDataRemoved=true;}
  report.finishedAt=new Date().toISOString();
  fs.writeFileSync(path.join(out,'验收报告.json'),JSON.stringify(report,null,2)+'\n',{mode:0o600});
}
process.once('SIGINT',()=>{interrupted=true;});
process.once('SIGTERM',()=>{interrupted=true;});
try{
  const fd=fs.openSync(path.join(out,'server.log'),'a',0o600);
  server=spawn(process.execPath,[path.join(root,'src/server.mjs')],{cwd:root,env:{...process.env,FLEET_DATA_DIR:data,FLEET_PORT:String(port)},stdio:['ignore',fd,fd]});fs.closeSync(fd);
  let health;
  for(let n=0;n<150;n++){try{health=await fetch(base+'/health',{signal:AbortSignal.timeout(1000)}).then(r=>r.json());if(health.pid===server.pid)break;}catch{}await pause(100);}
  assert.equal(health?.pid,server.pid,'独立诊断后台未启动');assert.equal(health.version,'1.2.0');
  await phaseVisible();await phasePersistence();if(agent)await phaseAgent();
  report.passed=true;
}catch(e){report.passed=false;report.error=e.message;report.stack=e.stack;console.error('检查未通过：'+e.message);}
finally{await cleanup();}
console.log('验收报告：'+path.join(out,'验收报告.json'));
if(!report.passed)process.exitCode=1;
