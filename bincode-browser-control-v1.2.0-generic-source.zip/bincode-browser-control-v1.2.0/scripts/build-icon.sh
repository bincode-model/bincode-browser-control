#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
destination=${1:?用法：build-icon.sh 输出.icns 路径}
build_dir=$(mktemp -d "${TMPDIR:-/tmp}/bincode-icon.XXXXXX")
trap 'rm -rf "$build_dir"' EXIT
iconset="$build_dir/bincode.iconset"
mkdir -p "$iconset" "$(dirname "$destination")"
for size in 16 32 128 256 512; do
  /usr/bin/sips -z "$size" "$size" "$root/assets/branding/bincode-logo.png" --out "$iconset/icon_${size}x${size}.png" >/dev/null
  double=$((size * 2))
  /usr/bin/sips -z "$double" "$double" "$root/assets/branding/bincode-logo.png" --out "$iconset/icon_${size}x${size}@2x.png" >/dev/null
done
/usr/bin/iconutil -c icns "$iconset" -o "$destination"
