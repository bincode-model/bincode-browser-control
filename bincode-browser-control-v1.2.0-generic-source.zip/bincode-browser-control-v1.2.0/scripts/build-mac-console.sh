#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
destination=${1:?用法：build-mac-console.sh 输出.app 路径}
mkdir -p "$(dirname "$destination")"
build_dir=$(mktemp -d "$(dirname "$destination")/.fleet-console-build.XXXXXX")
trap 'rm -rf "$build_dir"' EXIT
mkdir -p "$build_dir/app/Contents/MacOS" "$build_dir/app/Contents/Resources"
preferred_sdk=${FLEET_SDK:-$(xcrun --sdk macosx --show-sdk-path)}
built=0
for sdk in "$preferred_sdk" /Library/Developer/CommandLineTools/SDKs/MacOSX*.sdk; do
  [ -d "$sdk" ] || continue
  if /usr/bin/swiftc -sdk "$sdk" -target arm64-apple-macos13.5 -O -framework AppKit -framework WebKit "$root/mac/BrowserFleetConsole.swift" -o "$build_dir/app/Contents/MacOS/BrowserFleetConsole" 2>"$build_dir/compiler.log"; then
    built=1
    echo "使用 SDK：$sdk"
    break
  fi
done
if [ "$built" != 1 ]; then cat "$build_dir/compiler.log"; echo '没有与当前 Swift 编译器匹配的 SDK；原 app 未覆盖。'; exit 1; fi
mkdir -p "$destination/Contents/MacOS" "$destination/Contents/Resources"
cp "$build_dir/app/Contents/MacOS/BrowserFleetConsole" "$destination/Contents/MacOS/BrowserFleetConsole"
"$root/scripts/build-icon.sh" "$destination/Contents/Resources/AppIcon.icns"
cat > "$destination/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDevelopmentRegion</key><string>zh_CN</string>
<key>CFBundleExecutable</key><string>BrowserFleetConsole</string>
<key>CFBundleIdentifier</key><string>local.codex.browser-fleet-console</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>bincode多浏览器控制</string>
<key>CFBundleDisplayName</key><string>bincode多浏览器控制</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.2.0</string>
<key>CFBundleVersion</key><string>20261117</string>
<key>LSMinimumSystemVersion</key><string>13.5</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
printf '%s\n' "$root" > "$destination/Contents/Resources/fleet-path.txt"
/usr/bin/codesign --force --sign - "$destination"
echo "已构建 $destination"
