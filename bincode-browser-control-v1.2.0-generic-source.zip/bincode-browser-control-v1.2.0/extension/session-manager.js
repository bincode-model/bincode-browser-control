/* Adapted from hangwin/mcp-chrome, utils/cdp-session-manager.ts.
 * Copyright (c) 2024 hangye. MIT License (see THIRD_PARTY_NOTICES.md).
 * Changes: plain JavaScript; retain a session until the fleet lease is released;
 * expose forget() for Chrome's detach notification; no temporary auto-attach.
 */
class FleetDebugSessions {
  constructor(){this.sessions=new Map();}
  async attach(tabId){
    const state=this.sessions.get(tabId);
    if(state?.attachedByUs)return;
    const targets=await chrome.debugger.getTargets();
    const existing=targets.find(t=>t.tabId===tabId&&t.attached);
    if(existing){
      if(existing.extensionId===chrome.runtime.id){this.sessions.set(tabId,{attachedByUs:true});return;}
      throw Error('页面已被开发者工具或其他插件占用，请先释放调试连接。');
    }
    await chrome.debugger.attach({tabId},'1.3');
    this.sessions.set(tabId,{attachedByUs:true});
  }
  async detach(tabId){
    const state=this.sessions.get(tabId);if(!state)return;
    try{if(state.attachedByUs)await chrome.debugger.detach({tabId});}
    finally{this.sessions.delete(tabId);}
  }
  forget(tabId){this.sessions.delete(tabId);}
  async sendCommand(tabId,method,params={}){
    if(!this.sessions.get(tabId)?.attachedByUs)throw Error('插件尚未取得此页面的调试控制权。');
    return chrome.debugger.sendCommand({tabId},method,params);
  }
}
const fleetDebugSessions=new FleetDebugSessions();
