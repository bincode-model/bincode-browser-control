chrome.runtime.sendMessage({type:'status'}).then(s=>{
  document.querySelector('#identity').textContent=`${s.profileId} · AI 控制插件`;
  document.querySelector('#status').textContent=s.controller ? (s.controller==='控制台（待命）'?'AI 调试已连接 · 待命':`${s.controller} 正在控制浏览器`) : s.connected?'插件已连接，等待 AI 指令':'插件未连接控制台';
  document.querySelector('#console').href=s.consoleUrl;
});
document.querySelector('#stop').onclick=()=>chrome.runtime.sendMessage({type:'stop'}).then(()=>window.close());
