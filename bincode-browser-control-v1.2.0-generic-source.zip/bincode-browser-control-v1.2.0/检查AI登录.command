#!/bin/sh
set -eu
fleet_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"$fleet_root/scripts/portable/codex.sh" --version
exec "$fleet_root/scripts/portable/codex.sh" login status
