import AppKit
import Foundation
import WebKit

private enum LaunchResult {
    case success
    case failure(String)
}

private final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, NSWindowDelegate {
    private var window: NSWindow!
    private var webView: WKWebView!
    private var consoleURL: URL {
        var port = 17410
        if let root = fleetRoot(),
           let data = try? Data(contentsOf: root.appendingPathComponent("data/fleet.json")),
           let config = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let configured = config["port"] as? Int { port = configured }
        return URL(string: "http://127.0.0.1:\(port)/")!
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let initialContentRect = NSRect(x: 0, y: 0, width: 1450, height: 900)
        webView = WKWebView(frame: initialContentRect, configuration: configuration)
        webView.autoresizingMask = [.width, .height]
        webView.navigationDelegate = self
        webView.uiDelegate = self
        window = NSWindow(contentRect: initialContentRect,
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "bincode多浏览器控制"
        window.minSize = NSSize(width: 1020, height: 680)
        webView.frame = window.contentView?.bounds ?? initialContentRect
        window.contentView = webView
        window.delegate = self
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        recordDiagnostic("window-created")
        showMessage("正在连接 bincode 本机控制台…")
        for seconds in [3, 10] {
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(seconds)) { [weak self] in
                self?.recordDiagnostic("startup-\(seconds)s")
                self?.inspectLocalConsolePage("startup-\(seconds)s")
            }
        }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            let result = self.ensureServer()
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.recordDiagnostic("console-load-requested")
                    self.webView.load(URLRequest(url: self.consoleURL))
                case .failure(let message):
                    self.recordDiagnostic("server-check-failed", ["error": self.safeDiagnosticText(message)])
                    self.showMessage(message)
                }
            }
        }
    }

    func windowWillClose(_ notification: Notification) {
        NSApp.terminate(nil)
    }

    private func showMessage(_ message: String) {
        let safe = message.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
        webView.loadHTMLString("<meta charset='utf-8'><style>body{font:20px system-ui;margin:10%;color:#21434b;background:#f4f8f9}</style><h2>bincode多浏览器控制</h2><p>\(safe)</p>", baseURL: nil)
        recordDiagnostic("message-page-requested", ["message": safeDiagnosticText(message)])
    }

    // Local-console diagnostics only. No browser tabs, form values, cookies,
    // storage, tokens, web pages or external network endpoints are read.
    private func safeDiagnosticText(_ value: String) -> String {
        String(value.prefix(600))
            .replacingOccurrences(of: "(https?://[^\\s?#]+)[?#][^\\s]*", with: "$1?[omitted]", options: .regularExpression)
            .replacingOccurrences(of: "[A-Za-z0-9_-]{32,}", with: "[omitted]", options: .regularExpression)
    }

    private func isLocalConsoleURL(_ url: URL?) -> Bool {
        guard let url else { return false }
        return url.scheme == consoleURL.scheme && url.host == consoleURL.host
            && url.port == consoleURL.port
    }

    private func frameValues(_ rect: NSRect) -> [String: Double] {
        ["x": Double(rect.origin.x), "y": Double(rect.origin.y),
         "width": Double(rect.size.width), "height": Double(rect.size.height)]
    }

    private func recordDiagnostic(_ stage: String, _ fields: [String: Any] = [:]) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in self?.recordDiagnostic(stage, fields) }
            return
        }
        guard let root = fleetRoot() else { return }
        let directory = root.appendingPathComponent("data/diagnostics")
        let file = directory.appendingPathComponent("native-console-diagnostics.jsonl")
        var record: [String: Any] = ["time": ISO8601DateFormatter().string(from: Date()),
                                    "stage": stage, "pid": ProcessInfo.processInfo.processIdentifier]
        if let webView {
            record["url"] = isLocalConsoleURL(webView.url)
                ? (webView.url?.absoluteString.components(separatedBy: "?").first ?? "")
                : (webView.url == nil ? "[not committed]" : "[nonlocal omitted]")
            record["frame"] = frameValues(webView.frame)
            record["bounds"] = frameValues(webView.bounds)
            record["isLoading"] = webView.isLoading
            record["estimatedProgress"] = webView.estimatedProgress
            record["isHidden"] = webView.isHidden
            record["inWindow"] = webView.window != nil
            record["autoresizingMask"] = webView.autoresizingMask.rawValue
            if isLocalConsoleURL(webView.url) { record["title"] = safeDiagnosticText(webView.title ?? "") }
        }
        if let window {
            record["windowVisible"] = window.isVisible
            record["contentBounds"] = frameValues(window.contentView?.bounds ?? .zero)
        }
        fields.forEach { record[$0.key] = $0.value }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
                                                    attributes: [.posixPermissions: 0o700])
            if !FileManager.default.fileExists(atPath: file.path) {
                FileManager.default.createFile(atPath: file.path, contents: nil, attributes: [.posixPermissions: 0o600])
            }
            var data = try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys])
            data.append(0x0a)
            let handle = try FileHandle(forWritingTo: file)
            defer { try? handle.close() }
            try handle.seekToEnd()
            try handle.write(contentsOf: data)
        } catch {
            // Diagnostics must not alter startup or display a new product flow.
        }
    }

    private func inspectLocalConsolePage(_ stage: String) {
        guard isLocalConsoleURL(webView.url),
              let origin = URLComponents(url: consoleURL, resolvingAgainstBaseURL: false),
              let host = origin.host,
              let allowed = try? JSONSerialization.data(withJSONObject: ["\(origin.scheme ?? "http")://\(host):\(origin.port ?? 17410)"]),
              let allowedJSON = String(data: allowed, encoding: .utf8) else {
            recordDiagnostic("local-page-check-skipped", ["trigger": stage])
            return
        }
        recordDiagnostic("local-page-check-requested", ["trigger": stage])
        let script = """
        (() => {
          const allowed = \(allowedJSON)[0];
          if (location.origin !== allowed) return {skipped: 'nonlocal'};
          const node = id => document.getElementById(id);
          const number = id => Number((node(id)?.textContent || '').match(/\\d+/)?.[0] || 0);
          const error = (node('error')?.textContent || '').slice(0, 240)
            .replace(/(https?:\\/\\/[^\\s?#]+)[?#][^\\s]*/g, '$1?[omitted]')
            .replace(/[A-Za-z0-9_-]{32,}/g, '[omitted]');
          return {readyState: document.readyState, title: document.title.slice(0,120),
            bodyChildren: document.body?.children.length || 0,
            bodySize: {width: document.body?.getBoundingClientRect().width || 0,
                       height: document.body?.getBoundingClientRect().height || 0},
            profileRows: document.querySelectorAll('#profile-rows tr').length,
            environmentCount: number('environment-count'),
            brandCounts: (node('brand-count')?.textContent || '').match(/\\d+/g)?.slice(0,3).map(Number) || [],
            pluginOnline: number('live-count'), error: error};
        })()
        """
        webView.evaluateJavaScript(script) { [weak self] value, error in
            guard let self else { return }
            if let error {
                let e = error as NSError
                self.recordDiagnostic("local-page-check-failed", ["trigger": stage, "errorDomain": e.domain,
                    "errorCode": e.code, "error": self.safeDiagnosticText(e.localizedDescription)])
            } else {
                self.recordDiagnostic("local-page-check-result", ["trigger": stage, "page": value ?? NSNull()])
            }
        }
    }

    private func fleetRoot() -> URL? {
        let localRoot = Bundle.main.bundleURL.deletingLastPathComponent()
        if FileManager.default.fileExists(atPath: localRoot.appendingPathComponent("src/server.mjs").path) {
            return localRoot
        }
        guard let file = Bundle.main.url(forResource: "fleet-path", withExtension: "txt"),
              let value = try? String(contentsOf: file, encoding: .utf8).trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty else { return nil }
        return URL(fileURLWithPath: value, isDirectory: true)
    }

    private func serverIsHealthy() -> Bool {
        let semaphore = DispatchSemaphore(value: 0)
        var healthy = false
        var request = URLRequest(url: consoleURL.appendingPathComponent("health"))
        request.timeoutInterval = 2
        URLSession.shared.dataTask(with: request) { data, response, _ in
            if let response = response as? HTTPURLResponse, response.statusCode == 200,
               let data, let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                healthy = json["ok"] as? Bool == true && json["profiles"] as? Int == 140
                    && json["version"] as? String == "1.2.0"
                    && json["root"] as? String == self.fleetRoot()?.resolvingSymlinksInPath().path
            }
            semaphore.signal()
        }.resume()
        _ = semaphore.wait(timeout: .now() + 3)
        return healthy
    }

    private func ensureServer() -> LaunchResult {
        if serverIsHealthy() { return .success }
        guard let root = fleetRoot() else { return .failure("找不到 BinCode 控制台目录。") }
        let node = root.appendingPathComponent("runtime/node/bin/node")
        let launcher = root.appendingPathComponent("scripts/launch.mjs")
        guard FileManager.default.fileExists(atPath: launcher.path) else {
            return .failure("找不到 BinCode 启动脚本。")
        }
        let process = Process()
        if FileManager.default.isExecutableFile(atPath: node.path) {
            process.executableURL = node
            process.arguments = [launcher.path, "--no-open"]
        } else {
            process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
            process.arguments = ["node", launcher.path, "--no-open"]
            var environment = ProcessInfo.processInfo.environment
            environment["PATH"] = (environment["PATH"] ?? "/usr/bin:/bin") + ":/opt/homebrew/bin:/usr/local/bin"
            process.environment = environment
        }
        process.currentDirectoryURL = root
        process.standardOutput = Pipe()
        process.standardError = Pipe()
        do {
            try process.run()
            process.waitUntilExit()
        } catch {
            return .failure("启动控台失败：\(error.localizedDescription)")
        }
        if process.terminationStatus != 0 {
            let errorData = (process.standardError as? Pipe)?.fileHandleForReading.readDataToEndOfFile() ?? Data()
            let detail = String(data: errorData, encoding: .utf8) ?? ""
            return .failure("控台启动失败。请检查本机端口和 Node.js 安装。\n" + String(detail.suffix(1200)))
        }
        for _ in 0..<30 {
            if serverIsHealthy() { return .success }
            Thread.sleep(forTimeInterval: 0.1)
        }
        return .failure("控台没有在配置的本机端口启动，请查看 data/server.log。")
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        recordDiagnostic("navigation-started")
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        recordDiagnostic("navigation-committed")
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        recordDiagnostic("navigation-finished")
        inspectLocalConsolePage("navigation-finished")
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        recordDiagnostic("webcontent-process-terminated")
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        let e = error as NSError
        recordDiagnostic("navigation-failed", ["errorDomain": e.domain, "errorCode": e.code,
            "error": safeDiagnosticText(e.localizedDescription)])
        showMessage("控台页面加载失败：\(error.localizedDescription)")
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        let e = error as NSError
        recordDiagnostic("navigation-provisional-failed", ["errorDomain": e.domain, "errorCode": e.code,
            "error": safeDiagnosticText(e.localizedDescription)])
        showMessage("控台页面加载失败：\(error.localizedDescription)")
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { NSWorkspace.shared.open(url) }
        return nil
    }
}

let application = NSApplication.shared
application.setActivationPolicy(.regular)
private let delegate = AppDelegate()
application.delegate = delegate
application.run()
