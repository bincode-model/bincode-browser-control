#!/bin/sh
exec "$(dirname "$0")/scripts/portable/start.sh" "$@"
