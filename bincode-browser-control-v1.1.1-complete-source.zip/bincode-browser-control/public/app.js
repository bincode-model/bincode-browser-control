import {PageSelection} from './paging.js';
const paging = new PageSelection();
let state,group=0,view='environments',showAllJobs=false,editing=null,editingProvider=null,jobDetailId=null,settingsLoaded=false;
const selected=paging.selected;
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statuses={stopped:'未启动',starting:'正在启动',idle:'插件在线',reserved:'等待 AI 指令',controlling:'AI 控制中',disconnected:'插件断线',reconnecting:'重新连接',error:'启动失败'};
const jobStatuses={queued:'排队中',starting:'启动中',running:'运行中',succeeded:'已完成',failed:'失败',cancelled:'已取消',interrupted:'已中断',waiting_login:'待本人登录',needs_input:'待补充范围',needs_review:'待核验'};
function message(text,error=false){const box=$(error?'#error':'#notice');box.textContent=text;box.classList.remove('hidden');if(!error)setTimeout(()=>box.classList.add('hidden'),8000);}
async function api(route,body){const r=await fetch('/api/'+route,{method:body===undefined?'GET':'POST',headers:{'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const data=await r.json();if(!r.ok)throw Error(data.error);return data;}
async function action(button,fn){$('#error').classList.add('hidden');if(button)button.disabled=true;try{return await fn();}catch(e){message(e.message,true);}finally{if(button)button.disabled=false;}}
function switchView(next){view=next;document.querySelectorAll('.view').forEach(el=>el.classList.toggle('hidden',el.id!=='view-'+next));document.querySelectorAll('.nav').forEach(el=>el.classList.toggle('active',el.dataset.view===next));$('#page-title').textContent={environments:'浏览器环境',benchmark:'100 浏览器实测',jobs:'任务队列',providers:'AI 控制器',settings:'运行设置'}[next];$('#page-subtitle').textContent={environments:'每页 10 家 · 启动直达商家后台 · 连接与任务状态分别核验。',benchmark:'真实登录、真实插件取数、独立 Cookie 与购物车。',jobs:'独立环境各自执行任务，记录插件实际操作和结果。',providers:'为每个浏览器环境选择 AI，支持本机登录或模型 API。',settings:'按电脑实际负载调整并发，环境数据永久保存。'}[next];if(next==='jobs')renderJobs();if(next==='benchmark')renderBenchmark();}
function providerLabel(id){return state.providers.find(p=>p.id===id)?.name||id;}
function renderBenchmark(){
  if(!state)return;
  const tasks=state.jobs.filter(j=>j.workflow);const runId=tasks.at(-1)?.workflow.runId;
  if(!runId)return;
  const latest=new Map();for(const j of tasks.filter(j=>j.workflow.runId===runId))latest.set(j.profileId,j);
  const rows=[...latest.values()].sort((a,b)=>a.profileId.localeCompare(b.profileId));
  const passed=rows.filter(j=>j.status==='succeeded'&&j.benchmark?.passed).length;
  const failed=rows.filter(j=>['failed','cancelled','interrupted'].includes(j.status)).length;
  const running=rows.filter(j=>['starting','running'].includes(j.status)).length;
  const products=rows.reduce((n,j)=>n+(j.benchmark?.inventoryCount||0),0);
  $('#benchmark-summary').innerHTML=`<span><strong>${passed} / ${rows.length}</strong> 环境通过</span><span><strong>${failed}</strong> 失败</span><span><strong>${running}</strong> 执行中</span><span><strong>${products}</strong> 商品记录</span><span class="env-id">${esc(runId)}</span>`;
  $('#benchmark-progress').max=rows.length;$('#benchmark-progress').value=passed+failed;
  $('#benchmark-rows').innerHTML=rows.map(j=>{const c=j.workflow.case,b=j.benchmark;return `<tr><td><strong>${j.profileId}</strong><span class="env-id">第 ${j.group} 组</span></td><td>${esc(c.username)}</td><td>${c.sort==='lohi'?'价格升序':'价格降序'}</td><td>${b?.inventoryCount||0} 件</td><td>${b?.totalUsd===undefined?'—':'$'+b.totalUsd.toFixed(2)}</td><td><span class="status ${j.status==='failed'?'failed':['running','starting'].includes(j.status)?'busy':j.status==='succeeded'?'online':''}">${jobStatuses[j.status]}</span><span class="env-id">${esc(j.error||j.currentStep||'等待执行')}</span></td><td>${b?.durationSeconds===undefined?'—':b.durationSeconds+' 秒'}</td><td><button data-benchmark-detail="${j.id}">记录</button>${b?.screenshots?.cart?` <a href="${esc(b.screenshots.cart.artifactUrl)}" target="_blank">购物车截图 ↗</a>`:''}</td></tr>`;}).join('');
}
function shownProfiles(){
  const query=$('#search').value.trim().toLowerCase();
  const number=query.match(/^浏览器\s*0*(\d+)$/)?.[1];
  const platform=$('#platform-filter').value,status=$('#status-filter').value;
  return state.profiles.filter(p=>{
    if(p.duplicateOf)return false;
    if(status==='retained'&&!state.settings.retainedProfileIds.includes(p.id))return false;
    if(status==='logged_in'&&p.login?.state!=='logged_in')return false;
    if(platform&&p.storePlatform!==platform)return false;
    if(status==='running'&&!p.pid||status==='stopped'&&!!p.pid||status==='connected'&&!p.connected||status==='controlling'&&!p.controller||status==='disconnected'&&(!p.pid||p.connected))return false;
    if(number)return p.number===Number(number);
    return !query||`${p.id} ${p.name} ${p.verifiedIdentity?.shopId||''} 浏览器${p.number} 浏览器 ${p.number} 浏览器 ${String(p.number).padStart(3,'0')} ${p.storePlatform||''}`.toLowerCase().includes(query);
  });
}
function visiblePage(reset=false){return paging.update(shownProfiles(),{reset});}
function resetPage(){visiblePage(true);renderProfiles();}
function renderProfiles(){
  if(!state)return;
  const page=visiblePage(),shown=page.rows;
  $('#matrix').innerHTML=shown.map(p=>`<button class="${p.connected?'online ':''}${p.controller?'controlling ':''}${selected.has(p.id)?'selected':''}" data-matrix="${p.id}" aria-pressed="${selected.has(p.id)}" aria-label="浏览器${p.number}，${esc(p.name)}" title="${esc(p.name)}">${String(p.number).padStart(3,'0')}<span>${esc(p.storePlatform||'备用')}</span></button>`).join('');
  $('#profile-rows').innerHTML=shown.length?shown.map(p=>{
    const job=state.jobs.filter(j=>j.profileId===p.id&&(!p.verifiedIdentity||j.expectedStoreKey===p.verifiedIdentity.storeKey)).at(-1);
    const control=p.userStopped?'用户已停止控制':p.controller?(p.controlMode==='standby'?'AI 调试已连接 · 待命':p.controller+' 执行中'):statuses[p.status]||p.status;
    return `<tr class="${selected.has(p.id)?'selected-row':''}"><td><input type="checkbox" data-select="${p.id}" aria-label="选择 ${esc(p.name)}" ${selected.has(p.id)?'checked':''}></td><td><span class="env-name">${esc(p.displayName||p.name)}</span><span class="env-id">浏览器 ${p.number} · ${esc(p.storePlatform||'备用环境')} · ${p.id}</span><span class="entry-url">${p.entryUrl?esc(new URL(p.entryUrl).hostname):'入口待核验'}</span>${p.verifiedIdentity?`<span class="env-id">${p.login?.state==='logged_in'?'店铺ID':'上次核验ID'}：${esc(p.verifiedIdentity.shopId)}</span>`:''}${p.duplicateCandidates?.length?'<span class="env-id warning">存在相似店铺，账号待核</span>':''}</td><td><span class="status ${p.controller?'busy':p.connected?'online':''}">${esc(control)}</span><span class="env-id">${esc(p.login?.label||'尚未核验登录')}</span><span class="env-id">${p.controlProof?'读取已核验 · '+new Date(p.controlProof.checkedAt).toLocaleTimeString('zh-CN',{hour12:false}):'尚无页面读取回执'}</span>${p.error?`<span class="env-id warning">${esc(p.error)}</span>`:''}</td><td>${job?`<span class="status">${jobStatuses[job.status]||esc(job.status)}</span><span class="env-id">第 ${job.batchIndex||job.group}/${job.batchCount||'—'} 批 · ${esc(providerLabel(job.provider).split(' · ')[0])}</span><span class="task-brief" title="${esc(job.prompt)}">${esc(job.prompt)}</span>`:'<span class="env-id">暂无任务</span>'}</td><td><div class="row-actions"><button data-launch="${p.id}" ${p.status==='starting'?'disabled':''}>${p.pid?'关闭':'启动'}</button>${p.pid?`<button data-connect="${p.id}">重新核验</button>`:''}<button data-edit="${p.id}">设置</button></div></td></tr>`;
  }).join(''):'<tr><td colspan="5" class="empty">没有匹配的店铺浏览器。</td></tr>';
  $('#filtered-count').textContent=`共 ${page.total} 个 · 本页 ${shown.length} 个`;
  $('#selected-count').textContent=`已选择 ${selected.size} 个`;
  $('#select-all').textContent=`选择本页 ${shown.length} 家`;
  $('#select-group').checked=shown.length>0&&shown.every(p=>selected.has(p.id));
  $('#select-group').indeterminate=shown.some(p=>selected.has(p.id))&&!$('#select-group').checked;
  $('#page-label').textContent=`第 ${page.page} / ${page.pages} 页 · 每页最多 10 家`;
  $('#prev-page').disabled=page.page<=1;$('#next-page').disabled=page.page>=page.pages;
  $('#task-info').textContent=`本页选中 ${selected.size} 家。每批最多 10 家；同时最多 ${state.settings.maxAgents} 个 AI 任务、${state.settings.maxBrowsers} 个浏览器。`;
  const platform=$('#platform-filter').value;
  $('#submit-platform').disabled=!platform;
  $('#submit-platform').textContent=platform?`运行 ${platform} 当前筛选的全部店铺`:'先选择平台，再运行筛选店铺';
  const missing=state.profiles.filter(p=>p.storeId&&!p.entryUrl&&!p.duplicateOf),pending=state.profiles.filter(p=>p.duplicateCandidates?.length);
  $('#catalog-notes-body').textContent=`${missing.length} 家入口待核验：${missing.map(p=>p.id+' '+p.name).join('；')||'无'}。${pending.length} 个环境有相似名称，需以商家账号确认后归并，原编号和目录完整保留。`;
}
function renderJobs(){
  if(!state)return;const jobs=state.jobs.filter(j=>showAllJobs||['queued','starting','running','waiting_login','needs_input','needs_review','failed','interrupted'].includes(j.status)).slice().reverse();
  $('#job-list').innerHTML=jobs.length?jobs.map(j=>`<div class="job-row"><div><strong>${j.profileId}</strong><br><span class="env-id">第 ${j.group} 组 · ${esc(j.provider)}</span></div><span class="status ${j.status==='failed'?'failed':['running','starting'].includes(j.status)?'busy':''}">${jobStatuses[j.status]}</span><p>${esc(j.prompt)}</p><span class="job-time env-id">${new Date(j.createdAt).toLocaleString('zh-CN',{hour12:false})}</span><div class="job-actions"><button data-detail="${j.id}">详情</button>${['queued','starting','running'].includes(j.status)?`<button data-cancel="${j.id}">取消</button>`:['failed','interrupted','cancelled','waiting_login','needs_input','needs_review'].includes(j.status)?`<button data-retry="${j.id}">重试</button>`:''}</div></div>`).join(''):'<div class="empty">暂无'+(showAllJobs?'任务':'进行中或待处理任务')+'。在浏览器环境中选择环境并提交任务。</div>';
  const latest=state.jobs.at(-1),batch=latest?state.jobs.filter(j=>j.batchId===latest.batchId):[];
  const count=status=>batch.filter(j=>status.includes(j.status)).length;
  $('#batch-summary').innerHTML=batch.length?`<span>最近一轮 <strong>${batch.length}</strong> 家</span><span>已完成 <strong>${count(['succeeded'])}</strong></span><span>执行 / 排队 <strong>${count(['queued','starting','running'])}</strong></span><span>待登录 / 补充 / 核验 <strong>${count(['waiting_login','needs_input','needs_review'])}</strong></span><span>失败 / 中断 <strong>${count(['failed','interrupted','cancelled'])}</strong></span>`:'尚无批次任务';
  $('#pause-queue').textContent=state.paused?'继续队列':'暂停队列';
}
function updateState(next){
  state=next;$('#connection').textContent='本机控制台已连接';$('#live-count').textContent=state.profiles.filter(p=>p.connected).length;$('#working-count').textContent=state.profiles.filter(p=>p.controller).length;$('#memory').textContent=state.resources.fleetMemoryMB>1024?(state.resources.fleetMemoryMB/1024).toFixed(1)+' GB':state.resources.fleetMemoryMB+' MB';$('#limit-label').textContent=`并发 ${state.settings.maxAgents} 个任务 / ${state.settings.maxBrowsers} 个浏览器`;$('#nav-queued').textContent=state.jobs.filter(j=>['queued','running','starting'].includes(j.status)).length;
  const platforms=[...new Set(state.profiles.map(p=>p.storePlatform).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'zh-CN'));
  const platformOptions=platforms.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');
  if($('#platform-filter').dataset.options!==platformOptions){const previous=$('#platform-filter').value;$('#platform-filter').innerHTML='<option value="">全部平台</option>'+platformOptions;$('#platform-filter').value=previous;$('#platform-filter').dataset.options=platformOptions;}
  const retained=state.settings.retainedProfileIds||[];
  $('#status-filter option[value="retained"]').textContent=`本次保留（${retained.length} 家）`;
  if(!$('#status-filter').dataset.initialized){if(retained.length)$('#status-filter').value='retained';$('#status-filter').dataset.initialized='true';}
  renderProfiles();renderJobs();renderBenchmark();
  const options=state.providers.map(p=>`<option value="${p.id}">${esc(p.name)}${p.ready?'':'（未配置）'}</option>`).join('');
  for(const id of ['#task-provider','#edit-provider']){const el=$(id);if(el.dataset.options!==options){const old=el.value;el.innerHTML=(id==='#task-provider'?'<option value="">使用各环境自己的设置</option>':'')+options;el.value=old;el.dataset.options=options;}}
  $('#provider-list').innerHTML=state.providers.map(p=>`<div class="provider-row"><div class="provider-copy"><h3>${esc(p.name)}</h3><p>${esc(p.note)}${p.model?' · '+esc(p.model):''}</p></div><span class="status ${p.ready?'online':''}">${p.ready?'可使用':'待配置'}</span>${p.kind==='api'?`<button data-provider="${p.id}">配置</button>`:''}</div>`).join('');
  if(!settingsLoaded){$('#max-browsers').value=state.settings.maxBrowsers;$('#max-agents').value=state.settings.maxAgents;$('#auto-close').checked=state.settings.autoClose;$('#task-timeout').value=state.settings.taskTimeoutMinutes;settingsLoaded=true;}
  $('#machine-info').textContent=`${state.resources.totalMemoryGB.toFixed(0)} GB 内存 · ${state.resources.cpuCount} 核 CPU · 浏览器进程占用 ${state.resources.fleetMemoryMB} MB · 已打开 ${state.resources.activeBrowsers} 个环境`;
  $('#chrome-path').textContent='蓝色浏览器程序：本机 runtime/numbered-browsers/浏览器 001.app … 浏览器 140.app；每个店铺使用独立数据目录。';
}
document.querySelectorAll('.nav').forEach(el=>el.onclick=()=>switchView(el.dataset.view));
document.querySelectorAll('.group').forEach(el=>el.onclick=()=>{group=+el.dataset.group;renderProfiles();});
$('#search').oninput=resetPage;
$('#platform-filter').onchange=resetPage;
$('#status-filter').onchange=resetPage;
$('#prev-page').onclick=()=>{paging.move(-1);renderProfiles();};
$('#next-page').onclick=()=>{paging.move(1);renderProfiles();};
$('#matrix').onclick=e=>{const b=e.target.closest('[data-matrix]');if(!b)return;const id=b.dataset.matrix;selected.has(id)?selected.delete(id):selected.add(id);renderProfiles();};
$('#select-group').onchange=e=>{visiblePage().rows.forEach(p=>e.target.checked?selected.add(p.id):selected.delete(p.id));renderProfiles();};
$('#select-all').onclick=()=>{visiblePage().rows.forEach(p=>selected.add(p.id));renderProfiles();};
$('#clear-selection').onclick=()=>{selected.clear();renderProfiles();};
$('#profile-rows').onchange=e=>{const id=e.target.dataset.select;if(id){e.target.checked?selected.add(id):selected.delete(id);renderProfiles();}};
$('#profile-rows').onclick=e=>{
  const launch=e.target.closest('[data-launch]');if(launch){const p=state.profiles.find(p=>p.id===launch.dataset.launch);action(launch,async()=>{await api(p.pid?'stop':'start',{profileId:p.id});message(p.pid?'环境已关闭，数据已保存。':'商家页面已打开，控制台调试与页面读取已核验；AI 任务尚未执行。');});}
  const reconnect=e.target.closest('[data-connect]');if(reconnect)action(reconnect,async()=>{await api('start',{profileId:reconnect.dataset.connect});message('已重新读取页面并核验控制连接。');});
  const edit=e.target.closest('[data-edit]');if(edit){editing=edit.dataset.edit;const p=state.profiles.find(p=>p.id===editing);$('#profile-editor').classList.remove('hidden');$('#edit-id').textContent=editing;$('#edit-name').value=p.name;$('#edit-provider').value=p.provider;$('#edit-url').value=p.entryUrl;$('#edit-extensions').value=p.extraExtensions.join('\n');$('#edit-path').textContent='独立数据：'+p.userDataDir;$('#edit-name').focus();}
};
$('#save-profile').onclick=e=>action(e.target,async()=>{await api('profile',{profileId:editing,name:$('#edit-name').value,provider:$('#edit-provider').value,entryUrl:$('#edit-url').value,extraExtensions:$('#edit-extensions').value.split('\n').map(x=>x.trim()).filter(Boolean)});message('环境设置已保存。');});
async function submitJobs(ids){
  if(!ids.length)throw Error('请先选择店铺。');
  const prompt=$('#task-prompt').value.trim();if(!prompt)throw Error('请输入具体任务、数据内容和起止日期。');
  const jobs=await api('jobs',{profileIds:ids,prompt,provider:$('#task-provider').value||undefined,background:$('#background').checked});
  message(`${jobs.length} 个任务已入队，按每批最多 10 家依次执行。`);switchView('jobs');
}
$('#submit-task').onclick=e=>action(e.target,()=>submitJobs([...selected]));
$('#submit-platform').onclick=e=>action(e.target,async()=>{
  const platform=$('#platform-filter').value;if(!platform)throw Error('请先选择具体平台。');
  await submitJobs(shownProfiles().filter(p=>p.storeId).map(p=>p.id));
});
$('#start-selected').onclick=e=>action(e.target,async()=>{
  if(!selected.size)throw Error('请先选择店铺。');
  const ids=[...selected],newIds=ids.filter(id=>!state.profiles.find(p=>p.id===id).pid);
  const slots=state.settings.maxBrowsers-state.resources.activeBrowsers;
  if(newIds.length>slots)throw Error(`当前还可打开 ${slots} 家，请先关闭空闲浏览器。`);
  const results=await Promise.allSettled(ids.map(profileId=>api('start',{profileId,background:false})));
  const errors=results.flatMap((r,i)=>r.status==='rejected'?[ids[i]+'：'+r.reason.message]:[]);
  message(`已核验 ${results.length-errors.length}/${results.length} 家商家页面与控制连接。`+(errors.length?' '+errors.join('；'):''),!!errors.length);
});
$('#close-idle').onclick=e=>action(e.target,async()=>{const results=await api('close-idle',{});const failures=results.filter(x=>x.status==='rejected').length;message(failures?`关闭空闲环境时有 ${failures} 个错误，请查看环境状态。`:'空闲环境已关闭，Cookie 和登录已保存。',!!failures);});
$('#emergency').onclick=e=>action(e.target,async()=>{await api('emergency-stop',{});message('任务已取消，队列已暂停，AI 控制已释放。');});
$('#pause-queue').onclick=e=>action(e.target,()=>api('pause',{paused:!state.paused}));
$('#filter-active').onclick=()=>{showAllJobs=false;$('#filter-active').classList.add('active');$('#filter-all').classList.remove('active');renderJobs();};
$('#filter-all').onclick=()=>{showAllJobs=true;$('#filter-all').classList.add('active');$('#filter-active').classList.remove('active');renderJobs();};
async function detail(id){jobDetailId=id;const j=await api('jobs/'+id);$('#job-detail').classList.remove('hidden');$('#job-prompt').textContent=j.profileId+' · '+j.prompt;$('#job-events').textContent=(j.events||[]).map(x=>new Date(x.time).toLocaleTimeString('zh-CN')+' '+x.message).join('\n')||'任务尚未开始。';$('#job-result').textContent=j.result||j.error||'等待执行结果。';const names=[...new Set((j.result||'').match(/env-\d{3}-\d+-[a-f\d]+\.png/g)||[])];$('#job-artifacts').innerHTML=names.map(name=>`<figure><img src="/api/artifacts/${name}" alt="${esc(j.profileId)} 的插件操作截图" loading="lazy"><figcaption>${esc(name)}</figcaption></figure>`).join('');}
$('#job-list').onclick=e=>{const d=e.target.closest('[data-detail]'),c=e.target.closest('[data-cancel]'),r=e.target.closest('[data-retry]');if(d)action(d,()=>detail(d.dataset.detail));if(c)action(c,()=>api('cancel',{jobId:c.dataset.cancel}));if(r)action(r,()=>api('retry',{jobId:r.dataset.retry}));};
$('#benchmark-rows').onclick=e=>{const d=e.target.closest('[data-benchmark-detail]');if(d)action(d,async()=>{showAllJobs=true;switchView('jobs');await detail(d.dataset.benchmarkDetail);$('#job-detail').scrollIntoView({behavior:'smooth'});});};
$('#provider-list').onclick=e=>{const b=e.target.closest('[data-provider]');if(!b)return;editingProvider=b.dataset.provider;const p=state.providers.find(p=>p.id===editingProvider);$('#provider-form').classList.remove('hidden');$('#provider-form-title').textContent=p.name;$('#api-base').value=p.baseUrl;$('#api-model').value=p.model;$('#api-key').value='';$('#api-model').focus();};
$('#save-provider').onclick=e=>action(e.target,async()=>{const config={baseUrl:$('#api-base').value.trim(),model:$('#api-model').value.trim()};if($('#api-key').value.trim())config.apiKey=$('#api-key').value.trim();await api('provider',{provider:editingProvider,config});$('#api-key').value='';message('AI 控制器配置已保存。');});
$('#settings-form').onsubmit=e=>{e.preventDefault();action($('#settings-form button'),async()=>{await api('settings',{maxBrowsers:+$('#max-browsers').value,maxAgents:+$('#max-agents').value,autoClose:$('#auto-close').checked,taskTimeoutMinutes:+$('#task-timeout').value});message('运行设置已保存。');});};
const events=new EventSource('/api/events');events.addEventListener('state',event=>{try{updateState(JSON.parse(event.data));}catch(e){message('界面更新失败：'+e.message,true);}});events.addEventListener('job',event=>{const data=JSON.parse(event.data);if(data.jobId===jobDetailId)detail(jobDetailId).catch(()=>{});});events.onerror=()=>{$('#connection').textContent='连接中断，正在重连…';};
api('state').then(next=>{updateState(next);if(location.hash==='#benchmark')switchView('benchmark');}).catch(e=>message(e.message,true));
