export const PAGE_SIZE = 10;

// Selection belongs to one visible page. Server refreshes must not reselect
// rows that the user explicitly unchecked.
export class PageSelection {
  constructor() { this.page = 1; this.selected = new Set(); this.key = null; }
  update(profiles, {reset = false} = {}) {
    const pages = Math.max(1, Math.ceil(profiles.length / PAGE_SIZE));
    this.page = reset ? 1 : Math.max(1, Math.min(this.page, pages));
    const rows = profiles.slice((this.page - 1) * PAGE_SIZE, this.page * PAGE_SIZE);
    const key = rows.map(p => p.id).join('|');
    if (reset || key !== this.key) {
      this.selected.clear();
      rows.forEach(p => this.selected.add(p.id));
      this.key = key;
    }
    const visible = new Set(rows.map(p => p.id));
    for (const id of this.selected) if (!visible.has(id)) this.selected.delete(id);
    return {rows, pages, page: this.page, total: profiles.length};
  }
  move(delta) { this.page += delta; this.key = null; }
}
