/* The browser transport is exclusively chrome.debugger INSIDE this extension.
 * No remote debugging port, browser driver, or external CDP connection is used.
 * Architecture references: hangwin/mcp-chrome (MIT), Chrome debugger API.
 */
importScripts('config.js');
importScripts('session-manager.js');
let socket, reconnectTimer, currentTab, controller=null, owner=null, blockedOwner=null;
const attached=new Set();
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function send(message){if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify(message));}
function renderNotice(state){
  const id='ai-fleet-control-notice';
  let host=document.getElementById(id);
  if(!state){host?.remove();return;}
  if(!host){host=document.createElement('div');host.id=id;host.attachShadow({mode:'open'});(document.documentElement||document.body).append(host);}
  host.dataset.controller=state.controller;host.dataset.profileId=state.profileId;host.dataset.owner=state.owner;
  // Keep the control notice away from common navigation bars (for example,
  // Swag Labs' cart link). A full-width top overlay intercepted real clicks.
  host.style.cssText='position:fixed;bottom:12px;right:12px;max-width:calc(100vw - 24px);z-index:2147483647;pointer-events:none;display:block;';
  const root=host.shadowRoot;root.replaceChildren();
  const bar=document.createElement('div');bar.style.cssText='display:flex;align-items:center;justify-content:center;gap:18px;padding:10px 16px;background:#164c55;color:#fff;font:14px/1.4 system-ui;border-radius:6px;box-shadow:0 2px 6px #0003;pointer-events:auto;';
  const label=document.createElement('strong');label.textContent=state.controller==='控制台（待命）'?`AI 调试已连接 · 待命 · ${state.profileId}`:`${state.controller} 正在控制浏览器 · ${state.profileId}`;
  const button=document.createElement('button');button.textContent='停止控制';button.style.cssText='font:13px system-ui;border:1px solid #ffffff90;border-radius:4px;padding:4px 9px;color:#fff;background:transparent;cursor:pointer;';
  button.addEventListener('click',()=>chrome.runtime.sendMessage({type:'stop'}));
  bar.append(label,button);root.append(bar);
}
async function notice(tabId,state=controller?{controller,profileId:FLEET_CONFIG.profileId,owner}:null){
  try{await chrome.scripting.executeScript({target:{tabId},func:renderNotice,args:[state]});}catch{}
}
async function release(user=false){
  if(user)blockedOwner=owner;
  const oldOwner=owner;controller=null;owner=null;
  for(const id of [...attached]){await notice(id,null);try{await fleetDebugSessions.detach(id);}catch{}attached.delete(id);}
  await chrome.action.setBadgeText({text:''});
  send({type:'control',controller:null,attachedTabs:[],revoked:user,owner:oldOwner});
}
async function attach(tabId,name,requestOwner){
  if(blockedOwner&&blockedOwner===requestOwner)throw new Error('用户已停止本次 AI 控制；请新建任务或新会话。');
  const tab=await chrome.tabs.get(tabId);
  if(!/^https?:\/\//.test(tab.url||''))throw new Error('只能控制普通 HTTP/HTTPS 页面，请先导航到网站。');
  if(!attached.has(tabId)){await fleetDebugSessions.attach(tabId);attached.add(tabId);await fleetDebugSessions.sendCommand(tabId,'Page.enable');}
  currentTab=tabId;controller=name;owner=requestOwner;
  await chrome.action.setBadgeBackgroundColor({color:'#164c55'});await chrome.action.setBadgeText({text:'AI'});
  for(const id of attached)await notice(id);
  send({type:'control',controller,owner,attachedTabs:[...attached]});
}
async function chooseTab(){
  if(currentTab){try{return await chrome.tabs.get(currentTab);}catch{currentTab=null;}}
  const tabs=await chrome.tabs.query({});
  return tabs.find(t=>t.active&&/^https?:/.test(t.url||''))||tabs.find(t=>/^https?:/.test(t.url||''));
}
async function ready(tabId){
  for(let n=0;n<200;n++){const t=await chrome.tabs.get(tabId);if(t.status==='complete')return t;await delay(100);}
  throw new Error('页面加载超时。');
}
async function cdp(method,params={}){return fleetDebugSessions.sendCommand(currentTab,method,params);}
async function evaluate(expression){
  const r=await cdp('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});
  if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
  return r.result?.value??null;
}
async function locate(selector){
  return evaluate(`(async()=>{const s=${JSON.stringify(selector)};const e=s.startsWith('@')?document.querySelector('[data-ai-fleet-ref="'+s.slice(1)+'"]'):document.querySelector(s);if(!e)throw Error('找不到元素 '+s);e.scrollIntoView({block:'center',inline:'center',behavior:'instant'});await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));const r=e.getBoundingClientRect();if(!r.width||!r.height)throw Error('元素不可见');const x=r.x+r.width/2,y=r.y+r.height/2;const hit=document.elementFromPoint(x,y);if(hit!==e&&!e.contains(hit))throw Error('目标元素被遮挡：'+s);return {x,y,tag:e.tagName};})()`);
}
async function execute(message){
  const {action,args={},controller:name='AI',owner:requestOwner}=message;
  if(blockedOwner&&blockedOwner===requestOwner&&!['ping','release'].includes(action))throw new Error('用户已停止本次 AI 控制；请新建任务或新会话。');
  let result;
  if(action==='ping')return {profileId:FLEET_CONFIG.profileId,extensionId:chrome.runtime.id,version:chrome.runtime.getManifest().version,controller,attachedTabs:[...attached]};
  if(action==='release'){await release();return {released:true};}
  if(action==='tabs'){result=(await chrome.tabs.query({})).map(t=>({id:t.id,url:t.url,title:t.title,active:t.active}));}
  else if(action==='navigate'){
    const url=new URL(args.url);if(!['http:','https:'].includes(url.protocol))throw Error('URL 必须是 HTTP/HTTPS。');
    let tab=await chooseTab();
    if(args.newTab||!tab)tab=await chrome.tabs.create({url:args.url,active:args.activate===true});
    else await chrome.tabs.update(tab.id,{url:args.url});
    currentTab=tab.id;await ready(tab.id);await attach(tab.id,name,requestOwner);
    result={tabId:tab.id,url:(await chrome.tabs.get(tab.id)).url};
  }else{
    const tab=action==='select_tab'?await chrome.tabs.get(args.tabId):await chooseTab();
    if(!tab)throw Error('没有可控制页面，请先使用 navigate。');
    await attach(tab.id,name,requestOwner);
    switch(action){
      case 'select_tab': if(args.activate)await chrome.tabs.update(tab.id,{active:true});result={tabId:tab.id};break;
      case 'snapshot': result=await evaluate(`(()=>{let n=0;const els=[...document.querySelectorAll('a,button,input,textarea,select,[role="button"],[contenteditable="true"]')].filter(e=>{const r=e.getBoundingClientRect();return r.width&&r.height;});const elements=els.slice(0,200).map(e=>{const ref='e'+(++n);e.dataset.aiFleetRef=ref;return {ref:'@'+ref,tag:e.tagName.toLowerCase(),role:e.getAttribute('role'),name:(e.getAttribute('aria-label')||e.innerText||e.getAttribute('placeholder')||e.getAttribute('name')||'').trim().slice(0,180),type:e.type,value:e.type==='password'?'[hidden]':e.value,href:e.href};});return {url:location.href,title:document.title,text:document.body.innerText.slice(0,18000),elements};})()`);break;
      case 'evaluate': result=await evaluate(args.code);break;
      case 'click':{await locate(args.selector);await cdp('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const p=await locate(args.selector);await evaluate(`window.__fleetLastClick=null;document.addEventListener('click',e=>{window.__fleetLastClick={target:e.target.outerHTML.slice(0,500),trusted:e.isTrusted,x:e.clientX,y:e.clientY}},{once:true,capture:true})`);await cdp('Input.dispatchMouseEvent',{type:'mouseMoved',x:p.x,y:p.y,button:'none'});await cdp('Input.dispatchMouseEvent',{type:'mousePressed',x:p.x,y:p.y,button:'left',clickCount:1});await delay(80);await cdp('Input.dispatchMouseEvent',{type:'mouseReleased',x:p.x,y:p.y,button:'left',clickCount:1});await delay(100);let event=await evaluate('window.__fleetLastClick');if(!event){await evaluate(`(()=>{const s=${JSON.stringify(args.selector)};const e=s.startsWith('@')?document.querySelector('[data-ai-fleet-ref="'+s.slice(1)+'"]'):document.querySelector(s);if(!e||!['BUTTON','A','INPUT'].includes(e.tagName))throw Error('页面未接收点击');e.focus();})()`);await cdp('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});await cdp('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13});event=await evaluate('window.__fleetLastClick');if(!event){await evaluate(`(()=>{const s=${JSON.stringify(args.selector)};const e=s.startsWith('@')?document.querySelector('[data-ai-fleet-ref="'+s.slice(1)+'"]'):document.querySelector(s);if(!e)throw Error('目标已消失');e.click();})()`);event=await evaluate('window.__fleetLastClick');}}result={clicked:args.selector,point:p,event,activation:event?.trusted?'trusted-input':'extension-dom'};break;}
      case 'fill':{
        await locate(args.selector);
        await evaluate(`(()=>{const s=${JSON.stringify(args.selector)};const e=s.startsWith('@')?document.querySelector('[data-ai-fleet-ref="'+s.slice(1)+'"]'):document.querySelector(s);e.focus();if(e.select)e.select();else if(e.isContentEditable){const r=document.createRange();r.selectNodeContents(e);const sel=getSelection();sel.removeAllRanges();sel.addRange(r);}else throw Error('元素无法填写');})()`);
        await cdp('Input.insertText',{text:args.value});result={filled:args.selector};break;
      }
      case 'press_key':{const key=args.key;const codes={Enter:13,Tab:9,Escape:27,Backspace:8,ArrowDown:40,ArrowUp:38};await cdp('Input.dispatchKeyEvent',{type:'keyDown',key,code:key,windowsVirtualKeyCode:codes[key]||0,...(key==='Enter'?{text:'\r'}:{})});await cdp('Input.dispatchKeyEvent',{type:'keyUp',key,code:key,windowsVirtualKeyCode:codes[key]||0});result={pressed:key};break;}
      case 'scroll': await evaluate(`window.scrollBy(${Number(args.x)||0},${Number(args.y)||0})`);result={scrolled:true};break;
      case 'screenshot':{const r=await cdp('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});result={data:r.data,mimeType:'image/png'};break;}
      case 'close_tab': await chrome.tabs.remove(tab.id);attached.delete(tab.id);currentTab=null;result={closed:tab.id};break;
      default:throw Error('未知插件动作：'+action);
    }
  }
  return {result,proof:{via:'chrome-extension',profileId:FLEET_CONFIG.profileId,extensionId:chrome.runtime.id,controller,debuggerAttached:attached.has(currentTab),attachedTabs:[...attached],timestamp:new Date().toISOString()}};
}
function connect(){
  clearTimeout(reconnectTimer);
  if(socket&&[WebSocket.OPEN,WebSocket.CONNECTING].includes(socket.readyState))return;
  socket=new WebSocket(FLEET_CONFIG.bridgeUrl);
  socket.onopen=()=>send({type:'hello',profileId:FLEET_CONFIG.profileId,token:FLEET_CONFIG.token,extensionId:chrome.runtime.id,version:chrome.runtime.getManifest().version});
  socket.onmessage=async event=>{
    let m;try{m=JSON.parse(event.data);}catch{return;}
    if(m.type!=='command')return;
    try{send({type:'result',id:m.id,ok:true,data:await execute(m)});}catch(e){send({type:'result',id:m.id,ok:false,error:e.message});}
  };
  socket.onclose=()=>{release().catch(()=>{});reconnectTimer=setTimeout(connect,1500);};
  socket.onerror=()=>socket.close();
}
chrome.runtime.onMessage.addListener((m,_sender,respond)=>{
  if(m.type==='status'){respond({profileId:FLEET_CONFIG.profileId,controller,connected:socket?.readyState===WebSocket.OPEN,consoleUrl:FLEET_CONFIG.consoleUrl});return;}
  if(m.type==='stop'){release(true).then(()=>respond({stopped:true}));return true;}
});
chrome.debugger.onDetach.addListener((source,reason)=>{
  attached.delete(source.tabId);fleetDebugSessions.forget(source.tabId);notice(source.tabId,null);
  if(reason==='canceled_by_user')release(true).catch(()=>{});
});
chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='complete'&&attached.has(id)&&controller)notice(id);});
chrome.tabs.onRemoved.addListener(id=>{attached.delete(id);if(currentTab===id)currentTab=null;});
chrome.alarms.create('bridge-heartbeat',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(()=>{connect();send({type:'heartbeat',controller,owner,attachedTabs:[...attached]});});
setInterval(()=>send({type:'heartbeat',controller,owner,attachedTabs:[...attached]}),15000);
connect();
