# BinCode 多浏览器控制

![BinCode 多浏览器控制介绍](assets/marketing/bincode-browser-control-intro-16x9.png)

macOS 多浏览器管理与 AI 任务控制台，当前保存版本为 **1.1.1**。支持 140 个独立编号环境，通过自有浏览器插件和 MCP 接入 AI 任务。

## 项目内容

| 目录 | 内容 |
| --- | --- |
| `src/` | 本地服务、MCP、环境与任务管理、身份和结果核验 |
| `public/` | 控制台前端与分页组件 |
| `extension/` | 自有浏览器插件与调试会话管理 |
| `mac/` | macOS 原生 Swift 窗口及应用资源 |
| `scripts/` | 构建、启动、Codex 接入与诊断脚本 |
| `tests/` | 原有回归测试源码 |
| `handoff/` | 安装迁移工具、使用与开发说明、历史验收资料 |
| `backup-metadata/` | 来源、排除项和逐文件校验记录 |
| `assets/marketing/` | Codex 内置 image_gen 生成的横版产品介绍图 |

## 备份完整性

本次比较了现用安装、安装暂存、此前源码备份及原交接压缩包。原交接包共检查 59,243 个归档条目，其中 93 个源码及交接文件均与本次保存内容一致。原始 README 完整保存在 `handoff/installed-original-README.md`；此前源码提交历史另外保存为 Git bundle。

完整运行文件归档包括原生应用、固定版本 Chromium 与 140 个编号程序、Node.js、Codex CLI 和运行依赖；请在本仓库 Releases 下载。原始含登录资料的交接压缩包未原样上传，所有浏览器登录档案、cookie、session、管理员及插件令牌、模型认证和当前业务数据均留在本机。

## 开发入口

```sh
npm ci
npm test
npm start
```

以上为原项目开发命令。本次执行的是文件和归档完整性核验，没有运行店铺、业务操作或历史迁移安装器。140 个独立环境不表示 140 个同时运行的任务，实际并发由配置决定。

迁移脚本及历史验收材料按原内容保留，原迁移安装器依赖原交接包的数据和校验清单。去除登录资料的程序归档用于代码与运行文件留存，复原时应在新目录初始化独立资料。第三方组件来源与许可证见 `THIRD_PARTY_NOTICES.md` 和 `GitHub参考与版本.txt`。
