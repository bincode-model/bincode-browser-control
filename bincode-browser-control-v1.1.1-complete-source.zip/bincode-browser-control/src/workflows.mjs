import fs from 'node:fs';
import path from 'node:path';
import {DATA, now, writeJSON} from './store.mjs';

// Independent oracle: MIT saucelabs/sample-app-web at the pinned commit below.
// Expected prices never come from the browser values being tested.
export const SWAG_SOURCE = {repository:'https://github.com/saucelabs/sample-app-web',commit:'009b7a5b9db78488b014e689258840a6a7d7741f',url:'https://www.saucedemo.com/'};
export const SWAG_CATALOG = [
  {id:0,name:'Sauce Labs Bike Light',priceCents:999},
  {id:1,name:'Sauce Labs Bolt T-Shirt',priceCents:1599},
  {id:2,name:'Sauce Labs Onesie',priceCents:799},
  {id:3,name:'Test.allTheThings() T-Shirt (Red)',priceCents:1599},
  {id:4,name:'Sauce Labs Backpack',priceCents:2999},
  {id:5,name:'Sauce Labs Fleece Jacket',priceCents:4999},
];
export function validateWorkflow(value,profileId){
  if(!value||value.kind!=='swag-labs-v1')throw Error('未知表格工作流。');
  if(!/^[a-zA-Z0-9_-]{1,80}$/.test(value.runId||''))throw Error('测试编号无效。');
  const c=value.cases?.[profileId]||value.case;
  if(!c||c.profileId!==profileId)throw Error('任务表行与浏览器环境不一致。');
  if(!['standard_user','performance_glitch_user'].includes(c.username))throw Error('仅支持此练习网站公开的正常或慢速账号。');
  if(!['lohi','hilo'].includes(c.sort))throw Error('排序参数无效。');
  if(!Array.isArray(c.selectedIds)||c.selectedIds.length!==2||new Set(c.selectedIds).size!==2||c.selectedIds.some(id=>!Number.isInteger(id)||!SWAG_CATALOG.some(p=>p.id===id)))throw Error('请选择两个不同的有效练习商品。');
  return {kind:'swag-labs-v1',runId:value.runId,case:{profileId,username:c.username,sort:c.sort,selectedIds:[...c.selectedIds]}};
}
export function verifyInventory(items,sort){
  if(!Array.isArray(items)||items.length!==6||new Set(items.map(p=>p.name)).size!==6)throw Error('商品数或唯一性不符合预期。');
  for(const p of items){const expected=SWAG_CATALOG.find(x=>x.name===p.name);if(!expected||p.priceCents!==expected.priceCents)throw Error('商品价格与 GitHub 基准不符：'+p.name);}
  for(let i=1;i<items.length;i++)if(sort==='lohi'?items[i].priceCents<items[i-1].priceCents:items[i].priceCents>items[i-1].priceCents)throw Error('页面价格排序不正确。');
  return true;
}
export function verifyCart(items,selectedIds){
  const expected=selectedIds.map(id=>SWAG_CATALOG.find(p=>p.id===id));
  if(!Array.isArray(items)||items.length!==2||new Set(items.map(p=>p.name)).size!==2)throw Error('购物车应有两个不同商品。');
  for(const p of items){const e=expected.find(x=>x.name===p.name);if(!e||p.priceCents!==e.priceCents||p.quantity!==1)throw Error('购物车商品、单价或数量不符：'+p.name);}
  const totalCents=items.reduce((sum,p)=>sum+p.priceCents*p.quantity,0);
  if(totalCents!==expected.reduce((sum,p)=>sum+p.priceCents,0))throw Error('购物车金额不符。');
  return totalCents;
}
const inventoryCode=`[...document.querySelectorAll('.inventory_item')].map(e=>({name:e.querySelector('.inventory_item_name')?.textContent.trim(),priceCents:Math.round(Number(e.querySelector('.inventory_item_price')?.textContent.replace('$',''))*100)}))`;
const cartCode=`[...document.querySelectorAll('.cart_item')].map(e=>({name:e.querySelector('.inventory_item_name')?.textContent.trim(),priceCents:Math.round(Number(e.querySelector('.inventory_item_price')?.textContent.replace('$',''))*100),quantity:Number(e.querySelector('.cart_quantity')?.textContent.trim())}))`;
const sessionCode=`(()=>{const read=n=>decodeURIComponent(document.cookie.split('; ').find(c=>c.startsWith(n+'='))?.slice(n.length+1)||'');const h=document.querySelector('#ai-fleet-control-notice');return {username:read('session-username'),cookieProfile:read('fleet-benchmark-profile'),storageProfile:localStorage.getItem('fleet-benchmark-profile'),cartIds:JSON.parse(localStorage.getItem('cart-contents')||'[]'),noticeProfile:h?.dataset.profileId,noticeController:h?.dataset.controller,noticeText:h?.shadowRoot?.textContent,url:location.href};})()`;
function button(productId,verb){const p=SWAG_CATALOG.find(p=>p.id===productId);return `[data-test=${JSON.stringify(verb+'-'+p.name.replace(/\s+/g,'-').toLowerCase())}]`;}
export async function runWorkflow({job,fleet,handle,onEvent}){
  const workflow=validateWorkflow(job.workflow,job.profileId),c=workflow.case;
  const directory=path.join(DATA,'test-runs',workflow.runId);fs.mkdirSync(directory,{recursive:true,mode:0o700});
  const result={runId:workflow.runId,jobId:job.id,profileId:job.profileId,group:job.group,executionMode:'Codex-authored extension workflow',input:c,source:SWAG_SOURCE,startedAt:now(),steps:[],checks:{},screenshots:{},passed:false};
  job.benchmarkResult=result;
  const step=(name)=>{handle.abort.signal.throwIfAborted();job.currentStep=name;result.steps.push({name,time:now()});onEvent('workflow',name);fleet.changed();};
  const command=async(action,args={})=>{
    handle.abort.signal.throwIfAborted();const response=await fleet.command(job.profileId,action,args,{owner:job.id,controller:'Codex（表格任务）',background:job.background});
    if(response.proof?.via!=='chrome-extension'||!response.proof.debuggerAttached||response.proof.profileId!==job.profileId)throw Error('缺少目标插件实际执行回执。');
    if(result.extensionId&&result.extensionId!==response.proof.extensionId)throw Error('同一环境的插件身份发生变化。');result.extensionId=response.proof.extensionId;return response.result;
  };
  const evaluate=code=>command('evaluate',{code});
  const waitFor=async(code,label)=>{const until=Date.now()+30000;while(Date.now()<until){if(await evaluate(code))return;await new Promise(resolve=>setTimeout(resolve,250));}throw Error('等待页面状态超时：'+label);};
  const sessionCheck=s=>{if(s.username!==c.username||s.cookieProfile!==job.profileId||s.storageProfile!==job.profileId||s.noticeProfile!==job.profileId||!s.noticeController?.includes('Codex')||!s.noticeText?.includes('正在控制浏览器'))throw Error('登录、独立环境标记或页面控制提示不符。');};
  try{
    onEvent('execution_mode','执行模式：Codex 编排的插件流程；逐行读取任务表，浏览器操作与取数均由真实插件执行。');
    step('从任务表填写公开练习账号并登录');
    await command('navigate',{url:SWAG_SOURCE.url});
    await waitFor(`Boolean(document.querySelector('#login-button'))`,'登录页');
    const before=await evaluate(`({cookieProfile:document.cookie.split('; ').find(c=>c.startsWith('fleet-benchmark-profile='))?.split('=')[1]||'',storageProfile:localStorage.getItem('fleet-benchmark-profile')||''})`);
    if([before.cookieProfile,before.storageProfile].some(v=>v&&v!==job.profileId))throw Error('发现另一个环境的持久化标记。');result.previousSession=before;
    await command('fill',{selector:'#user-name',value:c.username});
    await command('fill',{selector:'#password',value:'secret_sauce'});
    await command('click',{selector:'#login-button'});
    await waitFor(`location.pathname==='/inventory.html'&&document.querySelectorAll('.inventory_item').length===6`,'商品列表');
    // Finish the login transition before sending trusted input to the inventory frame.
    await command('navigate',{url:SWAG_SOURCE.url+'inventory.html'});
    await waitFor(`document.querySelectorAll('.inventory_item').length===6`,'稳定的商品页面');
    await evaluate(`(()=>{document.cookie='fleet-benchmark-profile=${job.profileId}; Path=/; Max-Age=86400; SameSite=Lax';localStorage.setItem('fleet-benchmark-profile',${JSON.stringify(job.profileId)});return true;})()`);
    const originalCart=await evaluate(`JSON.parse(localStorage.getItem('cart-contents')||'[]')`);
    for(const id of originalCart)await command('click',{selector:button(id,'remove')});
    await waitFor(`!document.querySelector('.shopping_cart_badge')`,'清空旧练习购物车');
    step('设置价格排序，读取六件商品并核对 GitHub 基准');
    await evaluate(`(()=>{const s=document.querySelector('.product_sort_container');if(!s)throw Error('缺少排序下拉框');s.value=${JSON.stringify(c.sort)};s.dispatchEvent(new Event('change',{bubbles:true}));return s.value;})()`);
    await waitFor(`document.querySelector('.product_sort_container')?.value===${JSON.stringify(c.sort)}`,'价格排序');
    result.inventory=await evaluate(inventoryCode);verifyInventory(result.inventory,c.sort);result.checks.inventory=true;result.checks.sort=true;
    await evaluate('window.scrollTo(0,0)');result.screenshots.inventory=await command('screenshot');
    step('按表格选择两件商品，测试移除后重新加入');
    for(const [i,id] of c.selectedIds.entries()){
      const click=await command('click',{selector:button(id,'add-to-cart')});result.clickDiagnostics??=[];result.clickDiagnostics.push({id,click});
      await waitFor(`document.querySelector('.shopping_cart_badge')?.textContent===${JSON.stringify(String(i+1))}`,'逐个加购后的数量');
    }
    await waitFor(`document.querySelector('.shopping_cart_badge')?.textContent==='2'`,'两个商品计数');
    await command('click',{selector:button(c.selectedIds[0],'remove')});
    await waitFor(`document.querySelector('.shopping_cart_badge')?.textContent==='1'`,'移除后计数');
    await command('click',{selector:button(c.selectedIds[0],'add-to-cart')});
    await waitFor(`document.querySelector('.shopping_cart_badge')?.textContent==='2'`,'重新加入后计数');result.checks.removeAndReadd=true;
    step('打开购物车，读取数量、单价并计算金额');
    // scrollIntoView in the extension makes this a real trusted click, even if the page was scrolled.
    await command('click',{selector:'.shopping_cart_link'});
    await waitFor(`location.pathname==='/cart.html'&&document.querySelectorAll('.cart_item').length===2`,'购物车');
    result.cart=await evaluate(cartCode);result.totalCents=verifyCart(result.cart,c.selectedIds);result.totalUsd=result.totalCents/100;result.checks.cart=true;
    result.session=await evaluate(sessionCode);sessionCheck(result.session);result.checks.controllerBanner=true;result.checks.cookieIsolation=true;result.checks.storageIsolation=true;
    await evaluate('window.scrollTo(0,0)');result.screenshots.cart=await command('screenshot');
    step('关闭并重开同一浏览器，验证登录与购物车持久化');
    await fleet.release(job.profileId,job.id);await fleet.stop(job.profileId);handle.abort.signal.throwIfAborted();
    fleet.acquire(job.profileId,job.id,'Codex（表格任务）');await fleet.start(job.profileId,{background:job.background});
    await command('navigate',{url:SWAG_SOURCE.url+'cart.html'});
    await waitFor(`location.pathname==='/cart.html'&&document.querySelectorAll('.cart_item').length===2`,'重开后的购物车');
    result.reopenedCart=await evaluate(cartCode);verifyCart(result.reopenedCart,c.selectedIds);
    result.reopenedSession=await evaluate(sessionCode);sessionCheck(result.reopenedSession);
    if(JSON.stringify([...result.reopenedSession.cartIds].sort())!==JSON.stringify([...c.selectedIds].sort()))throw Error('重开后的本环境购物车存储不符。');
    result.checks.reopenPersistence=true;result.passed=true;step('全部项目通过');
  }catch(e){
    result.error=e.message;
    if(!handle.abort.signal.aborted)try{result.screenshots.failure=await command('screenshot');}catch{}
    throw e;
  }finally{
    result.endedAt=now();result.durationSeconds=Math.round((Date.parse(result.endedAt)-Date.parse(result.startedAt))/100)/10;
    result.actionCount=job.actions?.length||0;writeJSON(path.join(directory,job.profileId+'-'+job.id+'.json'),result);job.result=JSON.stringify(result,null,2);fleet.saveJobs();
  }
  return job.result;
}
