// Read only the account card rendered by JD. Never read cookies or login secrets.
export function readJdAccountCard() {
  const url = location.href;
  if (location.hostname !== 'shop.jd.com' || location.protocol !== 'https:') return {url};
  const value = element => (element?.getAttribute('title') || element?.textContent || '').trim();
  const cards = [...document.querySelectorAll('.shop-menu-accountV1__right-account')].filter(card => {
    const name = card.querySelector('.shop-menu-accountV1__right-account-top-name');
    const rect = name?.getBoundingClientRect();
    return rect?.width && rect?.height;
  });
  if (cards.length !== 1) return {url};
  const card = cards[0], fields = {};
  for (const row of card.querySelectorAll('.shop-menu-shop-cardV1__textItem')) {
    const key = value(row.querySelector('.shop-menu-shop-cardV1__textItem-key')).replace(/[：:\s]/g, '');
    if (['商家ID','店铺ID','登录账号','店铺主账号','商家类型'].includes(key)) {
      fields[key] = value(row.querySelector('.shop-menu-shop-cardV1__textItem-text'));
    }
  }
  return {url, shopName:value(card.querySelector('.shop-menu-accountV1__right-account-top-name')),
    shopId:fields['店铺ID'], merchantId:fields['商家ID'], merchantType:fields['商家类型'],
    loginAccount:fields['登录账号'], mainAccount:fields['店铺主账号']};
}

export const JD_IDENTITY_EXPRESSION = `(${readJdAccountCard.toString()})()`;

export function validateJdIdentity(value, snapshot) {
  if (!value || !snapshot) return null;
  let url;
  try { url = new URL(value.url); } catch { return null; }
  if (url.protocol !== 'https:' || url.hostname !== 'shop.jd.com' || /login|passport|signin/i.test(url.pathname) ||
      value.url !== snapshot.url || snapshot.elements?.some(e => e.type === 'password')) return null;
  const shopName = String(value.shopName || '').trim();
  const shopId = String(value.shopId || ''), merchantId = String(value.merchantId || '');
  if (shopName.length < 2 || shopName.length > 160 || !snapshot.text?.includes(shopName) ||
      !/^\d{1,20}$/.test(shopId) || !/^\d{1,20}$/.test(merchantId) || value.merchantType !== 'POP') return null;
  return {platform:'京东POP', shopName, shopId, merchantId, merchantType:'POP',
    loginAccount:String(value.loginAccount || '').slice(0,160), mainAccount:String(value.mainAccount || '').slice(0,160),
    storeKey:`jd:shop:${shopId}`, sourceUrl:value.url};
}

export function syncProfileIdentity(profile, identity, checkedAt) {
  const old = profile.verifiedIdentity;
  if (old && ['storeKey','shopName','merchantId','loginAccount','mainAccount'].every(key => old[key] === identity[key]) &&
      profile.name === identity.shopName && profile.displayName === identity.shopName) return null;
  const previous = {name:profile.name, storeId:profile.storeId, identity:old || null};
  if (!profile.catalogAssignment) {
    profile.catalogAssignment = Object.fromEntries(['name','displayName','nameAliases','storeId','storePlatform',
      'storeGroup','storeSourceRow','duplicateCandidates'].filter(key => profile[key] !== undefined).map(key => [key,structuredClone(profile[key])]));
  }
  profile.identityHistory ??= [];
  profile.identityHistory.push({checkedAt, previous, current:identity});
  profile.name = profile.displayName = identity.shopName;
  profile.nameAliases = [identity.shopName];
  profile.storeId = profile.actualStoreKey = identity.storeKey;
  profile.storePlatform = identity.platform;
  profile.storeGroup = '京东';
  delete profile.storeSourceRow;
  delete profile.duplicateCandidates;
  profile.verifiedIdentity = {...identity, verifiedAt:checkedAt};
  return previous;
}
