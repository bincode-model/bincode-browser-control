import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {EventEmitter} from 'node:events';
import {ROOT,DATA,initStore,loadJSON,writeJSON,now,sleep} from './store.mjs';
import {runAgent,providerStatus} from './providers.mjs';
import {validateWorkflow} from './workflows.mjs';
import {verifyReadReceipt,inspectLogin,assessJobResult} from './verification.mjs';
import {JD_IDENTITY_EXPRESSION,validateJdIdentity,syncProfileIdentity} from './identity.mjs';

export class Fleet extends EventEmitter {
  constructor(){
    super();this.config=initStore();this.pending=new Map();this.runtime=new Map();this.runningJobs=new Map();this.paused=false;
    this.jobs=loadJSON(path.join(DATA,'jobs.json'),[]);
    for(const j of this.jobs)if(['running','starting'].includes(j.status)){j.status='interrupted';j.error='控制台重启后未自动重跑，请重试任务。';j.endedAt=now();}
    this.credentials=loadJSON(path.join(DATA,'providers.json'),{});
    for(const p of this.config.profiles)this.runtime.set(p.id,{status:'stopped',socket:null,pid:null,lease:null,controller:null,chain:Promise.resolve(),starting:null,extensionId:null,lastSeen:null,error:null,attachedTabs:[]});
    this.adoptProcesses();this.saveJobs();
    this.timer=setInterval(()=>{this.expireLeases();this.refreshControls();this.pump().catch(e=>this.log('error',e.message));},1000);this.timer.unref();
  }
  profile(id){const p=this.config.profiles.find(p=>p.id===id);if(!p)throw Error('环境不存在：'+id);return p;}
  rt(id){this.profile(id);return this.runtime.get(id);}
  save(){writeJSON(path.join(DATA,'fleet.json'),this.config);}
  saveJobs(){writeJSON(path.join(DATA,'jobs.json'),this.jobs);this.changed();}
  changed(){this.emit('change');}
  log(type,message,detail={}){const entry={time:now(),type,message,...detail};fs.appendFileSync(path.join(DATA,'events.jsonl'),JSON.stringify(entry)+'\n',{mode:0o600});this.emit('event',entry);this.changed();}
  processRows(){try{return execFileSync('/bin/ps',['-axo','pid=,ppid=,rss=,command='],{encoding:'utf8',timeout:3000}).split('\n').map(line=>{const m=line.trim().match(/^(\d+)\s+(\d+)\s+(\d+)\s+(.+)$/);return m?{pid:+m[1],ppid:+m[2],rss:+m[3],command:m[4]}:null;}).filter(Boolean);}catch{return [];}}
  adoptProcesses(){
    for(const row of this.processRows())if(!row.command.includes('--type='))for(const p of this.config.profiles){if(row.command.includes(`--user-data-dir=${path.join(DATA,'profiles',p.id)}`)){const r=this.rt(p.id);r.pid=row.pid;r.status='reconnecting';}}
  }
  activeCount(){return [...this.runtime.values()].filter(r=>r.pid||r.starting).length;}
  resources(){
    const t=Date.now();if(this.resourceCache&&t-this.resourceCache.at<4000)return this.resourceCache.data;
    const rows=this.processRows();let fleetMemoryMB=0;
    for(const p of this.config.profiles){const r=this.rt(p.id);r.memoryMB=rows.filter(row=>row.command.includes(`--user-data-dir=${path.join(DATA,'profiles',p.id)}`)).reduce((sum,row)=>sum+row.rss,0)/1024;fleetMemoryMB+=r.memoryMB;
      if(r.pid&&!rows.some(row=>row.pid===r.pid)&&!r.starting){r.pid=null;if(!r.socket)r.status='stopped';}}
    const data={totalMemoryGB:os.totalmem()/1024**3,freeMemoryGB:os.freemem()/1024**3,cpuCount:os.cpus().length,loadAverage:os.loadavg()[0],fleetMemoryMB:Math.round(fleetMemoryMB),activeBrowsers:this.activeCount()};
    this.resourceCache={at:t,data};return data;
  }
  publicState(){
    const resources=this.resources();return {version:'1.1.1',time:now(),paused:this.paused,settings:{port:this.config.port,maxBrowsers:this.config.maxBrowsers,maxAgents:this.config.maxAgents,autoClose:this.config.autoClose,groupSize:10,taskTimeoutMinutes:this.config.taskTimeoutMinutes,chrome:this.config.chrome,retainedProfileIds:this.config.retainedProfileIds||[]},resources,
      providers:providerStatus(this.credentials),profiles:this.config.profiles.map(({token,...p})=>{const r=this.rt(p.id);return {...p,status:r.status,pid:r.pid,connected:!!r.socket,extensionId:r.extensionId,lastSeen:r.lastSeen,error:r.error,controller:r.controller,controlMode:r.lease?.kind||null,controlProof:r.controlProof||null,login:r.login||{state:'unknown',label:'尚未核验'},userStopped:!!r.userStopped,owner:r.lease?.owner||null,attachedTabs:r.attachedTabs,memoryMB:Math.round(r.memoryMB||0),userDataDir:path.join(DATA,'profiles',p.id),extensionDir:path.join(DATA,'extensions',p.id)};}),jobs:this.jobs.map(({events,benchmarkResult:b,...j})=>j.workflow?{...j,result:null,benchmark:b?{passed:b.passed,inventoryCount:b.inventory?.length||0,totalUsd:b.totalUsd,durationSeconds:b.durationSeconds,extensionId:b.extensionId,checks:b.checks,screenshots:b.screenshots}:null}:j)};
  }
  connect(ws,hello){
    const p=this.profile(hello.profileId);if(typeof hello.token!=='string'||!crypto.timingSafeEqual(Buffer.from(p.token),Buffer.from(hello.token.padEnd(p.token.length,' ').slice(0,p.token.length)))||hello.token.length!==p.token.length)throw Error('插件身份认证失败。');
    const r=this.rt(p.id);if(r.socket&&r.socket!==ws)r.socket.close(1000,'reconnected');r.socket=ws;r.extensionId=hello.extensionId;r.lastSeen=now();r.controller=null;r.controlProof=null;r.status=r.lease?'reserved':'idle';r.error=null;
    ws.profileId=p.id;this.log('connected','插件已连接',{profileId:p.id,extensionId:hello.extensionId});
    ws.on('close',()=>{if(r.socket!==ws)return;r.socket=null;r.controller=null;r.controlProof=null;r.login={state:'unknown',label:'连接中断，需重新核验'};r.attachedTabs=[];r.status=r.pid?'disconnected':'stopped';
      for(const [id,item] of this.pending)if(item.socket===ws){clearTimeout(item.timeout);item.reject(Error('插件连接中断。'));this.pending.delete(id);}this.changed();});
  }
  receive(ws,m){
    const r=this.rt(ws.profileId);if(r.socket!==ws)return;r.lastSeen=now();
    if(m.type==='result'){
      const item=this.pending.get(m.id);if(!item||item.socket!==ws)return;this.pending.delete(m.id);clearTimeout(item.timeout);
      if(m.ok)item.resolve(m.data);else item.reject(Error(m.error||'插件操作失败。'));
    }else if(['control','heartbeat'].includes(m.type)){
      r.attachedTabs=m.attachedTabs||[];
      r.controller=r.attachedTabs.length&&m.owner===r.lease?.owner&&r.controlProof?m.controller:null;
      r.status=r.controller?'controlling':r.lease?'reserved':'idle';
      if(m.revoked){r.userStopped=true;for(const job of this.jobs.filter(j=>j.profileId===ws.profileId&&['queued','running','starting'].includes(j.status)))this.cancelJob(job.id,'用户在浏览器中停止控制');r.lease=null;r.controller=null;r.controlProof=null;r.status='idle';}
      this.changed();
    }
  }
  raw(id,action,args={},owner='console',controller='AI'){
    const r=this.rt(id);if(!r.socket||r.socket.readyState!==1)throw Error('浏览器插件未连接。');
    return new Promise((resolve,reject)=>{const requestId=crypto.randomUUID();const timeout=setTimeout(()=>{this.pending.delete(requestId);reject(Error('插件操作超时：'+action));},45000);
      this.pending.set(requestId,{resolve,reject,timeout,socket:r.socket});r.socket.send(JSON.stringify({type:'command',id:requestId,action,args,owner,controller}));});
  }
  async start(id,{background=false,initialUrl}={}){
    const p=this.profile(id),r=this.rt(id);
    if(p.duplicateOf)throw Error(`此店铺已归并到 ${p.duplicateOf}；原编号和目录仍保留。`);
    if(initialUrl&&initialUrl!==`http://127.0.0.1:${this.config.port}/welcome/${id}`)throw Error('验证入口只能使用本环境的本机验证页。');
    const entry=initialUrl||p.entryUrl||(!p.storeId?`http://127.0.0.1:${this.config.port}/welcome/${id}`:null);
    if(!entry)throw Error('商家后台入口待核验，请先在环境设置填写已确认的网址。');
    if(r.socket)return {id,pid:r.pid,connected:true,extensionId:r.extensionId};
    if(r.starting)return r.starting;
    if(!r.pid&&this.activeCount()>=this.config.maxBrowsers)throw Error(`已达到 ${this.config.maxBrowsers} 个浏览器并发上限，请关闭空闲环境或调整设置。`);
    r.status='starting';r.error=null;
    r.starting=(async()=>{
      if(!r.pid){
        const numberedRoot=path.join(ROOT,'runtime','numbered-browsers');
        const numberedChrome=path.join(numberedRoot,`浏览器 ${id.slice(4)}.app`,'Contents','MacOS','Chromium');
        const chrome=process.platform==='darwin'&&fs.existsSync(numberedRoot)?numberedChrome:this.config.chrome;
        if(!chrome||!fs.existsSync(chrome))throw Error(`找不到 ${id} 对应的浏览器：${chrome||'未配置'}`);
        for(const ext of p.extraExtensions)if(!fs.existsSync(path.join(ext,'manifest.json')))throw Error('插件目录缺少 manifest.json：'+ext);
        const ownExt=path.join(DATA,'extensions',id),userData=path.join(DATA,'profiles',id);
        const args=[`--user-data-dir=${userData}`,'--profile-directory=Default',`--load-extension=${[ownExt,...p.extraExtensions].join(',')}`,'--no-first-run','--no-default-browser-check','--no-proxy-server','--disable-background-networking','--disable-component-update','--disable-sync','--disable-features=Translate,OptimizationHints,MediaRouter','--window-size=1200,820',entry];
        // Chromium's testing mode avoids one macOS Keychain dialog per process.
        // Profiles remain persistent, separate, and readable only by this user.
        if(process.platform==='darwin')args.splice(-1,0,'--use-mock-keychain');
        if(background)args.splice(-1,0,'--headless=new');
        const log=fs.openSync(path.join(DATA,`${id}-chrome.log`),'a',0o600);
        const child=spawn(chrome,args,{cwd:ROOT,stdio:['ignore',log,log],detached:true});fs.closeSync(log);child.unref();r.pid=child.pid;r.child=child;
        child.on('error',e=>{r.error=e.message;r.pid=null;r.status='error';this.changed();});
        child.on('exit',()=>{if(r.child===child){r.pid=null;r.child=null;r.status='stopped';r.socket?.close();r.lease=null;r.controller=null;this.changed();}});
      }
      for(let n=0;n<900;n++){if(r.socket)return {id,pid:r.pid,connected:true,extensionId:r.extensionId};if(!r.pid)throw Error(r.error||'浏览器进程已退出。');await sleep(100);}
      throw Error('浏览器已启动，但插件 90 秒内未连接。检查环境日志。');
    })();this.changed();
    try{return await r.starting;}catch(e){r.status='error';r.error=e.message;if(r.pid){try{process.kill(r.pid,'SIGTERM');}catch{}}throw e;}finally{r.starting=null;this.changed();}
  }
  async launch(id,{initialUrl}={}){
    const r=this.rt(id);if(r.launching)return r.launching;
    r.userStopped=false;
    r.launching=(async()=>{
      await this.start(id,{background:false,initialUrl});
      if(r.lease&&r.lease.kind!=='standby')throw Error('本环境已有任务控制，请查看当前任务。');
      const owner='standby-'+id+'-'+crypto.randomUUID(),controller='控制台（待命）';
      this.acquire(id,owner,controller);r.lease.kind='standby';
      try{
        let data,lastError;
        for(const deadline=Date.now()+90000;Date.now()<deadline;){
          try{data=await this.command(id,'snapshot',{}, {owner,controller});if(data.result.text.trim())break;}
          catch(e){lastError=e;if(r.userStopped||r.lease?.owner!==owner)throw e;}
          await sleep(400);
        }
        if(!data?.result?.text?.trim())throw lastError||Error('页面尚未加载出可读取内容，请重新核验。');
        if(!initialUrl&&this.profile(id).entryUrl&&data.result?.url?.startsWith(`http://127.0.0.1:${this.config.port}/welcome/`)){
          await this.command(id,'navigate',{url:this.profile(id).entryUrl},{owner,controller});
          data=await this.command(id,'snapshot',{}, {owner,controller});
        }
        r.controlProof=verifyReadReceipt(data,id,r.extensionId);r.login=inspectLogin(data.result,this.profile(id));
        r.controller=controller;r.status='controlling';this.changed();
        return {id,pid:r.pid,connected:true,controlMode:'standby',controlProof:r.controlProof,login:r.login};
      }catch(e){await this.release(id,owner).catch(()=>{});r.error=e.message;this.changed();throw e;}
    })();
    try{return await r.launching;}finally{r.launching=null;}
  }
  refreshControls(){
    for(const [id,r] of this.runtime){
      if(r.lease?.kind!=='standby'||!r.socket||!r.controlProof||r.userStopped||r.refreshing||Date.now()-(r.lastReadAt||0)<15000)continue;
      r.lastReadAt=Date.now();r.refreshing=true;
      this.command(id,'snapshot',{}, {owner:r.lease.owner,controller:r.lease.controller})
        .catch(e=>{r.controller=null;r.controlProof=null;r.error=e.message;this.changed();})
        .finally(()=>{r.refreshing=false;});
    }
  }
  async stop(id,{force=false}={}){
    const r=this.rt(id);if(r.lease&&r.lease.kind!=='standby'&&!force)throw Error('此环境正在被 AI 控制，请先停止任务或释放控制。');
    if(r.socket)await this.release(id,r.lease?.owner,true).catch(()=>{});
    const pid=r.pid;if(!pid){r.status='stopped';this.changed();return {id,stopped:true};}
    const identity=this.processRows().find(row=>row.pid===pid);if(identity&&!identity.command.includes(`--user-data-dir=${path.join(DATA,'profiles',id)}`))throw Error('进程身份不匹配，停止操作已取消。');
    try{process.kill(pid,'SIGTERM');}catch(e){if(e.code!=='ESRCH')throw e;}
    for(let i=0;i<100;i++){try{process.kill(pid,0);}catch{r.pid=null;r.status='stopped';r.lease=null;r.socket?.close();this.changed();return {id,stopped:true};}await sleep(100);}
    throw Error('浏览器仍在退出，请稍后重试。');
  }
  acquire(id,owner,controller){
    const r=this.rt(id);if(!owner)throw Error('缺少控制会话身份。');
    if(r.userStopped)throw Error('用户已停止控制，请显式点击重新连接或重新提交任务。');
    if(r.lease&&r.lease.owner!==owner&&r.lease.kind!=='standby')throw Error(`环境由 ${r.lease.controller} 的另一任务占用。`);
    const same=r.lease?.owner===owner,kind=same?r.lease.kind:'task';
    if(!same){r.controlProof=null;r.controller=null;}
    r.lease={owner,controller,kind,lastUsed:Date.now()};if(r.socket&&!r.controller)r.status='reserved';this.changed();
  }
  async command(id,action,args={},meta={}){
    const r=this.rt(id),owner=meta.owner||'console',controller=meta.controller||'控制台';
    const owningJob=this.jobs.find(j=>j.id===owner);if(owningJob&&owningJob.status==='cancelled')throw Error('任务已经取消。');
    if(action==='release')return this.release(id,owner);
    this.acquire(id,owner,controller);
    const task=async()=>{
      if(r.lease?.owner!==owner)throw Error('控制会话已停止。');
      await this.start(id,{background:meta.background===true});
      const started=Date.now();const data=await this.raw(id,action,args,owner,controller);
      if(r.lease?.owner!==owner||r.userStopped)throw Error('控制会话已停止，忽略迟到回执。');
      if(data.proof&&(data.proof.profileId!==id||data.proof.extensionId!==r.extensionId))throw Error('插件执行回执与目标环境不匹配。');
      if(action==='snapshot'){
        r.controlProof=verifyReadReceipt(data,id,r.extensionId);
        r.login=inspectLogin(data.result,this.profile(id));
        if(/^https:\/\/shop\.jd\.com(?:\/|$)/.test(data.result.url)){
          const account=await this.raw(id,'evaluate',{code:JD_IDENTITY_EXPRESSION},owner,controller);
          if(r.lease?.owner!==owner||r.userStopped)throw Error('控制会话已停止，忽略迟到身份回执。');
          if(account.proof?.profileId!==id||account.proof?.extensionId!==r.extensionId||!account.proof?.debuggerAttached||
            !account.proof.attachedTabs?.some(tab=>data.proof.attachedTabs.includes(tab)))throw Error('店铺身份读取回执与当前浏览器不符。');
          const identity=validateJdIdentity(account.result,data.result);
          if(identity){
            data.result.identity={...identity,url:identity.sourceUrl};
            const previous=syncProfileIdentity(this.profile(id),identity,account.proof.timestamp||now());
            if(previous){this.save();this.log('identity','已按实际登录店铺更新本机名称与身份',{profileId:id,previous,current:identity});}
            r.login=inspectLogin(data.result,this.profile(id));
            if(owningJob?.expectedStoreKey&&owningJob.expectedStoreKey!==identity.storeKey)throw Error('实际登录店铺已变化；任务未继续，请按新店铺重新提交。');
          }
        }
        r.login=inspectLogin(data.result,this.profile(id));r.lastReadAt=Date.now();
      }
      if(data.proof?.debuggerAttached&&r.controlProof){r.controller=controller;r.status='controlling';}
      const job=this.jobs.find(j=>j.id===owner);
      if(job&&data.proof?.debuggerAttached){job.actions??=[];job.actions.push({action,time:now(),extensionId:r.extensionId,profileId:id});}
      if(r.lease)r.lease.lastUsed=Date.now();
      this.log('command','插件已执行 '+action,{profileId:id,owner,controller,extensionId:r.extensionId,durationMs:Date.now()-started,proof:data.proof});
      if(action==='screenshot'&&data.result?.data){
        const name=`${id}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}.png`;const file=path.join(DATA,'artifacts',name);fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});fs.writeFileSync(file,Buffer.from(data.result.data,'base64'),{mode:0o600});data.result={artifactUrl:'/api/artifacts/'+name,file,mimeType:'image/png'};
      }
      return data;
    };
    const next=r.chain.then(task);r.chain=next.catch(()=>{});return next;
  }
  async release(id,owner,force=false){
    const r=this.rt(id);if(r.lease&&r.lease.owner!==owner&&!force)throw Error('只有当前控制会话可以释放环境。');
    await r.chain;
    if(r.socket)await this.raw(id,'release',{},owner||'console').catch(()=>{});
    r.lease=null;r.controller=null;r.controlProof=null;r.attachedTabs=[];if(r.socket)r.status='idle';this.changed();return {released:true};
  }
  expireLeases(){for(const [id,r] of this.runtime)if(r.lease&&r.lease.kind!=='standby'&&!this.runningJobs.has(r.lease.owner)&&Date.now()-r.lease.lastUsed>120000)this.release(id,r.lease.owner).catch(()=>{});}
  settings(value){
    if(value.retainedProfileIds!==undefined){
      if(!Array.isArray(value.retainedProfileIds)||value.retainedProfileIds.length>140)throw Error('保留环境必须是编号列表。');
      value.retainedProfileIds=[...new Set(value.retainedProfileIds)];value.retainedProfileIds.forEach(id=>this.profile(id));
    }
    for(const key of ['maxBrowsers','maxAgents'])if(value[key]!==undefined){if(!Number.isInteger(value[key])||value[key]<1||value[key]>10)throw Error('并发数量必须在 1–10 之间。');}
    if(value.maxBrowsers!==undefined&&value.maxBrowsers<this.activeCount())throw Error('请先关闭浏览器，再降低并发上限。');
    if(value.taskTimeoutMinutes!==undefined&&(!Number.isInteger(value.taskTimeoutMinutes)||value.taskTimeoutMinutes<1||value.taskTimeoutMinutes>240))throw Error('任务超时必须在 1–240 分钟之间。');
    if(value.autoClose!==undefined&&typeof value.autoClose!=='boolean')throw Error('自动关闭设置必须为布尔值。');
    for(const key of ['maxBrowsers','maxAgents','autoClose','taskTimeoutMinutes','retainedProfileIds'])if(value[key]!==undefined)this.config[key]=value[key];
    this.save();this.changed();return this.publicState().settings;
  }
  updateProfile(id,value){
    const p=this.profile(id),r=this.rt(id);if(r.lease)throw Error('请先停止此环境的任务。');
    if(value.name!==undefined){p.name=String(value.name).trim().slice(0,160)||p.name;p.displayName=p.name;}
    if(value.provider!==undefined){if(!['codex','claude-cli','openai','anthropic','kimi','perplexity','compatible'].includes(value.provider))throw Error('未知 AI 控制器。');p.provider=value.provider;}
    if(value.entryUrl!==undefined){if(value.entryUrl&&!/^https?:\/\//.test(value.entryUrl))throw Error('入口网址需要以 http:// 或 https:// 开头。');p.entryUrl=value.entryUrl;}
    if(value.extraExtensions!==undefined){if(!Array.isArray(value.extraExtensions))throw Error('插件目录必须是数组。');const next=value.extraExtensions.map(x=>path.resolve(x));if(r.pid&&JSON.stringify(next)!==JSON.stringify(p.extraExtensions))throw Error('添加插件前请关闭此环境。');for(const x of next)if(!fs.existsSync(path.join(x,'manifest.json')))throw Error('无效插件目录：'+x);p.extraExtensions=next;}
    this.save();this.changed();return {...p,token:undefined};
  }
  configureProvider(id,value){
    if(!['openai','anthropic','kimi','perplexity','compatible'].includes(id))throw Error('不可配置此控制器。');
    this.credentials[id]={...this.credentials[id],...value};if(this.credentials[id].baseUrl&&!/^https?:\/\//.test(this.credentials[id].baseUrl))throw Error('API 地址无效。');writeJSON(path.join(DATA,'providers.json'),this.credentials);this.changed();return providerStatus(this.credentials);
  }
  enqueue({profileIds,prompt,provider,background=false,batchId,workflow}){
    if(!Array.isArray(profileIds)||!profileIds.length||profileIds.length>140)throw Error('请选择 1–140 个环境。');
    if(typeof prompt!=='string'||!prompt.trim()||prompt.length>40000)throw Error('任务描述需要 1–40000 个字符。');
    const available=providerStatus(this.credentials);const batch=batchId||crypto.randomUUID();
    const selected=[...new Set(profileIds)].map(id=>{const p=this.profile(id),pr=provider||p.provider;if(p.duplicateOf)throw Error('重复入口已归并到 '+p.duplicateOf);if(!available.find(x=>x.id===pr)?.ready)throw Error('AI 控制器尚未配置：'+pr);if(workflow&&pr!=='codex')throw Error('此练习工作流由 Codex 编排。');return {p,pr,w:workflow?validateWorkflow(workflow,id):undefined};});
    const added=selected.map(({p,pr,w},index)=>({id:crypto.randomUUID(),batchId:batch,profileId:p.id,expectedStoreKey:p.verifiedIdentity?.storeKey||null,storeName:p.name,group:w?p.group:Math.floor(index/10)+1,batchIndex:Math.floor(index/10)+1,batchCount:Math.ceil(selected.length/10),provider:pr,prompt:prompt.trim(),background,status:'queued',createdAt:now(),events:[],result:null,...(w?{workflow:w,executionMode:'workflow'}:{})}));
    selected.forEach(({p})=>{this.rt(p.id).userStopped=false;});
    this.jobs.push(...added);this.saveJobs();this.pump();return added;
  }
  async pump(){
    if(this.paused||this.pumping||!this.jobs.some(j=>j.status==='queued'))return;this.pumping=true;let updated=false;
    try{
      for(const j of this.jobs.filter(j=>j.status==='queued')){
        if(this.runningJobs.size>=this.config.maxAgents)break;
        const earlier=this.jobs.some(other=>other.batchId===j.batchId&&other.group<j.group&&(['queued','starting','running'].includes(other.status)||this.runningJobs.has(other.id)));if(earlier)continue;
        const r=this.rt(j.profileId);if(r.userStopped||(r.lease&&r.lease.kind!=='standby'))continue;
        if(!r.pid&&this.activeCount()>=this.config.maxBrowsers)continue;
        const handle={abort:new AbortController(),process:null};this.runningJobs.set(j.id,handle);j.status='starting';j.startedAt=now();this.acquire(j.profileId,j.id,availableLabel(j.provider));
        updated=true;
        this.runJob(j,handle).catch(e=>this.log('error',e.message,{jobId:j.id}));
      }
    }finally{this.pumping=false;if(updated)this.saveJobs();}
  }
  async runJob(j,handle){
    const timeout=setTimeout(()=>this.cancelJob(j.id,'任务超时'),this.config.taskTimeoutMinutes*60000);
    const addEvent=(type,message)=>{j.events.push({time:now(),type,message});if(j.events.length>500)j.events.shift();fs.mkdirSync(path.join(DATA,'jobs'),{recursive:true,mode:0o700});fs.appendFileSync(path.join(DATA,'jobs',j.id+'.jsonl'),JSON.stringify({time:now(),type,message})+'\n',{mode:0o600});this.emit('jobEvent',{jobId:j.id,type,message});};
    try{
      await this.start(j.profileId,{background:j.background});if(handle.abort.signal.aborted)throw Error('任务已取消。');
      if(j.expectedStoreKey&&!j.workflow)await this.command(j.profileId,'snapshot',{}, {owner:j.id,controller:availableLabel(j.provider)});
      j.status='running';this.saveJobs();addEvent('start',`${availableLabel(j.provider)} 已接入 ${j.profileId} 的插件。`);
      j.result=await runAgent({job:j,fleet:this,handle,onEvent:addEvent,credentials:this.credentials[j.provider]||{}});
      if(handle.abort.signal.aborted)throw Error(j.error||'任务已取消。');
      const assessment=assessJobResult(j);j.status=assessment.status;j.error=assessment.reason;
    }catch(e){if(j.status!=='cancelled'){j.status='failed';j.error=e.message;}addEvent('error',e.message);}
    finally{clearTimeout(timeout);await this.release(j.profileId,j.id).catch(()=>{});if(this.config.autoClose)await this.stop(j.profileId).catch(e=>addEvent('cleanup',e.message));j.endedAt=now();this.runningJobs.delete(j.id);this.saveJobs();this.log('job',j.status,{profileId:j.profileId,jobId:j.id,provider:j.provider});this.pump();}
  }
  cancelJob(id,reason='任务已取消'){
    const j=this.jobs.find(j=>j.id===id);if(!j)throw Error('任务不存在。');if(!['queued','starting','running'].includes(j.status))return j;
    j.status='cancelled';j.error=reason;const handle=this.runningJobs.get(id);handle?.abort.abort();if(handle?.process)handle.process.kill('SIGTERM');this.saveJobs();return j;
  }
  retryJob(id){const j=this.jobs.find(j=>j.id===id);if(!j)throw Error('任务不存在。');return this.enqueue({profileIds:[j.profileId],prompt:j.prompt,provider:j.provider,background:j.background,...(j.workflow?{workflow:j.workflow,batchId:j.batchId}:{})});}
  async emergencyStop(){this.paused=true;for(const j of this.jobs)if(['queued','starting','running'].includes(j.status))this.cancelJob(j.id,'已全部停止');for(const [id,r] of this.runtime)if(r.socket)await this.release(id,r.lease?.owner,true).catch(()=>{});this.changed();return {stopped:true};}
}
export function availableLabel(id){return {codex:'Codex','claude-cli':'Claude',openai:'ChatGPT / OpenAI',anthropic:'Claude',kimi:'Kimi',perplexity:'Perplexity',compatible:'自定义 AI'}[id]||id;}
