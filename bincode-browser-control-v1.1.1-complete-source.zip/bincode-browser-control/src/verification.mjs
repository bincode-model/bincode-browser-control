import {validateJdIdentity} from './identity.mjs';

export function verifyReadReceipt(data, profileId, extensionId) {
  if (!data?.proof || data.proof.profileId !== profileId ||
      data.proof.extensionId !== extensionId || data.proof.debuggerAttached !== true ||
      !data.proof.attachedTabs?.length || !/^https?:\/\//.test(data.result?.url || '') ||
      typeof data.result.text !== 'string') {
    throw Error('未取得与本店铺、插件及实际页面一致的调试读取回执。');
  }
  return {profileId, extensionId, debuggerAttached:true, url:data.result.url,
    title:data.result.title || '', checkedAt:data.proof.timestamp};
}

export function inspectLogin(snapshot, profile) {
  const url = snapshot?.url || '', text = snapshot?.text || '';
  if (/^https?:\/\/(127\.0\.0\.1|localhost)(:|\/)/.test(url)) return {state:'local_test',label:'本机验证页'};
  if (/ERR_|无法访问此网站|无法连接|连接已重置/.test(text)) return {state:'page_error',label:'页面访问失败'};
  if (/滑块|拖动.*拼图|安全验证|人机验证|完成验证/.test(text)) return {state:'waiting_verification',label:'等待本人验证'};
  if (/login|passport|signin/i.test(url) || snapshot?.elements?.some(e=>e.type==='password') ||
      /扫码登录|扫描二维码.*登录|账号密码登录|短信登录|请先登录/.test(text)) {
    return {state:'waiting_login',label:'等待本人登录'};
  }
  const identity = validateJdIdentity(snapshot?.identity, snapshot);
  if (identity) return {state:'logged_in',label:'已登录 · 店铺ID已核验',matchedName:identity.shopName,
    shopId:identity.shopId,merchantId:identity.merchantId,storeKey:identity.storeKey};
  // JD requires an actual account-card ID, not a historical name match.
  if (/^https:\/\/shop\.jd\.com(?:\/|$)/.test(url)) return {state:'identity_pending',label:'当前店铺身份待核验'};
  // A brand or an unrelated page is not sufficient proof of this store.
  const names = [profile.name, ...(profile.nameAliases || [])].filter(Boolean);
  const matched = names.find(n => n.length >= 5 && text.includes(n));
  if (matched && /退出登录|订单管理|店铺管理/.test(text)) return {state:'logged_in',label:'店名已核验',matchedName:matched};
  return {state:'identity_pending',label:'登录与店名待核验'};
}

export function assessJobResult(job) {
  if (job.workflow) return job.benchmarkResult?.passed
    ? {status:'succeeded',reason:null} : {status:'needs_review',reason:'练习工作流缺少验收结果。'};
  const result = String(job.result || '');
  if (/尚未.*业务数据|停在登录页|跳转[至到].*登录页|请先.*登录|等待.*登录|在\s*env-\d+\s*登录/.test(result)) {
    return {status:'waiting_login',reason:'尚未登录或完成本人验证，业务任务未完成。'};
  }
  if (/补充.*(日期|类型|范围)|明确.*(取数|范围)|缺少.*(范围|日期)|等待.*确认/.test(result)) {
    return {status:'needs_input',reason:'缺少任务数据类型、范围或日期。'};
  }
  // CLI exit code and browser actions prove execution, not business acceptance.
  return {status:'needs_review',reason:'执行结果已保存，尚需核验任务目标与交付数据，未计为完成。'};
}
