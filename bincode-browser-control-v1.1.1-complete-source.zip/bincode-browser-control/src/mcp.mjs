import fs from 'node:fs';
import crypto from 'node:crypto';
import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
import {z} from 'zod';
import {api} from './client.mjs';

const at=process.argv.indexOf('--profile'),bound=at>=0?process.argv[at+1]:null;
const owner=process.env.FLEET_OWNER||'mcp-'+crypto.randomUUID();
const controller=process.env.FLEET_CONTROLLER||'AI';
const touched=new Set();
const server=new McpServer({name:'ai-browser-fleet',version:'1.1.1'},{instructions:'All browser actions execute inside the selected profile’s installed extension. Choose profileId explicitly unless this MCP is bound to one profile. Read snapshot before clicking. Never claim completion without actual tool results.'});
const profileSchema={profileId:z.string().optional().describe(bound?`固定环境 ${bound}，无需填写；不允许控制其他环境。`:'环境编号，如 env-001。')};
function idFor(args){const id=args.profileId||bound;if(!id)throw Error('必须填写 profileId。');if(bound&&id!==bound)throw Error('MCP 已绑定 '+bound+'，不允许控制其他环境。');return id;}
async function command(action,args){const id=idFor(args);touched.add(id);return api('/api/command',{profileId:id,action,args,owner,controller,background:process.env.FLEET_BACKGROUND==='true'});}
function register(name,description,schema,fn){server.registerTool(name,{description,inputSchema:schema},async args=>{
  try{const r=await fn(args);const content=[{type:'text',text:JSON.stringify(r)}];if(r.result?.mimeType==='image/png'&&r.result?.file)content.unshift({type:'image',mimeType:'image/png',data:fs.readFileSync(r.result.file).toString('base64')});return {content};}catch(e){return {isError:true,content:[{type:'text',text:e.message}]};}
});}
register('fleet_status','查看 140 个环境、实际插件连接和并发状态。',{},async()=>{const state=await api('/api/state');if(bound)return {settings:state.settings,profiles:state.profiles.filter(p=>p.id===bound)};return state;});
register('browser_navigate','通过本环境的 AI 插件打开 HTTP/HTTPS 网站。',{...profileSchema,url:z.string().url(),newTab:z.boolean().optional()},args=>command('navigate',args));
register('browser_snapshot','通过插件读取网页内容及可交互元素 @e 引用。',profileSchema,args=>command('snapshot',args));
register('browser_tabs','列出本环境标签页。',profileSchema,args=>command('tabs',args));
register('browser_select_tab','选择本环境的标签页。',{...profileSchema,tabId:z.number().int()},args=>command('select_tab',args));
register('browser_click','通过插件向网页发送真实鼠标点击。',{...profileSchema,selector:z.string()},args=>command('click',args));
register('browser_fill','通过插件清空并填写输入框。',{...profileSchema,selector:z.string(),value:z.string()},args=>command('fill',args));
register('browser_press_key','通过插件发送 Enter、Tab、Escape 等按键。',{...profileSchema,key:z.string()},args=>command('press_key',args));
register('browser_scroll','通过插件滚动网页。',{...profileSchema,x:z.number().optional(),y:z.number()},args=>command('scroll',args));
register('browser_evaluate','通过插件在当前网页执行 JS 并返回真实结果。',{...profileSchema,code:z.string()},args=>command('evaluate',args));
register('browser_screenshot','通过插件保存和返回网页截图。',profileSchema,args=>command('screenshot',args));
register('browser_release','释放 AI 控制；移除提示并解除插件调试连接。',profileSchema,async args=>{const id=idFor(args);touched.delete(id);return api('/api/release',{profileId:id,owner});});
if(!bound)register('fleet_run_tasks','给多个独立环境提交 AI 任务；每批最多 10 家依次执行。',{profileIds:z.array(z.string()).min(1).max(140),prompt:z.string(),provider:z.enum(['codex','claude-cli','openai','anthropic','kimi','perplexity','compatible']).optional()},args=>api('/api/jobs',args));
let closing=false;
async function cleanup(){if(closing)return;closing=true;for(const profileId of touched)await api('/api/release',{profileId,owner}).catch(()=>{});await server.close();process.exit(0);}
process.on('SIGTERM',cleanup);process.on('SIGINT',cleanup);process.stdin.on('end',cleanup);
await server.connect(new StdioServerTransport());
