import test from 'node:test';
import assert from 'node:assert/strict';
import {SWAG_CATALOG,validateWorkflow,verifyInventory,verifyCart} from '../src/workflows.mjs';
test('表格任务拒绝跨环境、非练习账号与重复商品',()=>{
  const c={profileId:'env-001',username:'standard_user',sort:'lohi',selectedIds:[0,4]};
  const value={kind:'swag-labs-v1',runId:'test',case:c};
  assert.deepEqual(validateWorkflow(value,'env-001').case,c);
  assert.throws(()=>validateWorkflow(value,'env-002'));
  assert.throws(()=>validateWorkflow({...value,case:{...c,username:'someone'}} ,'env-001'));
  assert.throws(()=>validateWorkflow({...value,case:{...c,selectedIds:[0,0]}} ,'env-001'));
});
test('真实取数验收拒绝错误价格、错序和重复商品',()=>{
  const sorted=[...SWAG_CATALOG].sort((a,b)=>a.priceCents-b.priceCents);
  assert.equal(verifyInventory(sorted,'lohi'),true);
  assert.throws(()=>verifyInventory(sorted,'hilo'));
  assert.throws(()=>verifyInventory(sorted.map((p,i)=>i? p:{...p,priceCents:800}),'lohi'));
  assert.throws(()=>verifyInventory([...sorted.slice(1),sorted[1]],'lohi'));
});
test('购物车用整数分核算并拒绝错商品、错数量',()=>{
  const cart=[SWAG_CATALOG[0],SWAG_CATALOG[4]].map(p=>({...p,quantity:1}));
  assert.equal(verifyCart(cart,[0,4]),3998);
  assert.throws(()=>verifyCart(cart,[0,5]));
  assert.throws(()=>verifyCart(cart.map((p,i)=>({...p,quantity:i?2:1})),[0,4]));
});
