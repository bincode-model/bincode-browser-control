import test from 'node:test';
import assert from 'node:assert/strict';
import {PageSelection} from '../public/paging.js';
import {Fleet} from '../src/fleet.mjs';
import {verifyReadReceipt,inspectLogin,assessJobResult} from '../src/verification.mjs';

const profiles=Array.from({length:22},(_,i)=>({id:`env-${String(i+1).padStart(3,'0')}`,provider:'codex',group:1}));
test('22 家按 10/10/2 分页；全选、翻页、筛选和实时刷新不保留跨页选择',()=>{
  const p=new PageSelection();assert.equal(p.update(profiles).rows.length,10);assert.equal(p.selected.size,10);
  p.selected.delete('env-001');p.update(profiles);assert.equal(p.selected.size,9);
  p.move(1);p.update(profiles);assert.equal(p.selected.size,10);assert(!p.selected.has('env-001'));assert(p.selected.has('env-011'));
  p.move(1);assert.equal(p.update(profiles).rows.length,2);assert.equal(p.selected.size,2);
  assert.equal(p.update(profiles.slice(0,3),{reset:true}).rows.length,3);assert.equal(p.page,1);assert.equal(p.selected.size,3);
  p.update([],{reset:true});assert.equal(p.selected.size,0);
});
function fake(){
  const f=Object.create(Fleet.prototype);f.config={profiles,maxAgents:10,maxBrowsers:10};f.credentials={};f.jobs=[];f.runningJobs=new Map();f.runtime=new Map(profiles.map(p=>[p.id,{pid:null,starting:null,lease:null,socket:null,chain:Promise.resolve()}]));
  f.saveJobs=()=>{};f.changed=()=>{};f.log=()=>{};f.paused=true;return f;
}
test('普通任务 10/10/2 分批，浏览器清理未结束前不得进入下一批',async()=>{
  const f=fake();const jobs=f.enqueue({profileIds:profiles.map(p=>p.id),prompt:'只读取页面标题'});
  assert.deepEqual(jobs.map(j=>j.group),[...Array(10).fill(1),...Array(10).fill(2),3,3]);assert(jobs.every(j=>j.background===false));
  f.paused=false;const starts=[];f.runJob=async j=>{j.status='running';f.rt(j.profileId).pid=100;starts.push(j.profileId);};
  for(const count of [10,10,2]){
    await f.pump();const active=jobs.filter(j=>j.status==='running');assert.equal(active.length,count);assert.equal(new Set(active.map(j=>j.group)).size,1);
    active.forEach(j=>j.status='succeeded');await f.pump();assert.equal(jobs.filter(j=>j.status==='running').length,0);
    active.forEach(j=>{f.runningJobs.delete(j.id);f.rt(j.profileId).pid=null;f.rt(j.profileId).lease=null;});
  }
  assert.equal(new Set(starts).size,22);
});
test('任务接管待命连接；其他任务不能抢占；用户停止后不自动抢回',()=>{
  const f=fake(),r=f.rt('env-001');f.acquire('env-001','standby','控制台（待命）');r.lease.kind='standby';
  f.acquire('env-001','job-a','Codex');assert.equal(r.lease.owner,'job-a');assert.equal(r.lease.kind,'task');
  assert.throws(()=>f.acquire('env-001','job-b','AI'),/另一任务占用/);
  r.lease=null;r.userStopped=true;assert.throws(()=>f.acquire('env-001','job-b','AI'),/用户已停止/);
});
test('仅 socket 在线、错误编号、错误插件和缺少读取内容均不能冒充控制核验',()=>{
  const valid={result:{url:'https://shop.jd.com/',text:'店铺',title:'京麦'},proof:{profileId:'env-001',extensionId:'ext',debuggerAttached:true,attachedTabs:[1],timestamp:new Date().toISOString()}};
  assert.equal(verifyReadReceipt(valid,'env-001','ext').profileId,'env-001');
  for(const value of [{},{...valid,result:{}},{...valid,proof:{...valid.proof,debuggerAttached:false}},{...valid,proof:{...valid.proof,profileId:'env-002'}},{...valid,proof:{...valid.proof,extensionId:'other'}}])assert.throws(()=>verifyReadReceipt(value,'env-001','ext'));
});
test('登录页和等待补充范围不算完成；成功退出程序也不等于业务验收',()=>{
  assert.equal(inspectLogin({url:'https://passport.shop.jd.com/login',text:'扫码登录'},{}).state,'waiting_login');
  assert.equal(inspectLogin({url:'https://shop.jd.com/',text:'欢迎'},{}).state,'identity_pending');
  assert.equal(assessJobResult({result:'取数未完成，尚未取得业务数据，请先登录。'}).status,'waiting_login');
  assert.equal(assessJobResult({result:'请补充取数类型与日期范围。'}).status,'needs_input');
  assert.equal(assessJobResult({result:'任务已完成',actions:[{action:'snapshot'}]}).status,'needs_review');
});
