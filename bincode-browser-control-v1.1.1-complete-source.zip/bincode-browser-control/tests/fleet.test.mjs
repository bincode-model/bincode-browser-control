import test from 'node:test';
import assert from 'node:assert/strict';
import {Fleet} from '../src/fleet.mjs';
function fakeFleet(){
  const f=Object.create(Fleet.prototype);f.config={maxBrowsers:6,maxAgents:3,taskTimeoutMinutes:15,autoClose:true,profiles:Array.from({length:140},(_,i)=>({id:`env-${String(i+1).padStart(3,'0')}`,group:Math.floor(i/10)+1}))};f.jobs=[];f.runningJobs=new Map();f.runtime=new Map(f.config.profiles.map(p=>[p.id,{pid:null,starting:null,lease:null,socket:null,chain:Promise.resolve()}]));f.saveJobs=()=>{};f.save=()=>{};f.changed=()=>{};f.publicState=()=>({settings:f.config});f.log=()=>{};f.paused=false;return f;
}
test('140 个任务按每批 10 家轮换，任何时刻遵守任务和浏览器并发上限',async()=>{
  const f=fakeFleet();f.jobs=f.config.profiles.map((p,i)=>({id:'job-'+i,profileId:p.id,group:p.group,batchId:'all-140',status:'queued',provider:'codex'}));const started=[];
  f.runJob=async function(j){j.status='running';this.rt(j.profileId).pid=100+started.length;started.push(j);};
  for(let round=0;round<150;round++){
    await f.pump();assert(f.runningJobs.size<=3);assert(f.activeCount()<=6);
    const active=f.jobs.filter(j=>j.status==='running');assert(new Set(active.map(j=>j.group)).size<=1);
    for(const j of active){assert(!f.jobs.some(x=>x.batchId===j.batchId&&x.group<j.group&&x.status==='queued'));j.status='succeeded';f.runningJobs.delete(j.id);f.rt(j.profileId).lease=null;f.rt(j.profileId).pid=null;}
    if(f.jobs.every(j=>j.status==='succeeded'))break;
  }
  assert.equal(started.length,140);assert.deepEqual(started.map(j=>j.group),Array.from({length:140},(_,i)=>Math.floor(i/10)+1));
});
test('同一环境不能被两个任务同时控制',()=>{
  const f=fakeFleet();f.acquire('env-001','job-a','Codex');assert.throws(()=>f.acquire('env-001','job-b','Claude'),/另一任务占用/);f.acquire('env-002','job-b','Claude');assert.equal(f.rt('env-001').lease.owner,'job-a');assert.equal(f.rt('env-002').lease.owner,'job-b');
});
test('暂停队列阻止新任务启动',async()=>{const f=fakeFleet();f.paused=true;f.jobs=[{id:'j',profileId:'env-001',group:1,status:'queued',provider:'codex'}];f.runJob=()=>assert.fail('不应启动');await f.pump();assert.equal(f.jobs[0].status,'queued');assert.equal(f.runningJobs.size,0);});
test('浏览器容量耗尽时任务保持排队，释放容量后继续',async()=>{
  const f=fakeFleet();f.config.maxBrowsers=1;f.rt('env-140').pid=123;f.jobs=[{id:'j',profileId:'env-001',group:1,status:'queued',provider:'codex'}];let started=false;f.runJob=async()=>{started=true;};await f.pump();assert.equal(started,false);f.rt('env-140').pid=null;await f.pump();assert.equal(started,true);
});
test('并发和超时设置拒绝无效值',()=>{const f=fakeFleet();for(const value of [{maxBrowsers:11},{maxAgents:11},{maxAgents:0},{maxAgents:1.5},{taskTimeoutMinutes:-1},{autoClose:'yes'}])assert.throws(()=>f.settings(value));f.settings({maxBrowsers:10,maxAgents:10,taskTimeoutMinutes:240});assert.equal(f.config.maxBrowsers,10);});
test('空闲或容量不足时不反复写任务文件',async()=>{const f=fakeFleet();let writes=0;f.saveJobs=()=>writes++;await f.pump();assert.equal(writes,0);f.rt('env-001').lease={owner:'other'};f.jobs=[{id:'j',profileId:'env-001',group:1,status:'queued',provider:'codex'}];await f.pump();assert.equal(writes,0);});
test('并发设置为 10 时按 14 批依次完成 140 个环境',async()=>{const f=fakeFleet();f.config.maxBrowsers=10;f.config.maxAgents=10;f.jobs=f.config.profiles.map((p,i)=>({id:'j-'+i,profileId:p.id,group:p.group,batchId:'batch',status:'queued',provider:'codex'}));f.runJob=async j=>{j.status='running';f.rt(j.profileId).pid=100;};for(const expected of Array(14).fill(10)){await f.pump();assert.equal(f.runningJobs.size,expected);const active=f.jobs.filter(j=>j.status==='running');assert.equal(new Set(active.map(j=>j.group)).size,1);for(const j of active){j.status='succeeded';f.runningJobs.delete(j.id);f.rt(j.profileId).lease=null;f.rt(j.profileId).pid=null;}}assert(f.jobs.every(j=>j.status==='succeeded'));});
