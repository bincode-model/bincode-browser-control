import test from 'node:test';
import assert from 'node:assert/strict';
import {Fleet} from '../src/fleet.mjs';
import {validateJdIdentity,syncProfileIdentity} from '../src/identity.mjs';
import {inspectLogin} from '../src/verification.mjs';

const account={url:'https://shop.jd.com/jdm/home',shopName:'DJI大疆国信专卖店',shopId:'16201070',
  merchantId:'17809498',merchantType:'POP',loginAccount:'京汇通达-Work',mainAccount:'大疆国信专卖店'};
const snapshot={url:account.url,text:'首页 DJI大疆国信专卖店 POP 财务 交易',elements:[]};
const proof={profileId:'env-002',extensionId:'ext-002',debuggerAttached:true,attachedTabs:[22],timestamp:'2026-10-16T08:00:00Z'};

test('按真实京东账号卡的店铺ID核验，店名不必与旧配置一致',()=>{
  const identity=validateJdIdentity(account,snapshot);
  assert.equal(identity.storeKey,'jd:shop:16201070');
  const result=inspectLogin({...snapshot,identity:account},{name:'原配置其他店铺'});
  assert.equal(result.state,'logged_in');assert.equal(result.shopId,'16201070');
  assert.equal(inspectLogin({...snapshot,text:snapshot.text+' 退出登录'},{name:account.shopName}).state,'identity_pending');
});
test('缺少ID、登录页、其他域名和页面切换后的过期身份都不能通过',()=>{
  for(const value of [{...account,shopId:''},{...account,merchantId:'unknown'},
    {...account,url:'https://other.example/jdm/home'},{...account,url:account.url+'?old=1'},
    {...account,shopName:'其他店铺'},{...account,merchantType:'未知'}])assert.equal(validateJdIdentity(value,snapshot),null);
  assert.equal(validateJdIdentity(account,{...snapshot,elements:[{type:'password'}]}),null);
  assert.equal(inspectLogin({...snapshot,url:'https://passport.shop.jd.com/login',identity:account},{}).state,'waiting_login');
});
test('随机扫码换店更新实际身份，原目录和旧店铺目录资料保留，重复读取不增加历史',()=>{
  const p={id:'env-002',number:2,name:'旧店',storeId:'catalog-old',storeSourceRow:3,nameAliases:['旧店'],duplicateCandidates:['env-050'],userDataDir:'/original/env-002'};
  const identity=validateJdIdentity(account,snapshot);
  assert(syncProfileIdentity(p,identity,proof.timestamp));
  assert.equal(p.name,account.shopName);assert.equal(p.displayName,account.shopName);assert.equal(p.storeId,'jd:shop:16201070');
  assert.equal(p.catalogAssignment.storeId,'catalog-old');assert.equal(p.catalogAssignment.storeSourceRow,3);
  assert.equal(p.userDataDir,'/original/env-002');assert.equal(p.id,'env-002');assert.equal(p.number,2);
  assert.equal(p.storeSourceRow,undefined);assert.equal(p.duplicateCandidates,undefined);
  assert.equal(syncProfileIdentity(p,identity,'2026-10-16T08:01:00Z'),null);assert.equal(p.identityHistory.length,1);
  syncProfileIdentity(p,{...identity,shopName:'新扫码店铺',shopId:'99',storeKey:'jd:shop:99'},'2026-10-16T08:02:00Z');
  assert.equal(p.name,'新扫码店铺');assert.equal(p.identityHistory.length,2);assert.equal(p.catalogAssignment.name,'旧店');
});
function fake({wrongProof=false,stopped=false,expectedStoreKey=null}={}){
  const f=Object.create(Fleet.prototype);
  const p={id:'env-002',name:'旧配置',storePlatform:'京东POP'};
  f.config={profiles:[p]};f.jobs=expectedStoreKey?[{id:'job',status:'running',expectedStoreKey}]:[];
  const r={socket:{readyState:1},pid:123,extensionId:'ext-002',chain:Promise.resolve(),lease:{owner:'job',controller:'测试',kind:'task'}};
  f.runtime=new Map([[p.id,r]]);f.changed=()=>{};f.log=()=>{};f.save=()=>{};f.start=async()=>{};
  f.raw=async(id,action)=>{
    if(action==='snapshot')return {proof:{...proof},result:structuredClone(snapshot)};
    assert.equal(action,'evaluate');if(stopped)r.userStopped=true;
    return {proof:{...proof,...(wrongProof?{extensionId:'other'}:{})},result:structuredClone(account)};
  };
  return f;
}
test('实际读取后自动同步本地名称并报告已登录；登录页不能沿用上次状态',async()=>{
  const f=fake();const data=await f.command('env-002','snapshot',{}, {owner:'job',controller:'测试'});
  assert.equal(data.result.identity.shopId,'16201070');assert.equal(f.profile('env-002').name,account.shopName);
  assert.equal(f.rt('env-002').login.state,'logged_in');assert.equal(f.rt('env-002').pid,123);
  f.raw=async()=>({proof:{...proof},result:{url:'https://passport.shop.jd.com/login',text:'密码登录',elements:[{type:'password'}]}});
  await f.command('env-002','snapshot',{}, {owner:'job',controller:'测试'});
  assert.equal(f.rt('env-002').login.state,'waiting_login');assert.equal(f.profile('env-002').name,account.shopName);
});
test('错插件和用户停止后的身份回执不允许改名；排队期间换店阻止原任务继续',async()=>{
  for(const opts of [{wrongProof:true},{stopped:true}]){
    const f=fake(opts);await assert.rejects(f.command('env-002','snapshot',{}, {owner:'job'}));
    assert.equal(f.profile('env-002').name,'旧配置');
  }
  const f=fake({expectedStoreKey:'jd:shop:other'});
  await assert.rejects(f.command('env-002','snapshot',{}, {owner:'job'}),/实际登录店铺已变化/);
  assert.equal(f.profile('env-002').name,account.shopName);
});
