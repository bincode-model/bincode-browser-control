#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
case "$(uname -m)" in arm64) ;; *) echo '本离线包适用于 Apple 芯片 Mac。'; exit 1;; esac
mkdir -p "$HOME/Applications"
bootstrap_dir=$(mktemp -d "$HOME/Applications/.fleet-install.XXXXXX")
trap 'rm -rf "$bootstrap_dir"' EXIT
# 先落到用户 Applications 再执行，避免从解压/隔离目录直接启动运行时。
/bin/cp -X ./控制台/runtime/node/bin/node "$bootstrap_dir/node"
chmod 700 "$bootstrap_dir/node"
"$bootstrap_dir/node" ./迁移工具/install.mjs "$@"
