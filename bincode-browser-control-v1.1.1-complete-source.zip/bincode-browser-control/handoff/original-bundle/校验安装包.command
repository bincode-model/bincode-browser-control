#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p "$HOME/Applications"
bootstrap_dir=$(mktemp -d "$HOME/Applications/.fleet-verify.XXXXXX")
trap 'rm -rf "$bootstrap_dir"' EXIT
/bin/cp -X ./控制台/runtime/node/bin/node "$bootstrap_dir/node"
chmod 700 "$bootstrap_dir/node"
"$bootstrap_dir/node" ./迁移工具/verify.mjs
