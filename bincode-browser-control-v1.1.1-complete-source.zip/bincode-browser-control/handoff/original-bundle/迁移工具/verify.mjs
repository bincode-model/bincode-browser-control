import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

export const bundleRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export function verify(root=bundleRoot){
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'文件校验清单.json'),'utf8'));
  const cache=new Map(); let files=0,links=0,bytes=0;
  for(const entry of manifest.entries){
    const p=path.resolve(root,entry.path);
    if(!p.startsWith(root+path.sep))throw Error('校验清单含越界路径');
    const st=fs.lstatSync(p);
    if(entry.type==='directory'){
      if(!st.isDirectory())throw Error('目录类型不符：'+entry.path);
    }else if(entry.type==='symlink'){
      if(!st.isSymbolicLink()||fs.readlinkSync(p)!==entry.target)throw Error('链接不符：'+entry.path);
      links++;
    }else{
      if(!st.isFile()||st.size!==entry.size)throw Error('文件大小不符：'+entry.path);
      const key=st.dev+':'+st.ino+':'+st.size;
      let sum=cache.get(key);
      if(!sum){
        const h=crypto.createHash('sha256'),fd=fs.openSync(p,'r'),buf=Buffer.allocUnsafe(4*1024*1024);
        try{let n;while((n=fs.readSync(fd,buf,0,buf.length,null))>0)h.update(buf.subarray(0,n));}finally{fs.closeSync(fd);}
        sum=h.digest('hex');cache.set(key,sum);
      }
      if(sum!==entry.sha256)throw Error('SHA-256 不符：'+entry.path);
      if((st.mode&0o111)!==(entry.mode&0o111))throw Error('执行权限不符：'+entry.path);
      files++;bytes+=st.size;
    }
  }
  return {passed:true,files,links,logicalBytes:bytes,uniqueHashedFiles:cache.size};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{console.log('正在核验完整安装包…');console.log(JSON.stringify(verify(),null,2));console.log('校验通过。');}
  catch(e){console.error('校验失败：'+e.message);process.exitCode=1;}
}
