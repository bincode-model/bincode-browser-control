import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {bundleRoot,verify} from './verify.mjs';

const argv=process.argv.slice(2);
const at=argv.indexOf('--dest');
const dest=path.resolve(at>=0?argv[at+1]:path.join(os.homedir(),'Applications','bincode多浏览器控制-1.1.1'));
const shortcuts=!argv.includes('--no-shortcuts');
const source=path.join(bundleRoot,'控制台');
const originalRoot='/Users/wangxin/Applications/AI浏览器控制台-20261015';
const report={startedAt:new Date().toISOString(),source,destination:dest,changes:[]};
let staging;
function json(file,value){fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{mode:0o600});}
function change(message){report.changes.push(message);console.log(message);}
function replacePaths(value){
  if(typeof value==='string')return value.replaceAll(originalRoot,dest);
  if(Array.isArray(value))return value.map(replacePaths);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,replacePaths(v)]));
  return value;
}
try{
  if(process.platform!=='darwin'||process.arch!=='arm64')throw Error('本离线包适用于 Apple 芯片 Mac。Intel Mac 需要对应的浏览器运行时。');
  const macVersion=execFileSync('/usr/bin/sw_vers',['-productVersion'],{encoding:'utf8'}).trim();
  if(Number(macVersion.split('.')[0])<14)throw Error('本迁移包要求 macOS 14 或更高版本。');
  if(fs.existsSync(dest))throw Error('目标目录已存在，未覆盖任何内容：'+dest+'。如需另装，请使用 --dest 指定新目录。');
  if(dest===source||dest.startsWith(bundleRoot+path.sep))throw Error('安装目标必须在解压包外。');
  console.log('正在校验全部文件…');report.packageVerification=verify();
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  staging=dest+'.installing-'+process.pid;
  if(fs.existsSync(staging))throw Error('安装临时目录已存在：'+staging);
  console.log('正在复制控制台、140 个编号浏览器和独立资料…');
  fs.cpSync(source,staging,{recursive:true,preserveTimestamps:true,verbatimSymlinks:true,mode:fs.constants.COPYFILE_FICLONE,errorOnExist:true,force:false});
  fs.chmodSync(staging,0o700);
  const data=path.join(staging,'data');fs.chmodSync(data,0o700);
  const cfg=replacePaths(JSON.parse(fs.readFileSync(path.join(data,'fleet.json'),'utf8')));
  cfg.chrome=path.join(dest,'runtime/browser/Chromium.app/Contents/MacOS/Chromium');
  if(cfg.profiles.length!==140)throw Error('环境数不符，安装未完成');
  json(path.join(data,'fleet.json'),cfg);
  change('已修正运行时与店铺配置中的旧电脑路径，保留全部编号、店铺名和独立资料。');
  const jobsFile=path.join(data,'jobs.json');
  const jobs=JSON.parse(fs.readFileSync(jobsFile,'utf8'));
  for(const j of jobs)if(['queued','starting','running'].includes(j.status)){
    j.migrationPreviousStatus=j.status;j.status='interrupted';j.endedAt=new Date().toISOString();j.error='迁移后未自动续跑，请核验店铺身份和任务范围后再运行。';
  }
  json(jobsFile,jobs);
  for(const name of ['server.pid','mcp-config.json']){
    const p=path.join(data,name);if(fs.existsSync(p))fs.unlinkSync(p);
  }
  for(const p of cfg.profiles){
    const profile=path.join(data,'profiles',p.id);
    for(const name of ['SingletonLock','SingletonSocket','SingletonCookie','DevToolsActivePort']){
      const f=path.join(profile,name);try{if(fs.lstatSync(f).isFile()||fs.lstatSync(f).isSymbolicLink())fs.unlinkSync(f);}catch(e){if(e.code!=='ENOENT')throw e;}
    }
    const prefs=path.join(profile,'Default','Preferences');
    if(fs.existsSync(prefs)){
      const value=JSON.parse(fs.readFileSync(prefs,'utf8'));let changed=false;
      if(value.download?.default_directory?.startsWith('/Users/wangxin/')){
        value.download.default_directory=path.join(os.homedir(),'Downloads');changed=true;
      }
      if(changed)json(prefs,value);
    }
  }
  change('已清理迁移副本的旧进程锁；使用空任务队列，不会续跑旧任务。');
  fs.renameSync(staging,dest);staging=null;
  const app=path.join(dest,'bincode多浏览器控制.app');
  fs.writeFileSync(path.join(app,'Contents/Resources/fleet-path.txt'),dest+'\n');
  execFileSync('/usr/bin/codesign',['--force','--sign','-',app],{stdio:'pipe'});
  const node=path.join(dest,'runtime/node/bin/node');
  const doctor=execFileSync(node,[path.join(dest,'scripts/portable/doctor.mjs')],{cwd:dest,encoding:'utf8',env:{...process.env,FLEET_DATA_DIR:path.join(dest,'data'),PATH:path.dirname(node)+':'+(process.env.PATH||'')}});
  report.doctor=JSON.parse(doctor);
  change('已生成本机 MCP 配置并通过环境检查。');
  for(const name of ['使用说明.txt','使用说明.html','GitHub参考与版本.txt','开发交接.txt','AI与MCP接入说明.txt','店铺与后台对应表.txt','店铺入口核对.json'])fs.copyFileSync(path.join(bundleRoot,name),path.join(dest,name));
  if(shortcuts){
    const desktop=path.join(os.homedir(),'Desktop');fs.mkdirSync(desktop,{recursive:true});
    for(const name of ['bincode多浏览器控制.app','批量打开浏览器.app']){
      let link=path.join(desktop,name);
      try{fs.lstatSync(link);link=path.join(desktop,name.replace('.app','-20261017.app'));}catch(e){if(e.code!=='ENOENT')throw e;}
      try{fs.lstatSync(link);change('已有桌面入口未覆盖：'+link);continue;}catch(e){if(e.code!=='ENOENT')throw e;}
      fs.symlinkSync(app,link);change('已创建桌面入口：'+link);
    }
  }
  report.passed=true;report.finishedAt=new Date().toISOString();json(path.join(dest,'data/迁移安装记录.json'),report);
  console.log('\n安装完成：'+dest+'\n双击桌面“bincode多浏览器控制.app”使用。安装程序没有启动店铺或取数任务。');
}catch(e){
  report.passed=false;report.error=e.message;console.error('\n安装未完成：'+e.message);
  if(staging)console.error('已保留安装临时目录，便于检查：'+staging);
  process.exitCode=1;
}
