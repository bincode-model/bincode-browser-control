# bincode多浏览器控制 1.1.1

完整使用与迁移步骤见安装目录的“使用说明.txt”。AI/MCP 接入见“AI与MCP接入说明.txt”。开发入口与当前环境见“开发交接.txt”。

从控制台启动编号浏览器，默认进入配置的商家后台，并在页面读取及调试回执核验后显示“AI 调试已连接 · 待命”。140 个资料目录独立；当前最多同时 10 个浏览器、10 个 AI 任务。

运行本机诊断：`./runtime/node/bin/node scripts/portable/check-multi-mcp.mjs`。登录自己的 Codex 后加 `--agent` 验证真实 AI 操作。
