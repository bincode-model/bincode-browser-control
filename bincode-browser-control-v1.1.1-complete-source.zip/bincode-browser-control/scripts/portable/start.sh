#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
if [ -x runtime/node/bin/node ]; then export PATH="$PWD/runtime/node/bin:$PATH"; fi
if ! command -v node >/dev/null 2>&1; then echo '请先运行 ./安装.command'; exit 1; fi
if [ "$(uname -s)" = Linux ] && [ "$(id -u)" = 0 ]; then echo '请使用普通用户运行浏览器；参照交付说明创建用户。'; exit 1; fi
node scripts/portable/doctor.mjs
exec node scripts/launch.mjs "$@"
