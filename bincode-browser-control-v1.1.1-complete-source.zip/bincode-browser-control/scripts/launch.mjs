import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {ROOT,DATA,sleep,initStore} from '../src/store.mjs';
const config=initStore(),url=`http://127.0.0.1:${config.port}`;
async function live(){
  let r;try{r=await fetch(url+'/health',{signal:AbortSignal.timeout(1500)});}catch{return false;}
  const data=await r.json().catch(()=>null);
  if(!r.ok||data?.profiles!==140||data?.version!=='1.1.1'||data?.root!==ROOT||data?.dataDir!==DATA)throw Error('本机端口 '+config.port+' 已由另一套后台占用。请先正常停止旧控制台后台，再打开本版本。未连接到其他目录的服务。');
  return true;
}
if(!await live()){
  const log=fs.openSync(path.join(DATA,'server.log'),'a',0o600);const child=spawn(process.execPath,[path.join(ROOT,'src/server.mjs')],{cwd:ROOT,detached:true,stdio:['ignore',log,log]});child.unref();fs.closeSync(log);
  let ready=false;for(let n=0;n<100;n++){if(await live()){ready=true;break;}await sleep(100);}if(!ready)throw Error('控制台启动失败，请查看 '+path.join(DATA,'server.log'));
}
if(!process.argv.includes('--no-open')){
  if(process.platform==='darwin'){
    const app=path.join(ROOT,'bincode多浏览器控制.app');
    if(fs.existsSync(app))spawn('/usr/bin/open',[app],{stdio:'ignore'}).unref();
  }else if(process.platform==='win32')spawn('cmd',['/c','start',url],{stdio:'ignore'}).unref();else spawn('xdg-open',[url],{stdio:'ignore'}).unref();
}
console.log('bincode多浏览器控制：'+url);
