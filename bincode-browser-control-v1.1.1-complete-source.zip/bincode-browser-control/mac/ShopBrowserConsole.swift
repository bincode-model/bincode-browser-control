import AppKit
import Foundation
import WebKit

private enum LaunchResult {
    case success
    case failure(String)
}

private final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, NSWindowDelegate {
    private var window: NSWindow!
    private var webView: WKWebView!
    private var consoleURL: URL {
        var port = 17400
        if let root = fleetRoot(),
           let data = try? Data(contentsOf: root.appendingPathComponent("data/fleet.json")),
           let config = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let configured = config["port"] as? Int { port = configured }
        return URL(string: "http://127.0.0.1:\(port)/")!
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1450, height: 900),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "bincode多浏览器控制"
        window.minSize = NSSize(width: 1020, height: 680)
        window.contentView = webView
        window.delegate = self
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        showMessage("正在连接 bincode 本机控制台…")

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            let result = self.ensureServer()
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.webView.load(URLRequest(url: self.consoleURL))
                case .failure(let message):
                    self.showMessage(message)
                }
            }
        }
    }

    func windowWillClose(_ notification: Notification) {
        NSApp.terminate(nil)
    }

    private func showMessage(_ message: String) {
        let safe = message.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
        webView.loadHTMLString("<meta charset='utf-8'><style>body{font:20px system-ui;margin:10%;color:#21434b;background:#f4f8f9}</style><h2>bincode多浏览器控制</h2><p>\(safe)</p>", baseURL: nil)
    }

    private func fleetRoot() -> URL? {
        let localRoot = Bundle.main.bundleURL.deletingLastPathComponent()
        if FileManager.default.fileExists(atPath: localRoot.appendingPathComponent("src/server.mjs").path) {
            return localRoot
        }
        guard let file = Bundle.main.url(forResource: "fleet-path", withExtension: "txt"),
              let value = try? String(contentsOf: file, encoding: .utf8).trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty else { return nil }
        return URL(fileURLWithPath: value, isDirectory: true)
    }

    private func serverIsHealthy() -> Bool {
        let semaphore = DispatchSemaphore(value: 0)
        var healthy = false
        var request = URLRequest(url: consoleURL.appendingPathComponent("health"))
        request.timeoutInterval = 2
        URLSession.shared.dataTask(with: request) { data, response, _ in
            if let response = response as? HTTPURLResponse, response.statusCode == 200,
               let data, let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                healthy = json["ok"] as? Bool == true && json["profiles"] as? Int == 140
                    && json["version"] as? String == "1.1.1"
                    && json["root"] as? String == self.fleetRoot()?.resolvingSymlinksInPath().path
            }
            semaphore.signal()
        }.resume()
        _ = semaphore.wait(timeout: .now() + 3)
        return healthy
    }

    private func ensureServer() -> LaunchResult {
        if serverIsHealthy() { return .success }
        guard let root = fleetRoot() else { return .failure("找不到蓝色浏览器控台目录。") }
        let node = root.appendingPathComponent("runtime/node/bin/node")
        let launcher = root.appendingPathComponent("scripts/launch.mjs")
        guard FileManager.default.isExecutableFile(atPath: node.path),
              FileManager.default.fileExists(atPath: launcher.path) else {
            return .failure("蓝色浏览器控台文件不完整：\(root.path)")
        }
        let process = Process()
        process.executableURL = node
        process.arguments = [launcher.path, "--no-open"]
        process.currentDirectoryURL = root
        process.standardOutput = Pipe()
        process.standardError = Pipe()
        do {
            try process.run()
            process.waitUntilExit()
        } catch {
            return .failure("启动控台失败：\(error.localizedDescription)")
        }
        if process.terminationStatus != 0 {
            let errorData = (process.standardError as? Pipe)?.fileHandleForReading.readDataToEndOfFile() ?? Data()
            let detail = String(data: errorData, encoding: .utf8) ?? ""
            return .failure("控台启动失败。请先正常停止占用端口的旧控制台，再重新打开。本次未连接到旧版本。\n" + String(detail.suffix(1200)))
        }
        for _ in 0..<30 {
            if serverIsHealthy() { return .success }
            Thread.sleep(forTimeInterval: 0.1)
        }
        return .failure("控台没有在配置的本机端口启动，请查看 data/server.log。")
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showMessage("控台页面加载失败：\(error.localizedDescription)")
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showMessage("控台页面加载失败：\(error.localizedDescription)")
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { NSWorkspace.shared.open(url) }
        return nil
    }
}

let application = NSApplication.shared
application.setActivationPolicy(.regular)
private let delegate = AppDelegate()
application.delegate = delegate
application.run()
